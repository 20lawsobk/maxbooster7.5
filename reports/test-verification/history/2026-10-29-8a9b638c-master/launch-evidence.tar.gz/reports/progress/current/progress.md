# Counted production completion

Measurement: **CURRENT**.

There is no estimated overall implementation percentage. These measured denominators remain separate.

Tested source: `8a9b638c6c1ce1b46a19501ee4a48893497c2518`; master finished `2026-10-29T22:49:33.882036+00:00`.

| Measurement | Verified at last run | Percentage |
| --- | ---: | ---: |
| Fully Green pages | 0/80 | 0.000000% |
| Required-check acceptance | 0/33549 | 0.000000% |
| Whole-plan work acceptance | 0/53033 | 0.000000% |
| Lines coverage | 29344/224013 | 13.099240% raw; 13.09% canonical |
| Statements coverage | 31245/240335 | 13.000603% raw; 13% canonical |
| Functions coverage | 4150/47857 | 8.671668% raw; 8.67% canonical |
| Branches coverage | 13914/158578 | 8.774231% raw; 8.77% canonical |

These are acceptance and execution measurements, not equivalent estimates of implemented functionality.
Test groups overlap; no combined unique test count is claimed.
A current measurement does not imply a passing master or launch approval.
