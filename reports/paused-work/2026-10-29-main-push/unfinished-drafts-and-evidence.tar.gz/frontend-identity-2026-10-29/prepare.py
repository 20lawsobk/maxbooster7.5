from pathlib import Path
import ast,hashlib,json,subprocess
ROOT=Path('/workspace/maxbooster7.5');OUT=Path('/workspace/onboarding-results/frontend-identity-2026-10-29');PATCH=Path('/workspace/onboarding-results/generation-critical-path-2026-10-29/frontend/evidence/source.patch');SOURCE='5eb416a04021f66c9bfc8af93997ec9fe8a55e31'
text=PATCH.read_text();paths=[line[6:] for line in text.splitlines() if line.startswith('+++ b/')];sourcepaths=[p for p in paths if p.startswith('client/')]
records=[]
for side in ['before','after']:
 dest=OUT/side;dest.mkdir(exist_ok=True)
 for path in paths:
  result=subprocess.run(['git','show',SOURCE+':'+path],cwd=ROOT,capture_output=True)
  if result.returncode==0:
   f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(result.stdout)
  elif side=='before':continue
 node=dest/'node_modules'
 if not node.exists():node.symlink_to(ROOT/'node_modules',target_is_directory=True)
 if side=='after':subprocess.run(['git','apply',str(PATCH)],cwd=dest,check=True)
 for path in sourcepaths:
  f=dest/path
  if f.exists():records.append({'side':side,'path':path,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 # Retain actual source declarations using the unchanged registry extractor.
 tree=ast.parse((ROOT/'scripts/testing/platform-register.py').read_text());extractor=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NODE_EXTRACTOR' for t in n.targets)))
 node=subprocess.run(['/workspace/.cloud-tools/node_modules/.bin/node','-e',extractor],cwd=dest,input=json.dumps([p for p in sourcepaths if (dest/p).exists()]),capture_output=True,text=True,check=True)
 (OUT/(side+'-actual-extractor.json')).write_text(node.stdout+'\n')
 # Unchanged static scanner's cwd controls all outputs. This copies only reviewed client files, sends no network requests.
 node=subprocess.run(['/workspace/.cloud-tools/node_modules/.bin/node',str(ROOT/'scripts/audit-endpoints.mjs'),'--static'],cwd=dest,capture_output=True,text=True,check=True)
 (OUT/(side+'-static-scanner.txt')).write_text(node.stdout+node.stderr)
 (OUT/(side+'-actual-calls.json')).write_bytes((dest/'reports/endpoint-audit.json').read_bytes())
(OUT/'source-inputs.json').write_text(json.dumps({'sourceRevision':SOURCE,'patchPath':str(PATCH),'patchSha256':hashlib.sha256(PATCH.read_bytes()).hexdigest(),'productionPaths':sourcepaths,'sourceFiles':records,'scope':'Outside copied-source static analysis; scanner uses only nine reviewed source files and does not claim full-registry live behavior'},indent=2)+'\n')
print(json.dumps({'productionFiles':len(sourcepaths),'patchSha256':hashlib.sha256(PATCH.read_bytes()).hexdigest(),'records':len(records)}))
