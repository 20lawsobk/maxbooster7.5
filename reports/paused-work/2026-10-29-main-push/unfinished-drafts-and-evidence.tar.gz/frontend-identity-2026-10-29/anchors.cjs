const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const ts=require('/workspace/maxbooster7.5/node_modules/typescript');
const root=path.resolve(process.argv[2]);
const sources=JSON.parse(fs.readFileSync(0,'utf8'));
const out={files:[],interactions:[],calls:[]};
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
function tokens(text){const s=ts.createScanner(ts.ScriptTarget.Latest,true,ts.LanguageVariant.JSX,text);const a=[];for(let k=s.scan();k!==ts.SyntaxKind.EndOfFileToken;k=s.scan())a.push([ts.SyntaxKind[k],s.getTokenText()]);return a;}
function namedOwner(node){const a=[];for(let p=node.parent;p;p=p.parent){if(ts.isFunctionDeclaration(p)&&p.name)a.push(p.name.text);else if((ts.isArrowFunction(p)||ts.isFunctionExpression(p))&&ts.isVariableDeclaration(p.parent))a.push(p.parent.name.getText());else if(ts.isMethodDeclaration(p))a.push(p.name.getText());}return a.reverse();}
function isContainer(n){return ts.isJsxElement(n)||ts.isJsxSelfClosingElement(n);}
for(const file of sources){
 const f=path.join(root,file);if(!fs.existsSync(f))continue;
 const text=fs.readFileSync(f,'utf8'),sf=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,file.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
 const containers=[],calls=[],definitions=[];
 function visit(n){if(isContainer(n))containers.push(n);if(ts.isCallExpression(n))calls.push(n);if(ts.isFunctionDeclaration(n)&&n.name)definitions.push({name:n.name.text,owner:namedOwner(n),body:hash(tokens(n.getText(sf)))});if(ts.isVariableDeclaration(n)&&n.initializer){let fn=n.initializer;if(ts.isCallExpression(fn)&&/^(?:React\.)?useCallback$/.test(fn.expression.getText(sf)))fn=fn.arguments[0];if(fn&&(ts.isArrowFunction(fn)||ts.isFunctionExpression(fn)))definitions.push({name:n.name.getText(sf),owner:namedOwner(n),body:hash(tokens(fn.getText(sf)))});}ts.forEachChild(n,visit);}visit(sf);
 const parents=new Map(),children=new Map();for(const n of containers){let p=n.parent;while(p&&!isContainer(p))p=p.parent;parents.set(n,p||null);const a=children.get(p||null)||[];a.push(n);children.set(p||null,a);}
 const opening=n=>ts.isJsxElement(n)?n.openingElement:n;
 function jsxPath(n){const parts=[];for(let x=n;x;x=parents.get(x)){const op=opening(x);const siblings=children.get(parents.get(x))||[];parts.push([op.tagName.getText(sf),siblings.indexOf(x)]);}return parts.reverse();}
 for(const n of containers){const op=opening(n);const start=op.getStart(sf),pos=sf.getLineAndCharacterOfPosition(start);const owner=namedOwner(op);const attrs=op.attributes.properties.filter(ts.isJsxAttribute);const handlerBodies=[];for(const a of attrs){if(!/^on[A-Z]/.test(a.name.getText(sf)))continue;const exp=a.initializer&&ts.isJsxExpression(a.initializer)?a.initializer.expression:null;if(!exp||!ts.isIdentifier(exp))continue;const found=definitions.filter(d=>d.name===exp.text&&d.owner.join('/')===owner.join('/'));handlerBodies.push({event:a.name.getText(sf),handler:exp.text,definitions:found.map(d=>d.body)});}
 out.interactions.push({file,line:pos.line+1,column:pos.character+1,tag:op.tagName.getText(sf),owner,jsxPath:jsxPath(n),openingTokenSha256:hash(tokens(op.getText(sf))),handlerBodies,key:hash([file,owner,jsxPath(n),hash(tokens(op.getText(sf)))])});}
 for(const n of calls){const pos=sf.getLineAndCharacterOfPosition(n.getStart(sf));out.calls.push({file,line:pos.line+1,column:pos.character+1,endLine:sf.getLineAndCharacterOfPosition(n.end).line+1,owner:namedOwner(n),callee:n.expression.getText(sf),callTokenSha256:hash(tokens(n.getText(sf))),directStrings:n.arguments.filter(n=>ts.isStringLiteralLike(n)||ts.isTemplateExpression(n)).map(n=>({kind:ts.SyntaxKind[n.kind],text:n.getText(sf)}))});}
 out.files.push({file,parseErrors:sf.parseDiagnostics.map(d=>d.code),sourceSha256:crypto.createHash('sha256').update(text).digest('hex')});
}
process.stdout.write(JSON.stringify(out));
