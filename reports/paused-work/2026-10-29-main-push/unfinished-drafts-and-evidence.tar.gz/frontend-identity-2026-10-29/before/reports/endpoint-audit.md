# Static Frontend/Backend API Inventory

Generated 2026-10-29T23:31:53.967Z without live requests.

- Backend route registrations: **0** (0 unique method/path pairs).
- Mounted router files: **0**.
- Frontend API call sites: **24** (18 unique method/path pairs).
- Matched: **0**; unmatched confirmed: **17**; method-unconfirmed: **1**.
- Cache/comment/non-API references: **11**; external URL references: **0**; SPA URL references: **1**.
- Dynamic frontend URLs unresolved: **0**.

## Confirmed matches

Every entry below has a statically detected frontend transport and at least one mounted backend route with the same method and normalized path. The full occurrence and backend location inventory is in `endpoint-audit.json`.


## Unmatched confirmed frontend calls

- **POST /api/social/analyze-image** via fetch — client/src/components/content/ServerVideoGenerator.tsx:824
- **POST /api/social/beat-analyze** via fetch — client/src/components/content/ServerVideoGenerator.tsx:899
- **POST /api/social/generate-music-video** via fetch — client/src/components/content/ServerVideoGenerator.tsx:949
- **POST /api/studio/generation/text** via apiRequest — client/src/components/studio/AIMusicGenerator.tsx:271, client/src/components/studio/StudioOneDAW.tsx:1463, client/src/components/studio/UltimateDAW.tsx:392
- **POST /api/studio/generation/pattern/arrangement** via apiRequest — client/src/components/studio/AIMusicGenerator.tsx:415, client/src/components/studio/StudioOneDAW.tsx:1627
- **PATCH /api/studio/tracks/:param** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:1240
- **DELETE /api/studio/tracks/:param** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:1270
- **POST /api/studio/tracks** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:1293
- **POST /api/studio/ai-mix/:param** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:1345, client/src/components/studio/UltimateDAW.tsx:279
- **POST /api/studio/ai-master/:param** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:1370, client/src/components/studio/UltimateDAW.tsx:299
- **POST /api/studio/clips/:param/analyze** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:1579
- **POST /api/studio/generation/pattern/chords** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:1669
- **GET /api/studio/projects/:param/mix-snapshots** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:5467
- **POST /api/studio/projects/:param/mix-snapshots** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:5480
- **POST /api/studio/projects/:param/mix-snapshots/:param/recall** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:5496
- **DELETE /api/studio/projects/:param/mix-snapshots/:param** via apiRequest — client/src/components/studio/StudioOneDAW.tsx:5510
- **POST /api/studio/record/upload** via fetch — client/src/components/studio/UltimateDAW.tsx:531

## Method-unconfirmed frontend calls

- `GET /api/social/video-job/:param` (fetch) — client/src/components/content/ServerVideoGenerator.tsx:411, client/src/components/content/ServerVideoGenerator.tsx:499

## Dynamic unresolved URLs and registrations

None.

## Dynamically resolved frontend contracts

Resolved source traces: **0**; generic/unverified call sites: **0**.

## Non-network and non-API references

- `comment: /api/social/generate-video` — client/src/components/content/ServerVideoGenerator.tsx:68
- `comment: /api/social/video-job/:id` — client/src/components/content/ServerVideoGenerator.tsx:69
- `not-api-reference: /api/social/generate-video` — client/src/components/content/ServerVideoGenerator.tsx:304
- `cache-key: /api/projects` — client/src/components/studio/StudioOneDAW.tsx:1767
- `cache-key: /api/studio/projects` — client/src/components/studio/StudioOneDAW.tsx:1769
- `cache-key: /api/studio/start-hub/summary` — client/src/components/studio/StudioOneDAW.tsx:1772
- `cache-key: /api/projects` — client/src/components/studio/StudioOneDAW.tsx:2727
- `cache-key: /api/studio/projects` — client/src/components/studio/StudioOneDAW.tsx:2728
- `not-api-reference: /api/audio-job/${encodeURIComponent(jobId)}` — client/src/components/studio/studioAudioDelivery.ts:180
- `not-api-reference: /api/audio/${encodeURIComponent(jobId)}/midi` — client/src/components/studio/studioAudioDelivery.ts:218
- `not-api-reference: /api/social/music-video-job/${encodeURIComponent(jobId)}` — client/src/lib/musicVideoJobs.ts:19

## External URLs and SPA paths

External URL references: 0; SPA path references: 1. These are intentionally not compared with Express API routes.

## Mounted router prefixes


## Findings

- **unmatched-confirmed-1**: The frontend makes a detected POST /api/social/analyze-image request via fetch, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-2**: The frontend makes a detected POST /api/social/beat-analyze request via fetch, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-3**: The frontend makes a detected POST /api/social/generate-music-video request via fetch, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-4**: The frontend makes a detected POST /api/studio/generation/text request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-5**: The frontend makes a detected POST /api/studio/generation/pattern/arrangement request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-6**: The frontend makes a detected PATCH /api/studio/tracks/:param request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-7**: The frontend makes a detected DELETE /api/studio/tracks/:param request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-8**: The frontend makes a detected POST /api/studio/tracks request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-9**: The frontend makes a detected POST /api/studio/ai-mix/:param request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-10**: The frontend makes a detected POST /api/studio/ai-master/:param request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-11**: The frontend makes a detected POST /api/studio/clips/:param/analyze request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-12**: The frontend makes a detected POST /api/studio/generation/pattern/chords request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-13**: The frontend makes a detected GET /api/studio/projects/:param/mix-snapshots request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-14**: The frontend makes a detected POST /api/studio/projects/:param/mix-snapshots request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-15**: The frontend makes a detected POST /api/studio/projects/:param/mix-snapshots/:param/recall request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-16**: The frontend makes a detected DELETE /api/studio/projects/:param/mix-snapshots/:param request via apiRequest, but no statically mounted backend registration matches this method and path.
- **unmatched-confirmed-17**: The frontend makes a detected POST /api/studio/record/upload request via fetch, but no statically mounted backend registration matches this method and path.

## Scope and honesty notes

- This is a static inventory only. It does not invoke routes, perform admin authentication, or make mutating requests.
- `queryClient.invalidateQueries`/`setQueryData` entries are cache keys, not network calls. Query keys with a custom `queryFn` are listed as references; the custom fetch is inventoried separately.
- Template placeholders are normalized to `:param`; computed URLs without a literal assignment remain dynamic unresolved rather than guessed.
- External URLs and SPA navigation paths are not API contracts. A component is not reported as needing an endpoint merely because it contains a cache key, link, or documentation example.

## Recommended isolated regression and live plan

- Widest safe isolated command: `npx vitest run --config vitest.config.ts tests/unit/audit-endpoints.test.ts tests/unit/typed-route-audit.test.ts tests/unit/frontend-batch-response-contracts.test.ts tests/unit/startup-probes.test.ts`.
- Read-only live inventory: `node scripts/audit-endpoints.mjs`. This sends only blocklist-cleared GET requests.
- Treat static matches and non-404 GET responses as routing evidence only. Validate request/response schemas in isolated tests; exercise non-GET contracts only against an isolated test database with payment, publishing, distribution, notification, and external-network adapters disabled.