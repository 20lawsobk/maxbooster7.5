from pathlib import Path
import collections,copy,datetime,hashlib,importlib.util,json
ROOT=Path('/workspace/maxbooster7.5');O=Path('/workspace/onboarding-results/frontend-identity-2026-10-29')
def read(p):return json.loads(p.read_text())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
reg=load('identity_relation_registry',ROOT/'scripts/testing/platform-register.py');r=read(ROOT/'reports/test-verification/platform-register.json');plan=read(ROOT/'reports/test-verification/completion-plan.json');inputs=read(O/'source-inputs.json')
raw={s:read(O/(s+'-actual-extractor.json')) for s in ['before','after']};anchors={s:read(O/(s+'-anchors.json')) for s in ['before','after']};calls={s:read(O/(s+'-actual-calls.json'))['frontendCalls'] for s in ['before','after']}
index={s:{(n['file'],n['line'],n['column']):n for n in anchors[s]['interactions']} for s in anchors}
def uid(row):return reg.identifier('ui',row['file'],row['line'],row['column'],row['tag'],row['eventBindings'])
def cid(row):return reg.identifier('call',row['file'],row['line'],row.get('method'),row.get('path'))
bykey={s:collections.defaultdict(list) for s in raw}
for side in raw:
 for n in raw[side]['interactions']:
  a=index[side][(n['file'],n['line'],n['column'])];bykey[side][a['key']].append((n,a))
ui=[];unresolved=[]
for key,oldrows in bykey['before'].items():
 newrows=bykey['after'].get(key,[])
 if len(oldrows)!=1 or len(newrows)!=1:
  unresolved.append({'kind':'interaction-anchor-ambiguity-or-semantic-change','key':key,'oldRows':[x[0] for x in oldrows],'newRows':[x[0] for x in newrows]});continue
 old,a=oldrows[0];new,b=newrows[0]
 exact_semantics=all(old[k]==new[k] for k in ['tag','labels','eventBindings'])
 if not exact_semantics:
  unresolved.append({'kind':'interaction-semantics-changed','old':old,'new':new});continue
 ui.append({'oldId':uid(old),'newId':uid(new),'file':old['file'],'oldSource':{'line':old['line'],'column':old['column']},'newSource':{'line':new['line'],'column':new['column']},'tag':old['tag'],'labels':old['labels'],'eventBindings':old['eventBindings'],'anchor':{'owner':a['owner'],'jsxPath':a['jsxPath'],'openingTokenSha256':a['openingTokenSha256'],'key':key},'namedHandlerImplementationTokensChanged':a['handlerBodies']!=b['handlerBodies'],'reviewScope':'Same control declaration, accessible attributes and event binding identity. Changed helper/handler implementation remains a fresh behavioral acceptance obligation.','transferPass':False})
oldreg={x['id']:x for x in r['interactions']};assert len(ui)==259 and all(x['oldId'] in oldreg for x in ui)
# Calls need exact method/path/kind/confidence and a unique same-function enclosing transport anchor.
def call_anchor(side,row):
 a=anchors[side]['calls'];candidates=[]
 for n in a:
  if n['file']!=row['file'] or not(n['line']<=row['line']<=n['endLine']):continue
  for st in n['directStrings']:
   import re
   value=re.sub(r'\$\{[^}]*\}',':param',st['text'][1:-1])
   if value==row['path']:candidates.append(n)
 candidates=sorted(candidates,key=lambda n:(n['endLine']-n['line'],n['column']))
 return candidates[0] if candidates else None
cgroups={s:collections.defaultdict(list) for s in calls}
for s in calls:
 for c in calls[s]:cgroups[s][(c['file'],c['method'],c['path'])].append(c)
relations=[]
for key,oldrows in cgroups['before'].items():
 newrows=cgroups['after'].get(key,[])
 if len(oldrows)!=1 or len(newrows)!=1:
  unresolved.append({'kind':'frontend-call-ambiguity-or-removed-contract','key':key});continue
 old,new=oldrows[0],newrows[0];a,b=call_anchor('before',old),call_anchor('after',new)
 samefields=all(old.get(k)==new.get(k) for k in ['file','method','path','kind','source','methodConfidence'])
 sameanchor=a and b and a['owner']==b['owner'] and a['callee']==b['callee']
 if not(samefields and sameanchor):
  unresolved.append({'kind':'frontend-call-owner-or-semantics-changed','old':old,'new':new,'oldAnchor':a,'newAnchor':b});continue
 relations.append({'oldId':cid(old),'newId':cid(new),'file':old['file'],'method':old['method'],'path':old['path'],'source':old['source'],'methodConfidence':old['methodConfidence'],'oldLine':old['line'],'newLine':new['line'],'owner':a['owner'],'callee':a['callee'],'callImplementationTokensChanged':a['callTokenSha256']!=b['callTokenSha256'],'transferPass':False,'reviewScope':'Exact declaration lineage only; payload, deadlines, signal propagation, authorization, lease authority, side effects and response handling require fresh execution.'})
(O/'initial-unresolved.json').write_text(json.dumps({'uiRelations':len(ui),'callRelations':len(relations),'unresolved':unresolved},indent=2)+'\n')
assert len(relations)==18
registered_contract_ids={z['id'] for z in r['frontendContracts']}
occurrence_relations=[x for x in relations if x['oldId'] not in registered_contract_ids]
for x in occurrence_relations:
 x['registeredRepresentative']=[z['id'] for z in r['frontendContracts'] if z['method']==x['method'] and z['path']==x['path']]
 x['scope']='Actual source occurrence retained under globally deduplicated method/path contract; do not invent an independently registered entity.'
relations=[x for x in relations if x['oldId'] in registered_contract_ids]
assert len(relations)==17 and len(occurrence_relations)==1
ui_map={x['oldId']:x['newId'] for x in ui};call_map={x['oldId']:x['newId'] for x in relations};checkmap={old+'/'+kind:new+'/'+kind for old,new in ui_map.items() for kind in ['control-behavior','control-failure']}
unchanged={'pages':[x['id'] for x in r['pages']],'interactions':[x['id'] for x in r['interactions'] if x['id'] not in ui_map],'backendRoutes':[x['id'] for x in r['backendRoutes']],'frontendContracts':[x['id'] for x in r['frontendContracts'] if x['id'] not in call_map],'requiredChecks':[c['id'] for k in ['pages','interactions','backendRoutes'] for x in r[k] for c in x['requiredChecks'] if c['id'] not in checkmap],'businessSections':[pid+'/'+s['id'] for pid,p in plan['businessPageWork'].items() for s in p['businessSections']]}
# A relation keeps an old obligation alive without inventing a PASS for its new source identity.
workmap={**checkmap,**{old+'/consumer-contract':new+'/consumer-contract' for old,new in call_map.items()}}
workids={x['id'] for x in plan['workItems']};assert set(workmap)<=workids
unchanged['workItems']=sorted(workids-set(workmap))
summary={'oldAndCandidateInteractiveDeclarations':len(ui),'changedInteractionIds':sum(x['oldId']!=x['newId'] for x in ui),'changedHandlerTokenReviewRows':sum(x['namedHandlerImplementationTokensChanged'] for x in ui),'oldAndCandidateFrontendCallSites':len(relations)+len(occurrence_relations),'registeredChangedFrontendContracts':len(relations),'deduplicatedOccurrenceOnlyRelations':len(occurrence_relations),'changedFrontendCallIds':sum(x['oldId']!=x['newId'] for x in relations),'changedCallImplementationRows':sum(x['callImplementationTokensChanged'] for x in relations),'oldCheckObligationsWithLineage':len(checkmap),'oldWorkObligationsWithLineage':len(workmap),'unchangedSubjectCounts':{k:len(v) for k,v in unchanged.items()},'ambiguousOrUnresolvedRelations':len(unresolved),'predictedTotalControls':len(unchanged['interactions'])+len(ui),'predictedTotalCalls':len(unchanged['frontendContracts'])+len(relations),'predictedOldRequiredChecksRetained':len(unchanged['requiredChecks'])+len(checkmap),'predictedOldWorkItemsRetained':len(unchanged['workItems'])+len(workmap),'fullCandidateRegisterRegenerated':False,'noPassTransferred':True}
base={'schemaVersion':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRevision':inputs['sourceRevision'],'patchSha256':inputs['patchSha256'],'scope':'Exact two-source static declaration lineage for the proposed frontend patch; actual unchanged production extractors used. Not a full candidate registry or acceptance result. Validate against the final full actual candidate scan before freeze.','summary':summary,'interactionRelations':ui,'frontendContractRelations':relations,'deduplicatedOccurrenceRelations':occurrence_relations,'requiredCheckRelations':checkmap,'workItemRelations':workmap,'unresolved':unresolved,'sourceInputs':inputs,'productionReady':False}
(O/'declaration-relations.json').write_text(json.dumps(base,indent=2)+'\n');(O/'unchanged-identities.json').write_text(json.dumps({'scope':'Explicit identity relations for every old obligation outside the narrow changed subject lane; source-bound to5eb. No PASS transfer.','identities':unchanged},indent=2)+'\n')
print(json.dumps(summary,indent=2))
