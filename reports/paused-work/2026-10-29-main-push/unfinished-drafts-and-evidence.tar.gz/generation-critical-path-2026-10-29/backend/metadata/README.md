# Capability plan version — outside candidate

Based on source `5eb416a04021f66c9bfc8af93997ec9fe8a55e31`. No repository source changed. The pending main master remains frozen; integrate only after it finishes and is archived.

The actual Python `generation_capabilities()` metadata advertises `generation-plan-v2`, but `GenerationPlan.from_request` emits `generation-plan-v3`. The patch defines one `GENERATION_PLAN_VERSION` constant in the existing plan module and uses it for both actual plan construction and advertised metadata. It preserves the v3 payload, every request/model/route, and the explicit `runtime:not_probed`, `quality:not_evaluated` and `digital_gpu_exclusive:not_verified` claims.

No direct-Python aliases or owner-path additions are included. The earlier direct-alias proposal is withdrawn in the parent folder because the imported TS API already translates those routes before reaching Python.

Validation uses the actual metadata function/decorator through ASGI and the actual plan constructor, without importing full server startup. It has an explicit clean environment with inherited application/provider variables absent and socket connections denied. No model, training worker, provider call or renderer runs.

| Test | Pass criterion |
| --- | --- |
| `test_advertised_version_matches_actual_plans_for_all_supported_modalities` | Actual ASGI metadata200 advertises exactly the actual constructed text/content/image/audio/video/campaign plan version; explicit seed preserved. |
| `test_static_metadata_preserves_unverified_runtime_quality_and_detached_renderers` | Static metadata keeps unverified runtime/quality flags and serving status; detached renderer mutation cannot change future responses; no readiness/launch claim appears. |

The exact same suite against unchanged5eb source reproduces six failing modality subtests. Candidate: **2 methods and6 subtests pass**, raw JUnit8 tests,0 failures/errors/skips. Baseline failure XML/log, positive XML/log, exact commands/environment/source receipts and both original subject hashes are retained. The root complete source inventory remains unchanged during both controls.

After review/integration, use the existing prepared no-egress Python runner:

```sh
/path/to/prepared/python scripts/testing/run-python-suites.py \
  --python /path/to/prepared/python \
  --file external/maxcore/artifacts/ai-training-server/tests/test_generation_capability_version.py \
  --output /tmp/maxbooster-capability-version
```

The standard master discovers that canonical new test after it is added to Git. Run appropriate current-source plan/capability regressions and the complete master; this metadata fix grants no generation-availability, media-quality, page or production approval. `run-controls.py` reproduces the outside baseline/candidate only while root subject files are still the recorded5eb versions and the owned copied `candidate` subtree exists. The compact manifest retains proposed source files and exact patch without duplicating the13MB copied dependency tree.
