"""Actual generation alias admission without startup, provider calls or rendering.

The ASGI fixture retains production route decorators/request models, immutable
plan wrapper and private-owner middleware. The sole render-dispatch fixture
checks routing/identity/controls, not real artifact production or quality.
"""
import ast
import inspect
from pathlib import Path
import tempfile
from types import SimpleNamespace
import time
import unittest
from unittest.mock import Mock, patch

from ai_model.awareness import AwarenessUnavailable, bound_snapshot
from ai_model.generation.live_serving import LiveServingModel
from ai_model.generation.plan import active_plan
from ai_model.generation.owner import owned_path
import test_dedicated_media_http as media_http
from test_live_awareness_planner_http import fresh_snapshot

SERVER = Path(__file__).parents[1] / "server.py"
CONTENT_PATHS = ("/content/generate", "/api/content/generate")
VIDEO_PATHS = ("/api/generate-video", "/api/generate/video")


class GenerationRouteAliasAdmission(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.directory = self.enterContext(tempfile.TemporaryDirectory())
        self.snapshot = fresh_snapshot()
        self.engine = SimpleNamespace(current_snapshot=Mock(return_value=self.snapshot))
        self.enterContext(patch("ai_model.awareness.engine.get_engine", return_value=self.engine))
        self.enterContext(patch.dict(__import__("os").environ,
                                    {"PDIM_LOCAL_CHANNEL_TOKEN": media_http.PRIVATE_CHANNEL}))
        self.model = LiveServingModel()
        self.model.pin = Mock(wraps=self.model.pin)
        self.persist = Mock()
        # Existing genuine media fixture extracts production code, not a route
        # reimplementation. Point its parser at this test's matching checkout.
        with patch.object(media_http, "SERVER", SERVER):
            self.app, self.scope = media_http.actual_media_app(
                Path(self.directory), self.model, self.persist, lambda job: None)
        names = {"ContentRequest", "generate_content"}
        nodes = [node for node in ast.parse(SERVER.read_text()).body
                 if isinstance(node, (ast.ClassDef, ast.AsyncFunctionDef)) and node.name in names]
        self.assertEqual({node.name for node in nodes}, names)
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SERVER), "exec"), self.scope)

    async def post(self, path, body, **kwargs):
        result = await media_http.post_json(self.app, path, body, **kwargs)
        self.assertIsNone(active_plan.get())
        self.assertIsNone(self.scope["_request_job_owner"].get())
        with self.assertRaises(AwarenessUnavailable):
            bound_snapshot()
        return result

    def test_aliases_bind_identical_real_handlers_and_request_models(self):
        routes = {route.path: route for route in self.app.routes if hasattr(route, "dependant")}
        for paths, handler, model in [(CONTENT_PATHS, "generate_content", "ContentRequest"),
                                       (VIDEO_PATHS, "api_generate_video", "ApiGenerateVideoRequest")]:
            with self.subTest(paths=paths):
                self.assertTrue(all(path in routes for path in paths), "advertised alias must exist")
                self.assertIs(routes[paths[0]].endpoint, routes[paths[1]].endpoint)
                self.assertEqual(routes[paths[1]].endpoint.__name__, handler)
                self.assertIs(inspect.signature(routes[paths[1]].endpoint).parameters["req"].annotation, self.scope[model])
        content = self.scope["ContentRequest"](topic="My actual release")
        self.assertEqual(content.tone, "energetic")
        self.assertEqual(content.platform, "tiktok")

    async def test_content_minimal_documented_body_reaches_same_capability_failure(self):
        for path in CONTENT_PATHS:
            with self.subTest(path=path):
                status, result = await self.post(path, {"topic": "My actual release", "platform": "tiktok"})
                self.assertEqual(status, 503, result)
                self.assertIn("No operationally capable", result["detail"])
                self.assertNotIn("caption", result)
        self.assertEqual(self.model.pin.call_count, len(CONTENT_PATHS))
        self.persist.assert_not_called()

    async def test_content_alias_keeps_body_validation_and_generation_auth(self):
        for path in CONTENT_PATHS:
            with self.subTest(path=path):
                status, result = await self.post(path, {"platform": "tiktok"})
                self.assertEqual(status, 422, result)
                self.assertTrue(any(row["loc"] == ["body", "topic"] for row in result["detail"]))
                status, result = await self.post(path, {"topic": "My release"}, owner=None, credential=None)
                self.assertEqual(status, 401, result)
        self.model.pin.assert_not_called()
        self.persist.assert_not_called()

    async def test_both_video_paths_require_private_owner_before_capability(self):
        for path in VIDEO_PATHS:
            self.assertTrue(owned_path(path), "alias must keep the canonical media owner policy")
            for kwargs in ({"owner": None}, {"credential": "public-generation"}, {"peer": "203.0.113.7"}):
                with self.subTest(path=path, kwargs=kwargs):
                    status, result = await self.post(path, {"idea": "My release"}, **kwargs)
                    self.assertEqual(status, 403, result)
        self.engine.current_snapshot.assert_not_called()
        self.model.pin.assert_not_called()
        self.persist.assert_not_called()

    async def test_video_alias_keeps_unavailable_semantic_engine_as503(self):
        for path in VIDEO_PATHS:
            with self.subTest(path=path):
                status, result = await self.post(path, {"idea": "My release", "platform": "tiktok"})
                self.assertEqual(status, 503, result)
                self.assertIn("No operationally capable", result["detail"])
                self.assertNotIn("url", result)
        self.assertEqual(self.model.pin.call_count, len(VIDEO_PATHS))
        self.persist.assert_not_called()

    async def test_video_alias_keeps_expired_and_missing_awareness_fail_closed(self):
        for snapshot in (None, fresh_snapshot(time.time() - 1000)):
            self.engine.current_snapshot.return_value = snapshot
            for path in VIDEO_PATHS:
                with self.subTest(path=path, has_snapshot=snapshot is not None):
                    status, result = await self.post(path, {"idea": "My release", "dedicated_controls": {}})
                    self.assertEqual(status, 503, result)
                    self.assertIn("Live awareness unavailable", result["detail"])
        self.model.pin.assert_not_called()
        self.persist.assert_not_called()

    async def test_video_alias_preserves_input_validation_before_dispatch(self):
        for path in VIDEO_PATHS:
            for body in ({"dedicated_controls": {}}, {"idea": "Release", "dedicated_controls": []}):
                with self.subTest(path=path, body=body):
                    status, result = await self.post(path, body)
                    self.assertEqual(status, 422, result)
        self.model.pin.assert_not_called()
        self.persist.assert_not_called()

    async def test_video_alias_routes_explicit_controls_and_owner_to_same_render_dispatch(self):
        calls = []
        async def in_thread(callback):
            return callback()
        self.scope["_in_thread"] = in_thread
        def render(modality, controls, path, **kwargs):
            plan = active_plan.get()
            self.assertIsNotNone(plan)
            calls.append((modality, controls, kwargs["owner_id"], plan.to_dict()))
            return {"url": "/api/storage/file/owner-a/dispatch-fixture.mp4", "job_id": kwargs["job_id"],
                    "status": "completed", "success": True,
                    "capability": {"renderer": "dispatch-only-fixture", "trained": False},
                    "validation": {"status": "dispatch_fixture_only", "artifact_validated": False}}
        controls = {"duration_sec": .25, "width": 128, "height": 96, "fps": 8}
        with patch("ai_model.generation.dedicated.render", render):
            for path in VIDEO_PATHS:
                with self.subTest(path=path):
                    status, result = await self.post(path, {"idea": "My release", "seed": 12,
                        "dedicated_controls": controls, "owner_id": "body-spoof", "user_id": "body-spoof"})
                    self.assertEqual(status, 200, result)
                    self.assertEqual(result["snapshot_id"], self.snapshot.id)
                    self.assertFalse(result["checkpoint_inference"])
                    self.assertEqual(result["generation_plan"]["checkpoint"], "")
                    self.assertEqual(result["source"], "dispatch-only-fixture")
        self.assertEqual(len(calls), len(VIDEO_PATHS))
        for modality, applied, owner, plan in calls:
            self.assertEqual((modality, applied, owner), ("video", controls, "owner-a"))
            self.assertEqual(plan["snapshot_id"], self.snapshot.id)
        self.model.pin.assert_not_called()
        self.persist.assert_not_called()


if __name__ == "__main__":
    unittest.main()
