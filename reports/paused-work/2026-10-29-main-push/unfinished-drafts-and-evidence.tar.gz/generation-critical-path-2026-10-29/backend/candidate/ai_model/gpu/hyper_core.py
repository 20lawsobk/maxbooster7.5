from __future__ import annotations
import os
import time
import threading
import numpy as np
from enum import Enum, auto
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from ai_model.gpu.digital_gpu import (
    GPUError, ShapeError, SIMDCore, VRAM
)
from ai_model.gpu.native.kernels import get_native_kernels
from ai_model.gpu.sizing import hyper_gpu_sizing

# Numerics-reference switch: when set, mixed-precision GEMMs round operands to
# bit-level FP16 before the FP32-accumulate product (slower on CPU; BLAS has no
# half GEMM). Default off = dispatch straight to the FP32 BLAS SGEMM.
_EMULATE_FP16 = os.environ.get("MAXCORE_EMULATE_FP16", "") == "1"

# Module-level constant for GELU — computed once at import, not per-call.
# np.float32 keeps the entire GELU expression in float32, preventing NumPy from
# silently upcasting to float64 when mixed with Python float literals.
_GELU_C = np.float32(np.sqrt(2.0 / np.pi))  # ≈ 0.7978845608


class PrecisionMode(Enum):
    FP32 = auto()
    FP16 = auto()
    BF16 = auto()
    MIXED = auto()


class HyperOpCode(Enum):
    GEMM = auto()
    ADD = auto()
    SOFTMAX = auto()
    ATTENTION = auto()
    GEMM_BIAS_RELU = auto()
    FLASH_ATTENTION = auto()
    CONV2D = auto()
    CONV3D = auto()
    LAYER_NORM = auto()
    GELU = auto()
    SILU = auto()
    TRANSPOSE = auto()
    CONCAT = auto()
    BATCH_NORM = auto()
    RESIDUAL_ADD = auto()
    MIXED_PRECISION_GEMM = auto()
    TENSOR_CORE_GEMM = auto()
    FUSED_ATTENTION_NORM = auto()
    DEPTHWISE_CONV = auto()
    GROUPED_GEMM = auto()


@dataclass
class TensorCoreUnit:
    m_tile: int = 16
    n_tile: int = 16
    k_tile: int = 16
    throughput_multiplier: float = 8.0
    precision: PrecisionMode = PrecisionMode.MIXED
    ops_executed: int = 0
    total_flops: float = 0.0

    def matmul(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        # The tensor core issues the full tile grid in a single vectorized SIMD
        # dispatch (BLAS-backed), not a Python-level tile loop. Tiling is a
        # hardware detail of how the systolic array streams the operands; the
        # numerical result is identical to the full-matrix product, so we execute
        # it as one fused GEMM to run at the hardware's real throughput.
        M, K = A.shape
        K2, N = B.shape
        C = np.matmul(A.astype(np.float32, copy=False),
                      B.astype(np.float32, copy=False), dtype=np.float32)
        self.ops_executed += 1
        self.total_flops += 2.0 * M * N * K
        return C

    def mixed_precision_matmul(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        # Mixed precision on real tensor cores means reduced-precision multiply
        # with FP32 accumulate — a throughput optimization, never a slowdown.
        # On this host the fastest compiled kernel is the FP32 BLAS SGEMM
        # (BLAS has no half-precision GEMM; emulating FP16 in NumPy costs 2x:
        # down-cast copies + a non-BLAS generic loop). FP32 multiply/accumulate
        # is a strict accuracy superset of FP16-multiply/FP32-accumulate (same
        # class as TF32-mode training GEMMs on current flagship GPUs), so we
        # dispatch straight to the SGEMM. Set MAXCORE_EMULATE_FP16=1 to force
        # bit-level FP16 operand rounding as a numerics reference.
        M, K = A.shape
        K2, N = B.shape
        if _EMULATE_FP16:
            A_op: np.ndarray = A.astype(np.float16)
            B_op: np.ndarray = B.astype(np.float16)
            C = np.matmul(A_op, B_op, dtype=np.float32)
        else:
            C = np.matmul(A.astype(np.float32, copy=False),
                          B.astype(np.float32, copy=False), dtype=np.float32)
        self.ops_executed += 1
        self.total_flops += 2.0 * M * N * K * self.throughput_multiplier
        return C

    def status(self) -> dict:
        return {
            "tile_shape": f"{self.m_tile}x{self.n_tile}x{self.k_tile}",
            "throughput_multiplier": self.throughput_multiplier,
            "precision": self.precision.name,
            "ops_executed": self.ops_executed,
            "total_tflops": round(self.total_flops / 1e12, 4),
        }


@dataclass
class MemoryPool:
    pool_size_bytes: int = 512 * 1024 * 1024
    block_size: int = 4096
    _allocated: Dict[int, np.ndarray] = field(default_factory=dict)
    _free_list: List[int] = field(default_factory=list)
    _next_id: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)
    _peak_bytes: int = 0
    _current_bytes: int = 0
    _alloc_count: int = 0
    _reuse_count: int = 0
    # Shape-keyed pool of live numpy arrays waiting for reuse.
    # Key: (shape_tuple, dtype_str) → list of zeroed arrays with that shape.
    # Populated by free(); drained by alloc() when a matching shape exists.
    # This eliminates the GC pressure and mmap syscall overhead of creating a
    # new np.zeros() on every alloc() call (the previous _free_list only stored
    # handle IDs of already-deleted arrays, so it was never actually consulted).
    _shape_pool: Dict = field(default_factory=dict)

    def alloc(self, shape: Tuple, dtype=np.float32) -> Tuple[int, np.ndarray]:
        with self._lock:
            nbytes = int(np.prod(shape)) * np.dtype(dtype).itemsize
            pool_key = (tuple(shape), np.dtype(dtype).str)
            recycled = self._shape_pool.get(pool_key)
            if recycled:
                arr = recycled.pop()
                arr.fill(0)   # clear before reuse (same semantics as np.zeros)
                self._reuse_count += 1
            else:
                arr = np.zeros(shape, dtype=dtype)
            mid = self._next_id
            self._next_id += 1
            self._allocated[mid] = arr
            self._current_bytes += nbytes
            self._alloc_count += 1
            if self._current_bytes > self._peak_bytes:
                self._peak_bytes = self._current_bytes
            return mid, arr

    def free(self, mid: int):
        with self._lock:
            if mid in self._allocated:
                arr = self._allocated[mid]
                nbytes = arr.nbytes
                # Return array to the shape pool so the next alloc with the
                # same (shape, dtype) can reuse it without a new allocation.
                pool_key = (arr.shape, arr.dtype.str)
                bucket = self._shape_pool.setdefault(pool_key, [])
                bucket.append(arr)
                self._current_bytes -= nbytes
                del self._allocated[mid]
                self._free_list.append(mid)

    def get(self, mid: int) -> np.ndarray:
        with self._lock:
            if mid not in self._allocated:
                raise GPUError(f"MemoryPool: invalid handle {mid}")
            return self._allocated[mid]

    def flush(self):
        with self._lock:
            total_freed = self._current_bytes
            self._allocated.clear()
            self._free_list.clear()
            self._current_bytes = 0
            return total_freed

    def status(self) -> dict:
        with self._lock:
            return {
                "pool_size_mb": round(self.pool_size_bytes / (1024 * 1024), 2),
                "current_mb": round(self._current_bytes / (1024 * 1024), 4),
                "peak_mb": round(self._peak_bytes / (1024 * 1024), 4),
                "active_allocations": len(self._allocated),
                "total_allocs": self._alloc_count,
                "reuse_count": self._reuse_count,
            }


class HyperSIMDCore(SIMDCore):
    def __init__(
        self,
        lanes: int | None = None,
        tile_m: int = 128,
        tile_n: int = 128,
        tile_k: int = 128,
        tensor_cores: int | None = None,
        precision: PrecisionMode = PrecisionMode.MIXED,
    ):
        # Default to the shared host-capacity-derived sizing (ai_model/gpu/sizing.py)
        # unless the caller explicitly overrides lanes/tensor_cores. This is the
        # root primitive every HyperGPU/HyperGPUBackend construction path bottoms
        # out at, so defaulting here closes off any remaining bypass.
        if lanes is None or tensor_cores is None:
            _default_lanes, _default_tensor_cores = hyper_gpu_sizing()
            lanes = _default_lanes if lanes is None else lanes
            tensor_cores = _default_tensor_cores if tensor_cores is None else tensor_cores
        super().__init__(lanes=lanes, tile_m=tile_m, tile_n=tile_n, tile_k=tile_k)
        self.precision = precision
        self.tensor_core_units = [
            TensorCoreUnit(
                m_tile=16, n_tile=16, k_tile=16,
                throughput_multiplier=8.0,
                precision=precision,
            )
            for _ in range(tensor_cores)
        ]
        self._mem_pool = MemoryPool()
        self._profile_data: Dict[str, float] = {}
        self._total_ops = 0
        # Compiled native SIMD kernels (gelu, silu, layernorm_rows, etc.).
        # These are the GPU's own fused compute primitives — compiled C with
        # AVX-512 + OpenMP, with a numpy never-raise fallback if gcc is absent.
        # Loaded once at construction so all kernel calls go through the GPU
        # stack rather than ad-hoc numpy expressions.
        self._native = get_native_kernels()

    def _select_tensor_core(self) -> TensorCoreUnit:
        return min(self.tensor_core_units, key=lambda tc: tc.ops_executed)

    def tensor_core_gemm(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        if A.ndim != 2 or B.ndim != 2:
            raise ShapeError("tensor_core_gemm expects 2D matrices")
        if A.shape[1] != B.shape[0]:
            raise ShapeError(f"Incompatible shapes: {A.shape} x {B.shape}")
        tc = self._select_tensor_core()
        self._total_ops += 1
        return tc.matmul(A.astype(np.float32, copy=False),
                         B.astype(np.float32, copy=False))

    def batched_gemm(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """Batched GEMM over leading dims ([..., M, K] x [..., K, N]) as one
        fused vectorized dispatch on the tensor cores (BLAS-backed)."""
        if A.ndim < 2 or B.ndim < 2:
            raise ShapeError("batched_gemm expects >=2D operands")
        if A.shape[-1] != B.shape[-2]:
            raise ShapeError(f"Incompatible shapes: {A.shape} x {B.shape}")
        tc = self._select_tensor_core()
        self._total_ops += 1
        C = np.matmul(A.astype(np.float32, copy=False),
                      B.astype(np.float32, copy=False), dtype=np.float32)
        batch = int(np.prod(A.shape[:-2])) if A.ndim > 2 else 1
        tc.ops_executed += 1
        tc.total_flops += 2.0 * batch * A.shape[-2] * B.shape[-1] * A.shape[-1]
        return C

    def mixed_precision_gemm(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        if A.ndim != 2 or B.ndim != 2:
            raise ShapeError("mixed_precision_gemm expects 2D")
        if A.shape[1] != B.shape[0]:
            raise ShapeError(f"Incompatible shapes: {A.shape} x {B.shape}")
        tc = self._select_tensor_core()
        self._total_ops += 1
        return tc.mixed_precision_matmul(A, B)

    def softmax(self, X: np.ndarray, axis: int = -1) -> np.ndarray:
        """Override base SIMDCore.softmax to route through the native SIMD kernel
        for the common last-axis case.  Falls back to the base numpy implementation
        for any other axis (rare in practice)."""
        if axis == -1 or axis == X.ndim - 1:
            Xf = np.ascontiguousarray(X.astype(np.float32, copy=False))
            orig = Xf.shape
            cols = orig[-1]
            rows = int(np.prod(orig[:-1])) if Xf.ndim > 1 else 1
            out2d = self._native.softmax_rows(Xf.reshape(rows, cols))
            self._total_ops += 1
            return out2d.reshape(orig)
        # Non-last axis: delegate to base SIMDCore numpy implementation.
        self._total_ops += 1
        return super().softmax(X, axis=axis)

    def flash_attention(
        self, Q: np.ndarray, K: np.ndarray, V: np.ndarray,
        causal: bool = False, block_size: int = 64,
    ) -> np.ndarray:
        if Q.ndim != 3:
            raise ShapeError("flash_attention expects [B, T, D]")
        B, Tq, D = Q.shape
        Tk = K.shape[1]
        if V.shape[1] != Tk:
            raise ShapeError(f"flash_attention: K length {Tk} != V length {V.shape[1]}")

        Qf: np.ndarray = np.ascontiguousarray(Q.astype(np.float32, copy=False))
        Kf: np.ndarray = np.ascontiguousarray(K.astype(np.float32, copy=False))
        Vf: np.ndarray = np.ascontiguousarray(V.astype(np.float32, copy=False))
        scale = np.float32(1.0 / np.sqrt(D))

        # ── Decode fast-path: Tq == 1 ─────────────────────────────────────────
        # During every KV-cache decode step the query sequence length is exactly
        # 1 — there is no tiling work to do.  Skip the Python tile loop entirely
        # and dispatch two single batched GEMMs + one native SIMD softmax.
        # This is the hot path called hundreds of times per generation.
        if Tq == 1:
            KT = np.ascontiguousarray(Kf.transpose(0, 2, 1))   # [B, D, Tk]
            scores = self.batched_gemm(Qf, KT) * scale           # [B, 1, Tk]
            if causal:
                # With Tq=1, every key position ≤ 0 is visible (causal mask is
                # trivially satisfied for the last query position).
                pass
            # Softmax over key dimension via native SIMD kernel
            scores_2d = scores.reshape(B, Tk)
            try:
                probs_2d = self._native.softmax_rows(scores_2d)
            except Exception:
                e = np.exp(scores_2d - scores_2d.max(axis=-1, keepdims=True))
                probs_2d = e / e.sum(axis=-1, keepdims=True)
            probs = probs_2d.reshape(B, 1, Tk)
            out = self.batched_gemm(probs, Vf)                   # [B, 1, D]
            self._total_ops += 1
            return out

        # ── Prefill path: tiled online softmax (handles any Tq) ───────────────
        bs = max(1, min(int(block_size), Tk))
        # Adaptive block widening for long sequences — halves Python loop count.
        if Tk >= 256 and bs < 128:
            bs = min(128, Tk)

        O = np.zeros((B, Tq, D), dtype=np.float32)
        m = np.full((B, Tq), -np.inf, dtype=np.float32)
        l = np.zeros((B, Tq), dtype=np.float32)

        for start in range(0, Tk, bs):
            end = min(start + bs, Tk)
            K_block_T = np.ascontiguousarray(Kf[:, start:end, :].transpose(0, 2, 1))
            scores = self.batched_gemm(Qf, K_block_T) * scale   # [B, Tq, blk]
            if causal:
                qi = np.arange(Tq, dtype=np.int32).reshape(-1, 1)
                kj = np.arange(start, end, dtype=np.int32).reshape(1, -1)
                scores = np.where(kj > qi, np.float32(-1e9), scores)

            m_new = np.maximum(m, scores.max(axis=-1))
            exp_scores = np.exp(scores - m_new[:, :, None])
            exp_m_diff = np.exp(m - m_new)
            l = exp_m_diff * l + exp_scores.sum(axis=-1)
            V_block = np.ascontiguousarray(Vf[:, start:end, :])
            O = exp_m_diff[:, :, None] * O + self.batched_gemm(exp_scores, V_block)
            m = m_new

        out = O / l[:, :, None]
        self._total_ops += 1
        return out

    def conv2d(
        self, X: np.ndarray, W: np.ndarray,
        stride: int = 1, padding: int = 0,
    ) -> np.ndarray:
        if X.ndim != 4:
            raise ShapeError("conv2d expects [B, C_in, H, W]")
        if W.ndim != 4:
            raise ShapeError("conv2d kernel expects [C_out, C_in, kH, kW]")

        B, C_in, H, Wid = X.shape
        C_out, C_in_k, kH, kW = W.shape
        if C_in != C_in_k:
            raise ShapeError(f"Channel mismatch: input {C_in} vs kernel {C_in_k}")

        if padding > 0:
            X = np.pad(X, ((0, 0), (0, 0), (padding, padding), (padding, padding)))
            _, _, H, Wid = X.shape

        H_out = (H - kH) // stride + 1
        W_out = (Wid - kW) // stride + 1

        # im2col via stride tricks: build all receptive-field patches as a
        # strided view, then dispatch a single 2-D tensor_core_gemm by
        # collapsing the batch dimension into the spatial dimension.
        # [B, K, P] → transpose(1,0,2) → [K, B, P] → reshape → [K, B*P]
        # so one GPU GEMM handles the entire batch in a single dispatch.
        X = np.ascontiguousarray(X)
        s = X.strides
        K_dim = C_in * kH * kW
        P = H_out * W_out
        shape = (B, C_in, kH, kW, H_out, W_out)
        strides = (s[0], s[1], s[2], s[3], s[2] * stride, s[3] * stride)
        patches = np.lib.stride_tricks.as_strided(X, shape=shape, strides=strides)
        cols = patches.reshape(B, K_dim, P)
        W_col = W.reshape(C_out, K_dim).astype(np.float32, copy=False)
        cols_flat = np.ascontiguousarray(cols.transpose(1, 0, 2)).reshape(K_dim, B * P)
        # [C_out, K] @ [K, B*P] → [C_out, B*P] — one TensorCore dispatch
        out_flat = self.tensor_core_gemm(W_col, cols_flat)
        out = out_flat.reshape(C_out, B, H_out, W_out).transpose(1, 0, 2, 3)

        self._total_ops += 1
        return out.astype(X.dtype, copy=False)

    def conv3d(
        self, X: np.ndarray, W: np.ndarray,
        stride: Tuple[int, int, int] = (1, 1, 1),
        padding: Tuple[int, int, int] = (0, 0, 0),
    ) -> np.ndarray:
        if X.ndim != 5:
            raise ShapeError("conv3d expects [B, C_in, D, H, W]")
        if W.ndim != 5:
            raise ShapeError("conv3d kernel expects [C_out, C_in, kD, kH, kW]")

        B, C_in, D, H, Wid = X.shape
        C_out, C_in_k, kD, kH, kW = W.shape

        if C_in != C_in_k:
            raise ShapeError(f"Channel mismatch: {C_in} vs {C_in_k}")

        pd, ph, pw = padding
        sd, sh, sw = stride

        if any(p > 0 for p in padding):
            X = np.pad(X, ((0, 0), (0, 0), (pd, pd), (ph, ph), (pw, pw)))
            _, _, D, H, Wid = X.shape

        D_out = (D - kD) // sd + 1
        H_out = (H - kH) // sh + 1
        W_out = (Wid - kW) // sw + 1

        # 3-D im2col via stride tricks + single tensor_core_gemm.
        # Collapse batch into spatial: [B, K, P] → [K, B*P] → one GPU GEMM.
        X = np.ascontiguousarray(X)
        s = X.strides
        K_dim = C_in * kD * kH * kW
        P = D_out * H_out * W_out
        shape = (B, C_in, kD, kH, kW, D_out, H_out, W_out)
        strides = (s[0], s[1], s[2], s[3], s[4],
                   s[2] * sd, s[3] * sh, s[4] * sw)
        patches = np.lib.stride_tricks.as_strided(X, shape=shape, strides=strides)
        cols = patches.reshape(B, K_dim, P)
        W_col = W.reshape(C_out, K_dim).astype(np.float32, copy=False)
        cols_flat = np.ascontiguousarray(cols.transpose(1, 0, 2)).reshape(K_dim, B * P)
        # [C_out, K] @ [K, B*P] → [C_out, B*P] — one TensorCore dispatch
        out_flat = self.tensor_core_gemm(W_col, cols_flat)
        out = out_flat.reshape(C_out, B, D_out, H_out, W_out).transpose(1, 0, 2, 3, 4)

        self._total_ops += 1
        return out.astype(X.dtype, copy=False)

    def layer_norm(
        self, X: np.ndarray, gamma: np.ndarray, beta: np.ndarray,
        eps: float = 1e-5,
    ) -> np.ndarray:
        # Route through the compiled native SIMD layernorm_rows kernel — a
        # fused single-pass AVX-512 + OpenMP implementation that is the GPU
        # stack's own compute primitive for normalization.  layernorm_rows
        # expects [rows, cols] 2-D input, so we reshape, run, and restore.
        Xf = X.astype(np.float32, copy=False)
        orig_shape = Xf.shape
        cols = orig_shape[-1]
        rows = int(np.prod(orig_shape[:-1])) if Xf.ndim > 1 else 1
        X2d = Xf.reshape(rows, cols)
        out2d = self._native.layernorm_rows(
            X2d,
            gamma.astype(np.float32, copy=False).ravel(),
            beta.astype(np.float32, copy=False).ravel(),
            eps=eps,
        )
        self._total_ops += 1
        return out2d.reshape(orig_shape)

    def batch_norm(
        self, X: np.ndarray, gamma: np.ndarray, beta: np.ndarray,
        running_mean: Optional[np.ndarray] = None,
        running_var: Optional[np.ndarray] = None,
        training: bool = True, eps: float = 1e-5, momentum: float = 0.1,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        if X.ndim == 4:
            axis: tuple[int, ...] = (0, 2, 3)
        elif X.ndim == 2:
            axis = (0,)
        else:
            axis = tuple(i for i in range(X.ndim) if i != 1) if X.ndim > 1 else (0,)

        if training:
            mean = X.mean(axis=axis, keepdims=True)
            var = X.var(axis=axis, keepdims=True)
            X_norm = (X - mean) / np.sqrt(var + eps)

            mean_sq = mean.squeeze()
            var_sq = var.squeeze()
            if running_mean is not None:
                running_mean = (1 - momentum) * running_mean + momentum * mean_sq
            else:
                running_mean = mean_sq
            if running_var is not None:
                running_var = (1 - momentum) * running_var + momentum * var_sq
            else:
                running_var = var_sq
        else:
            if running_mean is None or running_var is None:
                raise GPUError("batch_norm: running stats required in eval mode")
            shape = [1] * X.ndim
            shape[1] = -1
            mean = running_mean.reshape(shape)
            var = running_var.reshape(shape)
            X_norm = (X - mean) / np.sqrt(var + eps)

        g_shape = [1] * X.ndim
        g_shape[1] = -1
        out = gamma.reshape(g_shape) * X_norm + beta.reshape(g_shape)
        self._total_ops += 1
        return out, running_mean, running_var

    def gelu(self, X: np.ndarray) -> np.ndarray:
        # Route through the compiled native SIMD gelu kernel — a fused
        # AVX-512 loop using a Cephes-style polynomial tanh that auto-
        # vectorizes and never materializes the intermediate cube or inner
        # product as separate numpy temporaries.  Shape-agnostic: NativeKernels
        # flattens to a contiguous float* and restores the original shape.
        out = self._native.gelu(X.astype(np.float32, copy=False))
        self._total_ops += 1
        return out.reshape(X.shape)

    def silu(self, X: np.ndarray) -> np.ndarray:
        # Route through the compiled native SIMD silu kernel — a fused
        # x/(1+exp(-x)) loop with the same Cephes fast_expf used by gelu,
        # eliminating the two-pass numpy sigmoid (exp + division).
        out = self._native.silu(X.astype(np.float32, copy=False))
        self._total_ops += 1
        return out.reshape(X.shape)

    # ── Fused linear + activation ────────────────────────────────────────────
    # Each feedforward block calls linear (GEMM) then an activation function as
    # two separate kernel dispatches.  These fused helpers collapse both into a
    # single Python call — one GEMM dispatch followed immediately by an in-place
    # native SIMD activation, with no intermediate Python allocation between
    # them.  The output array of the GEMM is passed directly into the activation
    # kernel, keeping the data hot in L2/L3 cache.

    def linear_gelu(
        self,
        X: np.ndarray,
        W: np.ndarray,
        bias: np.ndarray | None = None,
    ) -> np.ndarray:
        """Fused matmul(X, Wᵀ) + optional bias + GeLU — single Python call."""
        Xf = np.ascontiguousarray(X.astype(np.float32, copy=False))
        Wf = np.ascontiguousarray(W.astype(np.float32, copy=False))
        # GEMM: X @ Wᵀ  → [..., out_features]
        out = self.tensor_core_gemm(Xf.reshape(-1, Xf.shape[-1]),
                                    Wf.T).reshape(*Xf.shape[:-1], Wf.shape[0])
        if bias is not None:
            out += bias.astype(np.float32, copy=False)
        # In-place native SIMD GeLU — data stays hot in cache
        out_flat = self._native.gelu(np.ascontiguousarray(out.reshape(-1)))
        self._total_ops += 2   # GEMM + activation
        return out_flat.reshape(out.shape)

    def linear_silu(
        self,
        X: np.ndarray,
        W: np.ndarray,
        bias: np.ndarray | None = None,
    ) -> np.ndarray:
        """Fused matmul(X, Wᵀ) + optional bias + SiLU — single Python call."""
        Xf = np.ascontiguousarray(X.astype(np.float32, copy=False))
        Wf = np.ascontiguousarray(W.astype(np.float32, copy=False))
        out = self.tensor_core_gemm(Xf.reshape(-1, Xf.shape[-1]),
                                    Wf.T).reshape(*Xf.shape[:-1], Wf.shape[0])
        if bias is not None:
            out += bias.astype(np.float32, copy=False)
        out_flat = self._native.silu(np.ascontiguousarray(out.reshape(-1)))
        self._total_ops += 2
        return out_flat.reshape(out.shape)

    def linear_relu(
        self,
        X: np.ndarray,
        W: np.ndarray,
        bias: np.ndarray | None = None,
    ) -> np.ndarray:
        """Fused matmul(X, Wᵀ) + optional bias + ReLU — single Python call."""
        Xf = np.ascontiguousarray(X.astype(np.float32, copy=False))
        Wf = np.ascontiguousarray(W.astype(np.float32, copy=False))
        out = self.tensor_core_gemm(Xf.reshape(-1, Xf.shape[-1]),
                                    Wf.T).reshape(*Xf.shape[:-1], Wf.shape[0])
        if bias is not None:
            out += bias.astype(np.float32, copy=False)
        out_flat = np.maximum(out.reshape(-1), 0.0, dtype=np.float32)
        self._total_ops += 2
        return out_flat.reshape(out.shape)

    def grouped_gemm(
        self, A_list: List[np.ndarray], B_list: List[np.ndarray],
    ) -> List[np.ndarray]:
        if len(A_list) != len(B_list):
            raise ShapeError("grouped_gemm: mismatched group count")
        if not A_list:
            self._total_ops += 1
            return []
        # When every group shares the same shape we can stack the operands and
        # dispatch a single batched GEMM — one BLAS call, no Python per-group
        # loop.  The per-group tensor_core_gemm loop was O(G) Python iterations
        # each carrying interpreter + time.perf_counter overhead.
        shapes_uniform = (
            all(A.shape == A_list[0].shape for A in A_list) and
            all(B.shape == B_list[0].shape for B in B_list)
        )
        if shapes_uniform:
            A_stack = np.stack([A.astype(np.float32, copy=False) for A in A_list])
            B_stack = np.stack([B.astype(np.float32, copy=False) for B in B_list])
            # Route through the GPU's own batched_gemm — runs through
            # TensorCoreUnit op accounting and stays in the GPU stack.
            C_stack = self.batched_gemm(A_stack, B_stack)  # [G, M, N]
            results = [C_stack[i] for i in range(len(A_list))]
        else:
            # Heterogeneous shapes: fall back to per-group tensor-core dispatch.
            results = [self.tensor_core_gemm(A, B) for A, B in zip(A_list, B_list)]
        self._total_ops += 1
        return results

    def fused_attention_norm(
        self, Q: np.ndarray, K: np.ndarray, V: np.ndarray,
        gamma: np.ndarray, beta: np.ndarray,
        causal: bool = False, eps: float = 1e-5,
    ) -> np.ndarray:
        attn_out = self.flash_attention(Q, K, V, causal=causal)
        self._total_ops += 1
        return self.layer_norm(attn_out, gamma, beta, eps=eps)

    def status(self) -> dict:
        tc_status = [tc.status() for tc in self.tensor_core_units]
        total_tc_flops = sum(tc.total_flops for tc in self.tensor_core_units)
        return {
            "lanes": self.lanes,
            "tile_shape": f"{self.tile_m}x{self.tile_n}x{self.tile_k}",
            "precision": self.precision.name,
            "tensor_cores": len(self.tensor_core_units),
            "tensor_core_details": tc_status,
            "total_tensor_core_tflops": round(total_tc_flops / 1e12, 6),
            "memory_pool": self._mem_pool.status(),
            "total_ops_executed": self._total_ops,
        }


class HyperVRAM(VRAM):
    def __init__(self, capacity_bytes: int = 0):
        super().__init__()
        self.capacity_bytes = capacity_bytes
        self._peak_bytes = 0
        self._lock = threading.Lock()

    def alloc(self, array: np.ndarray) -> int:
        with self._lock:
            if self.capacity_bytes > 0:
                current = sum(a.nbytes for a in self._store.values())
                if current + array.nbytes > self.capacity_bytes:
                    raise GPUError(
                        f"HyperVRAM OOM: {current + array.nbytes} > capacity {self.capacity_bytes}"
                    )
            hid = super().alloc(array)
            current = sum(a.nbytes for a in self._store.values())
            if current > self._peak_bytes:
                self._peak_bytes = current
            return hid

    def free(self, hid: int):
        with self._lock:
            super().free(hid)

    def flush(self):
        with self._lock:
            self._store.clear()
            self._meta.clear()

    @property
    def used_bytes(self) -> int:
        return sum(a.nbytes for a in self._store.values())

    @property
    def peak_bytes(self) -> int:
        return self._peak_bytes

    def status(self) -> dict:
        return {
            "capacity_mb": round(self.capacity_bytes / (1024 * 1024), 2) if self.capacity_bytes > 0 else "unlimited",
            "used_mb": round(self.used_bytes / (1024 * 1024), 4),
            "peak_mb": round(self._peak_bytes / (1024 * 1024), 4),
            "handles": len(self._store),
        }


class HyperGPU:
    def __init__(
        self,
        lanes: int | None = None,
        tensor_cores: int | None = None,
        precision: PrecisionMode = PrecisionMode.MIXED,
        vram_capacity: int = 0,
        tile_size: int = 128,
        silicon=None,
    ):
        # lanes/tensor_cores default to None so HyperSIMDCore resolves the
        # shared host-capacity-derived sizing itself unless overridden here.
        self.core = HyperSIMDCore(
            lanes=lanes,
            tile_m=tile_size, tile_n=tile_size, tile_k=tile_size,
            tensor_cores=tensor_cores,
            precision=precision,
        )
        self.vram = HyperVRAM(capacity_bytes=vram_capacity)
        self.precision = precision
        self._created_at = time.time()
        self._total_compute_ms = 0.0
        self._lock = threading.Lock()
        self._training_ops = 0
        # Optional MaxCoreSilicon performance model (estimates only; never alters
        # results or speed). See ai_model/gpu/silicon_model.py.
        self.silicon = silicon

    def _model(self, kind: str, flops: float, kv_size: float = 0.0,
               bytes_moved: float = 0.0, precision: str = "fp16") -> None:
        if self.silicon is not None:
            try:
                self.silicon.model_op(kind, flops, kv_size=kv_size,
                                     bytes_moved=bytes_moved, precision=precision)
            except Exception:
                # Architectural estimates must never abort real execution.
                import logging
                logging.getLogger(__name__).exception("Silicon telemetry failed")

    def silicon_report(self):
        return self.silicon.report() if self.silicon is not None else None

    def _record_op(self, op_name: str, flops: int, simulated_ms: float):
        with self._lock:
            self.core._total_ops += 1
            self._training_ops += 1
            if self.core.tensor_core_units:
                self.core.tensor_core_units[0].total_flops += float(flops)
            self._total_compute_ms += simulated_ms

    @staticmethod
    def _pocket():
        from ai_model.maxcore.pdim.pocket_accelerator import get_pocket_accelerator
        return get_pocket_accelerator()

    def gemm(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        t0 = time.time()
        A32: np.ndarray = A.astype(np.float32, copy=False)
        B32: np.ndarray = B.astype(np.float32, copy=False)
        result, _src = self._pocket().accelerate(
            "hyper_gemm", (A32, B32), 2.0 * float(A32.size) * float(B32.shape[-1]),
            lambda: self.core.tensor_core_gemm(A32, B32))
        self._model("gemm", 2.0 * float(A32.size) * float(B32.shape[-1]),
                    bytes_moved=A32.nbytes + B32.nbytes)
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def mixed_gemm(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        t0 = time.time()
        result, _src = self._pocket().accelerate(
            "hyper_mixed", (A, B), 2.0 * float(A.size) * float(B.shape[-1]),
            lambda: self.core.mixed_precision_gemm(A, B),
            extra_key=f"|fp16={_EMULATE_FP16}")
        self._model("gemm", 2.0 * float(A.size) * float(B.shape[-1]),
                    bytes_moved=A.nbytes + B.nbytes, precision="fp16")
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def gemm_batched(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        t0 = time.time()
        result, _src = self._pocket().accelerate(
            "hyper_gemm_batched", (A, B),
            2.0 * float(A.size) * float(B.shape[-1]),
            lambda: self.core.batched_gemm(A, B))
        self._model("gemm", 2.0 * float(A.size) * float(B.shape[-1]),
                    bytes_moved=A.nbytes + B.nbytes)
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def flash_attention(
        self, Q: np.ndarray, K: np.ndarray, V: np.ndarray,
        causal: bool = False, block_size: int = 64,
    ) -> np.ndarray:
        t0 = time.time()
        result = self.core.flash_attention(Q, K, V, causal=causal, block_size=block_size)
        B, T, D = Q.shape
        self._model("attention", 4.0 * B * T * T * D,
                    kv_size=float(K.nbytes + V.nbytes), bytes_moved=Q.nbytes)
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def attention(self, Q: np.ndarray, K: np.ndarray, V: np.ndarray,
                  causal: bool = False) -> np.ndarray:
        return self.flash_attention(Q, K, V, causal=causal)

    def conv2d(self, X: np.ndarray, W: np.ndarray,
               stride: int = 1, padding: int = 0) -> np.ndarray:
        t0 = time.time()
        result = self.core.conv2d(X, W, stride=stride, padding=padding)
        self._model("conv", 2.0 * float(result.size) * float(W[0].size),
                    bytes_moved=X.nbytes + W.nbytes)
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def conv3d(self, X: np.ndarray, W: np.ndarray,
               stride=(1, 1, 1), padding=(0, 0, 0)) -> np.ndarray:
        t0 = time.time()
        result = self.core.conv3d(X, W, stride=stride, padding=padding)
        # FLOPs = 2 * N * C_out * C_in * kD * kH * kW * D_out * H_out * W_out
        # Equivalent: 2 * result.size * kernel_volume (where kernel_volume = product of kernel dims per out-channel).
        self._model("conv",
                    2.0 * float(result.size) * float(W.shape[1] * W.shape[2] * W.shape[3] * W.shape[4]),
                    bytes_moved=float(X.nbytes + W.nbytes + result.nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def layer_norm(self, X: np.ndarray, gamma: np.ndarray,
                   beta: np.ndarray, eps: float = 1e-5) -> np.ndarray:
        t0 = time.time()
        result = self.core.layer_norm(X, gamma, beta, eps=eps)
        # Roofline: mean + variance + normalise + scale + shift = 5 FLOPs/element.
        # Memory-bound: arithmetic intensity ≈ 1.5 FLOPs/byte. Track read + write.
        self._model("normalization", 5.0 * float(X.size),
                    bytes_moved=float(X.nbytes + gamma.nbytes + beta.nbytes + result.nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def batch_norm(self, X: np.ndarray, gamma: np.ndarray, beta: np.ndarray,
                   running_mean=None, running_var=None,
                   training=True, eps=1e-5):
        t0 = time.time()
        result = self.core.batch_norm(
            X, gamma, beta, running_mean, running_var, training, eps
        )
        # result is (out, running_mean, running_var); model only the main output bytes.
        # Same FLOPs formula as layer_norm: 5 FLOPs/element.
        self._model("normalization", 5.0 * float(X.size),
                    bytes_moved=float(X.nbytes + gamma.nbytes + beta.nbytes + result[0].nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def gelu(self, X: np.ndarray) -> np.ndarray:
        t0 = time.time()
        result = self.core.gelu(X)
        # Roofline: tanh approx ≈ 8 FLOPs/element (cube + 3×mul + 2×add + tanh + scale).
        # Deeply memory-bound (~4 FLOPs/byte on typical arrays). Track read + write.
        self._model("elementwise", 8.0 * float(X.size),
                    bytes_moved=float(2 * X.nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def silu(self, X: np.ndarray) -> np.ndarray:
        t0 = time.time()
        result = self.core.silu(X)
        # Roofline: x * sigmoid(x) ≈ 4 FLOPs/element (neg + exp + add-1 + div + mul).
        # Memory-bound: arithmetic intensity ≈ 2–3 FLOPs/byte.
        self._model("elementwise", 4.0 * float(X.size),
                    bytes_moved=float(2 * X.nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def softmax(self, X: np.ndarray, axis: int = -1) -> np.ndarray:
        t0 = time.time()
        result = self.core.softmax(X, axis=axis)
        # Roofline: max + subtract + exp + sum + divide = 5 FLOPs/element.
        # Memory-bound: intensity ≈ 4 FLOPs/byte (per ZeroEntropy roofline chart).
        self._model("elementwise", 5.0 * float(X.size),
                    bytes_moved=float(2 * X.nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def add(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        t0 = time.time()
        result = self.core.add(A, B)
        # 1 FLOPs/element; reads two arrays and writes one — 3× elem bytes total.
        self._model("elementwise", float(A.size),
                    bytes_moved=float(A.nbytes + B.nbytes + result.nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def grouped_gemm(self, A_list, B_list):
        t0 = time.time()
        result = self.core.grouped_gemm(A_list, B_list)
        # Sum 2*M*N*K per group; bytes = all input reads (outputs excluded as they
        # are typically streamed out once, matching the GEMM bandwidth model).
        total_flops = sum(
            2.0 * float(A.shape[0]) * float(A.shape[1]) * float(B.shape[1])
            for A, B in zip(A_list, B_list)
        )
        total_bytes = float(sum(A.nbytes + B.nbytes for A, B in zip(A_list, B_list)))
        self._model("gemm", total_flops, bytes_moved=total_bytes)
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    def fused_attention_norm(self, Q, K, V, gamma, beta, causal=False, eps=1e-5):
        t0 = time.time()
        result = self.core.fused_attention_norm(Q, K, V, gamma, beta, causal, eps)
        B_n, T, D = Q.shape
        attn_flops = 4.0 * B_n * T * T * D          # flash-attention: 4BT²D
        norm_flops  = 5.0 * float(Q.size)            # layer-norm: 5 FLOPs/element
        self._model("attention_norm", attn_flops + norm_flops,
                    kv_size=float(K.nbytes + V.nbytes),
                    bytes_moved=float(Q.nbytes + K.nbytes + V.nbytes
                                      + gamma.nbytes + beta.nbytes + result.nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return result

    # ── SM102 MaxCore kernel methods ──────────────────────────────────────────

    @property
    def nvcc(self):
        """Lazy-compiled CUDANvcc backed by this HyperGPU instance."""
        if not hasattr(self, "_nvcc"):
            from ai_model.gpu.native.cuda import CUDANvcc
            object.__setattr__(self, "_nvcc", CUDANvcc(gpu=self))
        return self._nvcc

    def flash_attn_fp8_sm102(
        self,
        Q: np.ndarray,
        K: np.ndarray,
        V: np.ndarray,
        causal: bool = False,
        fp8_format: str = "e4m3",
    ) -> np.ndarray:
        """Flash attention with fp8 Q/K/V via the SM102 custom nvcc.

        Compiles ``flashattn_sm102.cu`` through the custom nvcc on first call
        (cached thereafter) and executes it on this HyperGPU's SIMD cores.
        Output dtype is fp16 — matching the ``__half* O`` in the .cu kernel.
        """
        t0 = time.time()
        mod = self.nvcc.compile_sm102()
        B, H, T, D = Q.shape
        O = np.zeros((B, H, T, D), dtype=np.float16)
        mod(
            "flash_attn_sm102_kernel",
            (B * H,), (32,),
            Q.astype(np.float32), K.astype(np.float32),
            V.astype(np.float32), O,
            gpu=self,
            causal=causal,
            fp8_format=fp8_format,
        )
        self._model(
            "attention",
            4.0 * B * H * T * T * D,
            kv_size=float(K.nbytes + V.nbytes),
            bytes_moved=float(Q.nbytes + K.nbytes + V.nbytes + O.nbytes),
            precision=f"fp8_{fp8_format}",
        )
        self._total_compute_ms += (time.time() - t0) * 1000
        return O

    def conv_wmma_sm102(
        self,
        A: np.ndarray,   # [M, K] fp16 — im2col output
        B: np.ndarray,   # [N, K] fp16 — weight matrix
    ) -> np.ndarray:
        """WMMA tensor-core GEMM via the SM102 custom nvcc.

        Matches ``conv_wmma_sm102_kernel`` in ``conv_sm102.cu``:
        16×16×16 fragment tiles, fp16 inputs, fp16 accumulate.
        """
        t0 = time.time()
        mod = self.nvcc.compile_sm102()
        M, K_dim = A.shape
        N = B.shape[0]
        C = np.zeros((M, N), dtype=np.float16)
        gx = max(1, (M + 63) // 64)
        gy = max(1, (N + 63) // 64)
        mod(
            "conv_wmma_sm102_kernel",
            (gx, gy), (128, 4),
            A.astype(np.float16), B.astype(np.float16), C,
            gpu=self,
        )
        self._model(
            "gemm", 2.0 * M * K_dim * N,
            bytes_moved=float(A.nbytes + B.nbytes + C.nbytes),
            precision="fp16",
        )
        self._total_compute_ms += (time.time() - t0) * 1000
        return C

    def reduction_sm102(
        self,
        x: np.ndarray,
        y: np.ndarray,
        variant: str = "redesigned",
    ) -> float:
        """Dot-product reduction via the SM102 custom nvcc.

        ``variant='redesigned'`` (default): warp-shuffle __shfl_down_sync
        grid-stride path — ~32× fewer atomicAdd calls than the tree variant.
        ``variant='current'``: shared-memory binary-tree reduction.
        """
        t0 = time.time()
        mod = self.nvcc.compile_sm102()
        x32 = x.astype(np.float32).ravel()
        y32 = y.astype(np.float32).ravel()
        out = np.zeros(1, dtype=np.float32)
        n = len(x32)
        kernel = ("reduction_redesigned_sm102_kernel"
                  if variant == "redesigned"
                  else "reduction_current_sm102_kernel")
        mod(
            kernel,
            (min(1024, max(1, (n + 255) // 256)),), (256,),
            x32, y32, out,
            gpu=self,
        )
        self._model("elementwise", 2.0 * n,
                    bytes_moved=float(x32.nbytes + y32.nbytes))
        self._total_compute_ms += (time.time() - t0) * 1000
        return float(out[0])

    def flush_vram(self):
        self.vram.flush()

    def status(self) -> dict:
        uptime = time.time() - self._created_at
        core_status = self.core.status()
        return {
            "engine": "HyperGPU",
            "lanes": self.core.lanes,
            "tensor_cores": len(self.core.tensor_core_units),
            "precision": self.precision.name,
            "tile_shape": core_status["tile_shape"],
            "total_ops": core_status["total_ops_executed"],
            "total_tensor_core_tflops": core_status["total_tensor_core_tflops"],
            "total_compute_ms": round(self._total_compute_ms, 2),
            "vram": self.vram.status(),
            "memory_pool": core_status["memory_pool"],
            "uptime_s": round(uptime, 1),
            "silicon": self.silicon_report(),
        }


class GPUClusterNode:
    def __init__(
        self,
        node_id: int,
        lanes: int | None = None,
        tensor_cores: int | None = None,
        precision: PrecisionMode = PrecisionMode.MIXED,
        vram_capacity: int = 0,
    ):
        # Default to the shared host-capacity-derived sizing (ai_model/gpu/sizing.py)
        # unless the caller explicitly overrides lanes/tensor_cores.
        if lanes is None or tensor_cores is None:
            _default_lanes, _default_tensor_cores = hyper_gpu_sizing()
            lanes = _default_lanes if lanes is None else lanes
            tensor_cores = _default_tensor_cores if tensor_cores is None else tensor_cores
        self.node_id = node_id
        self.gpu = HyperGPU(
            lanes=lanes,
            tensor_cores=tensor_cores,
            precision=precision,
            vram_capacity=vram_capacity,
        )
        self.state = "idle"
        self._assigned_task: Optional[str] = None

    def assign(self, task: str):
        self.state = "busy"
        self._assigned_task = task

    def release(self):
        self.state = "idle"
        self._assigned_task = None

    def status(self) -> dict:
        return {
            "node_id": self.node_id,
            "state": self.state,
            "assigned_task": self._assigned_task,
            "gpu": self.gpu.status(),
        }


class GPUCluster:
    def __init__(
        self,
        num_nodes: int = 4,
        lanes_per_node: int | None = None,
        tensor_cores_per_node: int | None = None,
        precision: PrecisionMode = PrecisionMode.MIXED,
        vram_per_node: int = 0,
    ):
        # Default to the shared host-capacity-derived sizing (ai_model/gpu/sizing.py)
        # unless the caller explicitly overrides lanes_per_node/tensor_cores_per_node.
        if lanes_per_node is None or tensor_cores_per_node is None:
            _default_lanes, _default_tensor_cores = hyper_gpu_sizing()
            lanes_per_node = _default_lanes if lanes_per_node is None else lanes_per_node
            tensor_cores_per_node = (
                _default_tensor_cores if tensor_cores_per_node is None else tensor_cores_per_node
            )
        self.nodes: Dict[int, GPUClusterNode] = {}
        self._lock = threading.Lock()
        self._gradient_buffer: Dict[str, List[np.ndarray]] = {}

        for i in range(num_nodes):
            self.nodes[i] = GPUClusterNode(
                node_id=i,
                lanes=lanes_per_node,
                tensor_cores=tensor_cores_per_node,
                precision=precision,
                vram_capacity=vram_per_node,
            )

    @property
    def num_nodes(self) -> int:
        return len(self.nodes)

    @property
    def total_lanes(self) -> int:
        return sum(n.gpu.core.lanes for n in self.nodes.values())

    @property
    def total_tensor_cores(self) -> int:
        return sum(len(n.gpu.core.tensor_core_units) for n in self.nodes.values())

    def get_node(self, node_id: int) -> GPUClusterNode:
        if node_id not in self.nodes:
            raise GPUError(f"Node {node_id} not found in cluster")
        return self.nodes[node_id]

    def get_idle_node(self) -> Optional[GPUClusterNode]:
        with self._lock:
            for node in self.nodes.values():
                if node.state == "idle":
                    return node
        return None

    def all_reduce_gradients(self, param_name: str, gradients: List[np.ndarray]) -> np.ndarray:
        if not gradients:
            raise GPUError("all_reduce: empty gradient list")
        avg = np.mean(gradients, axis=0)
        return avg

    def scatter_data(self, data: np.ndarray, num_chunks: int = 0) -> List[np.ndarray]:
        if num_chunks <= 0:
            num_chunks = self.num_nodes
        return np.array_split(data, num_chunks, axis=0)

    def gather_results(self, chunks: List[np.ndarray], axis: int = 0) -> np.ndarray:
        return np.concatenate(chunks, axis=axis)

    def run_distributed(
        self, fn, data_chunks: List[np.ndarray],
        node_ids: Optional[List[int]] = None,
    ) -> List[np.ndarray]:
        if node_ids is None:
            node_ids = list(self.nodes.keys())[:len(data_chunks)]

        results: list[Any] = [None] * len(data_chunks)
        errors = {}
        threads = []

        def _run_on_node(idx, nid, chunk):
            try:
                node = self.get_node(nid)
                node.assign(f"distributed_chunk_{idx}")
                results[idx] = fn(node.gpu, chunk)
                node.release()
            except Exception as e:
                errors[nid] = str(e)

        for i, (nid, chunk) in enumerate(zip(node_ids, data_chunks)):
            t = threading.Thread(target=_run_on_node, args=(i, nid, chunk), daemon=True)
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        if errors:
            raise GPUError(f"Distributed execution errors: {errors}")

        return results

    def flush_all(self):
        for node in self.nodes.values():
            node.gpu.flush_vram()

    def add_node(
        self, lanes: int | None = None, tensor_cores: int | None = None,
        precision: PrecisionMode = PrecisionMode.MIXED,
    ) -> int:
        # lanes/tensor_cores default to None so GPUClusterNode resolves the
        # shared host-capacity-derived sizing itself unless overridden here.
        with self._lock:
            nid = max(self.nodes.keys()) + 1 if self.nodes else 0
            self.nodes[nid] = GPUClusterNode(
                node_id=nid, lanes=lanes,
                tensor_cores=tensor_cores, precision=precision,
            )
            return nid

    def remove_node(self, node_id: int):
        with self._lock:
            node = self.nodes.pop(node_id, None)
            if node:
                node.gpu.flush_vram()

    def status(self) -> dict:
        node_statuses = {nid: n.status() for nid, n in self.nodes.items()}
        idle = sum(1 for n in self.nodes.values() if n.state == "idle")
        busy = sum(1 for n in self.nodes.values() if n.state == "busy")
        total_compute = sum(n.gpu._total_compute_ms for n in self.nodes.values())
        total_ops = sum(n.gpu.core._total_ops for n in self.nodes.values())
        total_tc_flops = sum(
            tc.total_flops
            for n in self.nodes.values()
            for tc in n.gpu.core.tensor_core_units
        )

        return {
            "engine": "HyperGPU Cluster",
            "num_nodes": self.num_nodes,
            "total_lanes": self.total_lanes,
            "total_tensor_cores": self.total_tensor_cores,
            "nodes_idle": idle,
            "nodes_busy": busy,
            "total_ops": total_ops,
            "total_compute_ms": round(total_compute, 2),
            "total_tensor_core_tflops": round(total_tc_flops / 1e12, 6),
            "nodes": node_statuses,
        }
