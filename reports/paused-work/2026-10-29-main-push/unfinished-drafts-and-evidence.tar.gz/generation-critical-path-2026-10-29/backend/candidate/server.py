"""
MaxBooster AI Training Server
==============================================
Production-grade AI model training server with:
  - Custom transformer model (no external APIs)
  - API key management with PostgreSQL
  - Training orchestration
  - GPU simulation / HyperGPU cluster
  - Multi-platform content generation
  - BoostSheet management
  - Storage server sync (datasets, checkpoints, curriculum state)
"""
from __future__ import annotations

import os
import sys
import time
import secrets
import hashlib
import uuid
import json
import asyncio
import threading
import re
import logging
from contextvars import ContextVar
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Optional, List, Dict
from urllib.parse import urlparse
import html as _html
import urllib.request as _urllib_request

# ── BLAS/OpenMP thread pools — sized to the actual host, before numpy loads ──
# The default MaxCore path (MAXCORE_NUM_STREAMS unset/1) runs every
# GEMM/attention/conv2d op directly in *this* process via numpy — it is not
# "bookkeeping only", so it genuinely needs a real, host-scaled BLAS thread
# pool. Hardcoding every BLAS var to "1" (the old policy here) left 15/16
# cores idle on a 16-CPU host for the most common execution path. When a
# caller opts into MAXCORE_NUM_STREAMS > 1, LaneProcessPool spawns separate
# worker processes and re-plans BLAS threads for its own worker count right
# before spawning them (see ai_model/maxcore/runtime/process_pool.py) — that
# re-plan uses override=True specifically so it can shrink whatever this
# block sets, so it is never oversubscribed by this process-wide default.
#
# UVICORN_WORKERS (also read below, in __main__) matters here too: each
# uvicorn worker is a separate OS process that re-executes this module from
# scratch, so every worker independently divides the *same* host by the *same*
# worker count via plan_blas_threads's num_workers — never N x cpus threads.
#
# ai_model.maxcore's package __init__ eagerly imports numpy-heavy submodules,
# so this can't do `from ai_model.maxcore.hardware import ...` — that would
# import numpy before these env vars are set, too late for BLAS to see them.
# Load hardware.py directly, by file path, bypassing the package __init__
# entirely (the same isolation trick silicon_simt_backend.py uses to load the
# engine module without pulling in the rest of ai_model.gpu).
import importlib.util as _blas_ilu

_blas_hardware_path = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "ai_model", "maxcore", "hardware.py"
)
_blas_hardware_spec = _blas_ilu.spec_from_file_location("_maxcore_hardware_bootstrap", _blas_hardware_path)
_blas_hardware = _blas_ilu.module_from_spec(_blas_hardware_spec)
_blas_hardware_spec.loader.exec_module(_blas_hardware)

_blas_cpus = _blas_hardware.cpu_count()
_blas_workers = max(1, int(os.environ.get("UVICORN_WORKERS", "1")))
_blas_hardware.configure_blas_threads(
    num_workers=_blas_workers,
    reserve=_blas_hardware.reserve_cpus_for(_blas_cpus),
)

import psycopg2
import psycopg2.pool
from psycopg2.extras import RealDictCursor
from fastapi import FastAPI, HTTPException, Depends, Header, Request, BackgroundTasks, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator

_srv_logger = logging.getLogger(__name__)

# ─── DB Setup ────────────────────────────────────────────────────────────────

DATABASE_URL = os.environ.get("DATABASE_URL")

_db_pool: Optional[psycopg2.pool.ThreadedConnectionPool] = None
_db_pool_lock = threading.Lock()

def _get_db_pool() -> psycopg2.pool.ThreadedConnectionPool:
    global _db_pool
    if _db_pool is None:
        with _db_pool_lock:
            if _db_pool is None:
                _db_pool = psycopg2.pool.ThreadedConnectionPool(
                    minconn=2,
                    maxconn=15,
                    dsn=DATABASE_URL,
                    # Keep connections alive across long idle periods
                    keepalives=1,
                    keepalives_idle=30,
                    keepalives_interval=5,
                    keepalives_count=5,
                )
    return _db_pool

def _acquire() -> psycopg2.extensions.connection:
    return _get_db_pool().getconn()

def _release(conn, error: bool = False):
    try:
        if error:
            conn.rollback()
        _get_db_pool().putconn(conn)
    except Exception as e:
        _srv_logger.debug(f"[DB] pool release error: {e}")

def get_db():
    conn = _acquire()
    try:
        yield conn
    finally:
        _release(conn)

def init_db():
    """Initialize database tables."""
    conn = _acquire()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS api_keys (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            name TEXT NOT NULL,
            key_hash TEXT NOT NULL UNIQUE,
            prefix TEXT NOT NULL,
            scopes TEXT[] NOT NULL DEFAULT '{}',
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            request_count INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            last_used_at TIMESTAMPTZ,
            expires_at TIMESTAMPTZ
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS training_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            level TEXT NOT NULL DEFAULT 'info',
            message TEXT NOT NULL,
            epoch INTEGER,
            loss FLOAT,
            job_id TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS request_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            api_key_id UUID REFERENCES api_keys(id),
            endpoint TEXT NOT NULL,
            method TEXT NOT NULL,
            status_code INTEGER,
            response_time_ms INTEGER,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
    """)

    # Create a default admin key if none exists
    cur.execute("SELECT COUNT(*) FROM api_keys")
    count = cur.fetchone()[0]
    if count == 0:
        admin_key = f"mbs_{secrets.token_hex(32)}"
        key_hash = hashlib.sha256(admin_key.encode()).hexdigest()
        prefix = admin_key[:12]
        cur.execute(
            """INSERT INTO api_keys (name, key_hash, prefix, scopes, is_active)
               VALUES (%s, %s, %s, %s, TRUE)""",
            ("Default Admin Key", key_hash, prefix, ["read", "write", "train", "admin", "generate"])
        )
        # Bootstrap state is private, never a credential in public logs.
        key_path = _PRIVATE_STATE_DIR / "bootstrap-admin.key"
        flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0)
        with os.fdopen(os.open(key_path, flags, 0o600), "w") as key_file:
            os.fchmod(key_file.fileno(), 0o600)
            key_file.write(admin_key)
        print("[Server] Bootstrap administrator credential stored in private state directory")

    # Ensure AI_TRAINING_KEY_PROD is registered (idempotent — upsert by hash)
    _prod_key = os.environ.get("AI_TRAINING_KEY_PROD")
    if _prod_key:
        _prod_hash   = hashlib.sha256(_prod_key.encode()).hexdigest()
        _prod_prefix = _prod_key[:12]
        cur.execute("SELECT id FROM api_keys WHERE key_hash = %s", (_prod_hash,))
        if not cur.fetchone():
            cur.execute(
                """INSERT INTO api_keys (name, key_hash, prefix, scopes, is_active)
                   VALUES (%s, %s, %s, %s, TRUE)""",
                ("AI Training Key (prod)", _prod_hash, _prod_prefix,
                 ["read", "write", "train", "admin", "generate"])
            )
            print(f"[Server] AI_TRAINING_KEY_PROD registered: {_prod_prefix}...")
        else:
            # Ensure it's active
            cur.execute(
                "UPDATE api_keys SET is_active = TRUE WHERE key_hash = %s",
                (_prod_hash,)
            )
            print(f"[Server] AI_TRAINING_KEY_PROD already registered: {_prod_prefix}...")

    conn.commit()
    cur.close()
    _release(conn)

def log_training(message: str, level: str = "info", epoch: int = None,
                 loss: float = None, job_id: str = None):
    try:
        conn = _acquire()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO training_logs (level, message, epoch, loss, job_id) VALUES (%s, %s, %s, %s, %s)",
            (level, message, epoch, loss, job_id)
        )
        conn.commit()
        cur.close()
        _release(conn)
    except Exception as e:
        print(f"[Server] Failed to log training: {e}")

# ─── Training State ──────────────────────────────────────────────────────────

_training_state: dict[str, Any] = {
    "state": "idle",
    "epoch": 0,
    "total_epochs": 0,
    "loss": None,
    "perplexity": None,
    "samples_trained": 0,
    "elapsed_seconds": 0,
    "eta_seconds": None,
    "weights_exist": False,
    "job_id": None,
    "started_at": None,
    "first_loss": None,
    "best_loss": None,
    "current_loss": None,
    "sessions_done": 0,
    "last_weights_save": None,
    "weights_file": "weights_v4.npz",
    "total_trained": 0,
    "training_time": 0,
    "curriculum_phase": None,
    "curriculum_phases_done": [],
    "schedule_mode": "single",
    "stop_requested": False,
}
_training_lock = threading.Lock()

# ─── App Init ────────────────────────────────────────────────────────────────

app = FastAPI(
    title="MaxBooster AI Training Server",
    description="Production-grade custom AI model training server with API key management",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Authenticated application identity forwarded only across the private
# app-Node -> MaxCore-Node -> Python chain. It is never accepted from a request
# body, so producer payloads cannot claim another user's jobs.
_request_job_owner: ContextVar[Optional[str]] = ContextVar(
    "maxcore_request_job_owner", default=None
)


@app.middleware("http")
async def bind_job_owner_middleware(request: Request, call_next):
    from ai_model.generation.owner import verify_owner
    from fastapi.responses import JSONResponse
    try:
        owner = verify_owner(
            request.headers, path=request.url.path,
            peer=request.client.host if request.client else "",
            secret=os.environ.get("PDIM_LOCAL_CHANNEL_TOKEN", ""),
        )
    except ValueError as exc:
        return JSONResponse(status_code=403, content={"detail": str(exc)})
    token = _request_job_owner.set(owner)
    try:
        return await call_next(request)
    finally:
        _request_job_owner.reset(token)

# ─── Progressive latency observability (NO aborts) ──────────────────────────
# Guaranteed-completion policy: requests are NEVER aborted by the server.
# Every endpoint keeps a latency-class budget, but it is used purely for
# observability — slow requests are logged at 50% and 100% of budget and then
# allowed to run to completion.  The Node.js proxy and uvicorn keep-alives are
# configured with no request timeouts, so the full chain waits for the work.

_TIMEOUT_EXEMPT_SUFFIXES = ("/download", "/file", "/video", "/preview")

_TIMEOUT_CLASSES: list = [
    # (path prefixes, budget seconds) — first match wins; order matters
    (("/health", "/api/health", "/model/status", "/gpu/", "/dashboard/stats",
      "/api/concurrency", "/api/video-job", "/api/audio-job", "/api/video-jobs",
      "/api-keys", "/storage/status", "/storage/pipeline/status",
      "/storage/datasets/audio/status", "/training/status",
      "/training/continuous/status", "/training/puller/status",
      "/api/awareness/quality/status"), 10.0),
    (("/generate/audio", "/api/generate/audio", "/platform/video/generate",
      "/api/generate-video", "/api/video/", "/platform/model/reload",
      "/api/warm", "/training/", "/storage/"), 150.0),
    (("/content/generate", "/api/generate/", "/platform/", "/generate/",
      "/api/url-parser", "/api/analyze", "/api/safety",
      "/api/awareness/"), 40.0),
]
# Default stays below the Node proxy's 45s non-stream abort so unclassified
# routes still return a structured 504 instead of an opaque proxy abort.
_TIMEOUT_DEFAULT_BUDGET = 40.0


def _timeout_budget_for(path: str) -> float:
    for prefixes, budget in _TIMEOUT_CLASSES:
        if path.startswith(prefixes):
            return budget
    return _TIMEOUT_DEFAULT_BUDGET


@app.middleware("http")
async def progressive_timeout_middleware(request, call_next):
    from fastapi.responses import JSONResponse  # local: avoid top-level churn

    path = request.url.path
    # Exempt binary/streaming routes (video files, scene previews).
    if path.startswith("/api/video-job/") and (
        "/preview/" in path or path.endswith(_TIMEOUT_EXEMPT_SUFFIXES)
    ):
        return await call_next(request)

    budget = _timeout_budget_for(path)
    soft = budget * 0.5
    start = time.time()

    # Observability-only: log at soft/full budget, but NEVER abort — the
    # request always runs to completion (guaranteed-completion policy).
    task = asyncio.ensure_future(call_next(request))
    done, _ = await asyncio.wait({task}, timeout=soft)
    if not done:
        print(f"[latency] SLOW {request.method} {path}: exceeded soft mark "
              f"{soft:.0f}s (class {budget:.0f}s) — still running", flush=True)
        done, _ = await asyncio.wait({task}, timeout=budget - soft)
        if not done:
            print(f"[latency] VERY SLOW {request.method} {path}: exceeded "
                  f"{budget:.0f}s class budget — waiting to completion", flush=True)
            await asyncio.wait({task})

    response = task.result()
    response.headers["X-Latency-Class"] = f"{budget:.0f}"
    elapsed = time.time() - start
    if elapsed > budget:
        print(f"[latency] COMPLETED {request.method} {path} after {elapsed:.1f}s "
              f"(class {budget:.0f}s)", flush=True)
    return response


# ─── Async helper: run blocking calls off the event loop ─────────────────────

async def _in_thread(fn):
    """Run a synchronous callable in the default thread-pool executor so that
    Digital GPU / blocking agent inference does not stall uvicorn's event loop."""
    from contextvars import copy_context
    context = copy_context()
    future = asyncio.get_running_loop().run_in_executor(None, context.run, fn)
    try:
        return await asyncio.shield(future)
    except asyncio.CancelledError:
        # Cancelling the HTTP waiter does not stop its executor thread. Keep
        # request GPU contexts alive until that worker actually exits.
        while not future.done():
            try:
                await asyncio.shield(future)
            except asyncio.CancelledError:
                continue
            except Exception:
                break
        if not future.cancelled():
            future.exception()  # retrieve a worker error before propagating cancellation
        raise


from ai_model.adaptive_concurrency import INFERENCE_GATE, RENDER_GATE, GateBusy  # noqa: E402


async def _in_thread_gated(gate, fn, timeout=None):
    """Run ``fn`` in a worker thread while holding an adaptive-concurrency slot.

    Guaranteed-completion policy: the slot acquisition waits INDEFINITELY
    (timeout=None) — bursts queue up and drain in order instead of being
    rejected with GateBusy/503.  The blocking wait happens inside the worker
    thread so the event loop is never stalled.  The ``timeout`` parameter is
    retained for signature compatibility and ignored."""
    def _run():
        with gate.slot(timeout=None):
            return fn()
    return await _in_thread(_run)


# ─── Pocket GPU Pool: infinite per-request GPU lifecycle ─────────────────────
# Each unique inference request gets its own GPU instance spawned from the
# pocket dimension (born → working → dead).  The pool is unbounded — the
# pocket's compression+filetree system absorbs any burst.  Identical requests
# never reach the pool; the async coalescer above collapses them to one life.
_gpu_pool = None
_gpu_pool_lock = threading.Lock()


def _get_gpu_pool():
    """Process-wide PocketGPUPool singleton.  Lazily initialised on first use."""
    global _gpu_pool
    if _gpu_pool is None:
        with _gpu_pool_lock:
            if _gpu_pool is None:
                from ai_model.gpu.pocket_pool import PocketGPUPool
                _gpu_pool = PocketGPUPool()
    return _gpu_pool


# ─── Model-readiness & worker-readiness helpers ──────────────────────────────
# These replace the old instant-503 guards that fired whenever an endpoint was
# hit before _init_ai_model() / _init_workers() had finished.  Requests now
# park here (250 ms sleep loop) for up to their respective deadlines, then
# raise 503 with a Retry-After header only if the subsystem truly never came up.

async def _wait_for_model_ready(max_wait: float = 30.0) -> None:
    """Wait a bounded time for compatible checkpoint initialization."""
    if _model_ready:
        return  # fast path — already ready
    _waited = 0.0
    while not _model_ready:
        if _model_init_error is not None:
            raise HTTPException(
                status_code=503,
                detail=f"Model initialization failed: {_model_init_error}",
            )
        if _waited >= max_wait:
            raise HTTPException(
                status_code=503, detail="A compatible trained model is not ready",
                headers={"Retry-After": "30"},
            )
        await asyncio.sleep(0.25)
        _waited += 0.25
        if _waited and _waited % max(max_wait, 30.0) < 0.25:
            print(f"[readiness] still waiting for model init ({_waited:.0f}s)", flush=True)


async def _wait_for_workers(max_wait: float = 20.0):
    """Return (continuous_trainer, data_puller) once both are initialised.

    Guaranteed-completion policy: parks indefinitely (250 ms poll) until both
    workers exist — never returns early.  ``max_wait`` retained only as the
    slow-log threshold."""
    _waited = 0.0
    while True:
        with _workers_lock:
            ct, dp = _continuous_trainer, _data_puller
        if ct is not None and dp is not None:
            return ct, dp
        await asyncio.sleep(0.25)
        _waited += 0.25
        if _waited and _waited % max(max_wait, 30.0) < 0.25:
            print(f"[readiness] still waiting for workers ({_waited:.0f}s)", flush=True)


def _digest_str(fields: dict) -> str:
    """Stable digest string for a dict of request fields (used as pool spawn key)."""
    payload = json.dumps(fields, sort_keys=True, default=str).encode()
    return hashlib.blake2b(payload, digest_size=16).hexdigest()


# ─── Storage health tracking ─────────────────────────────────────────────────
# Updated by _init_storage() at boot and polled lazily by _get_storage_mode().
# Three states:
#   "live"           — pdim is reachable and serving requests
#   "local_fallback" — pdim offline; disk-backed SQLite store is active
#   "offline"        — neither pdim nor the disk store is available
_storage_mode: str = "unknown"


def _get_storage_mode() -> str:
    """Return the current storage health as a string constant.

    Reads the live StorageClient state (never raises) so the caller always
    gets a concrete value to surface in health probes and generation responses."""
    try:
        from storage_client import get_storage
        s = get_storage()
        if getattr(s, "_local_canonical", False):
            return "live" if s.ping() else "offline"
        if s.is_available:
            return "live"
        return "local_fallback" if s.disk_store_available else "offline"
    except Exception:
        return "unknown"


# ─── PDIM orchestrator: dedup + single-flight (default for content gen) ────────
_pdim_orchestrator = None
_pdim_orch_lock = threading.Lock()


def _get_pdim_orchestrator():
    """Process-wide PDIM orchestrator — fleet-wide dedup + single-flight.

    Backed by the existing ``dedup_cache`` module, so cache keys and TTL
    semantics are unchanged. This only ADDS single-flight: N concurrent
    identical requests collapse to ONE real compute while the rest wait and
    share its result. This is the proven 90M-scale concurrency path and the
    default method for content generation."""
    global _pdim_orchestrator
    if _pdim_orchestrator is None:
        with _pdim_orch_lock:
            if _pdim_orchestrator is None:
                from ai_model.maxcore.pdim import PDIMOrchestrator
                _pdim_orchestrator = PDIMOrchestrator()
    return _pdim_orchestrator


# ─── Async-native request coalescer (90M concurrent path) ────────────────────
#
# The PDIMOrchestrator above uses threading.Event for single-flight, which is
# correct for background threads but wrong at the HTTP layer: each follower
# blocks an executor thread (~8 MB stack) instead of suspending as a coroutine
# (~2 KB).  At 90M simultaneous requests that difference is existential.
#
# This coalescer sits at the asyncio layer, BEFORE any thread is created.
# Identical-digest requests share one asyncio.Future; the other 89,999,999
# waiters are suspended coroutines.  Only unique digests ever enter the thread
# pool and the INFERENCE_GATE — pdim auto-scale ensures that universe is small.

class _AsyncRequestCoalescer:
    """Asyncio-native single-flight for generation handlers.

    Three request paths, in order of cost:

    1. **Settled hit** — a Future for this digest already resolved successfully
       (within the 500 ms eviction window).  Return ``existing.result()``
       directly: zero coroutine creation, zero thread-pool entry, zero gate
       slots.  This is the dominant path at 90 M-concurrent scale where the
       vast majority of requests arrive after the first compute finishes.

    2. **Active follower** — a Future exists but is still pending.  Await
       ``asyncio.shield(future)``: the coroutine suspends cheaply with no
       threads.  One leader computes; every follower wakes up with the result.

    3. **Leader** — no Future exists.  Create one, run ``coro_fn()``, resolve
       the Future, and schedule eviction after 500 ms.

    Thread-safe for coroutines (the asyncio event loop is single-threaded;
    all dict mutations between ``await`` points are GIL-atomic).
    """

    def __init__(self) -> None:
        self._inflight: dict[str, asyncio.Future] = {}

    @staticmethod
    def _digest(key_data: dict) -> str:
        import hashlib
        payload = json.dumps(key_data, sort_keys=True, default=str).encode()
        return hashlib.blake2b(payload, digest_size=16).hexdigest()

    async def compute(self, key_data: dict, coro_fn) -> Any:
        """Run coro_fn() once per unique digest; every other caller gets the
        same result for free — no extra threads, no extra gate slots."""
        digest = self._digest(key_data)
        loop   = asyncio.get_running_loop()

        existing = self._inflight.get(digest)
        if existing is not None:
            if not existing.done():
                # Path 2: active computation — suspend and share the result.
                return await asyncio.shield(existing)
            # Path 1: already settled — return the stored result synchronously.
            # This is the hot path at 90 M concurrent: no Future creation, no
            # thread-pool entry, no INFERENCE_GATE slot consumed.
            if not existing.cancelled() and existing.exception() is None:
                return existing.result()
            # Settled with an exception — fall through to become a new leader
            # so the request gets a fresh attempt rather than a stale error.

        # Path 3: Leader — register the Future before the first ``await`` so
        # any coroutine that computes the same digest after this point sees it
        # and becomes a follower rather than a duplicate leader.
        fut: asyncio.Future = loop.create_future()
        self._inflight[digest] = fut

        try:
            result = await coro_fn()
            fut.set_result(result)
            return result
        except BaseException as exc:
            if not fut.done():
                fut.set_exception(exc)
            raise
        finally:
            # Keep the settled Future alive for 500 ms so late arrivals get
            # Path 1 (synchronous result) rather than becoming new leaders.
            async def _evict() -> None:
                await asyncio.sleep(0.5)
                self._inflight.pop(digest, None)
            asyncio.ensure_future(_evict())


_async_coalescer: "_AsyncRequestCoalescer | None" = None
_async_coalescer_lock = threading.Lock()


def _get_async_coalescer() -> "_AsyncRequestCoalescer":
    global _async_coalescer
    if _async_coalescer is None:
        with _async_coalescer_lock:
            if _async_coalescer is None:
                _async_coalescer = _AsyncRequestCoalescer()
    return _async_coalescer


# ─── Static file serving for generated assets ────────────────────────────────

class _GeneratedAssetsOnlyStaticFiles(StaticFiles):
    async def get_response(self, path: str, scope):
        if path == "analysis-inputs" or path.startswith("analysis-inputs/"):
            raise HTTPException(status_code=404, detail="Not found")
        return await super().get_response(path, scope)


_UPLOADS_PATH = Path(__file__).parent / "uploads"
_UPLOADS_PATH.mkdir(parents=True, exist_ok=True)
(Path(__file__).parent / "uploads" / "images").mkdir(parents=True, exist_ok=True)
app.mount("/uploads", _GeneratedAssetsOnlyStaticFiles(directory=str(_UPLOADS_PATH)), name="uploads")

_AUDIO_UPLOAD_MAX_BYTES = int(os.environ.get("MAXCORE_AUDIO_UPLOAD_MB", "100")) * 1024 * 1024
_AUDIO_UPLOAD_TYPES = {
    "audio/wav": ".wav", "audio/x-wav": ".wav", "audio/wave": ".wav",
    "audio/mpeg": ".mp3", "audio/flac": ".flac", "audio/x-flac": ".flac",
    "audio/ogg": ".ogg", "audio/opus": ".opus", "audio/webm": ".webm",
    "audio/mp4": ".m4a", "audio/x-m4a": ".m4a", "audio/aac": ".aac",
    "audio/aiff": ".aiff", "audio/x-aiff": ".aiff",
}


def _audio_upload_owner_dir(owner_id: str) -> Path:
    digest = hashlib.sha256(owner_id.encode("utf-8")).hexdigest()
    return _UPLOADS_PATH / "audio-inputs" / digest


# ─── Uploads janitor ─────────────────────────────────────────────────────────
# Renders (audio_*, video_*, stems, temp WAVs) accumulate on the VM's
# persistent disk and are never re-read after the client fetches them.  An
# unbounded uploads/ dir eventually fills the disk, which surfaces as ffmpeg
# write failures mid-render and general production instability.  Sweep hourly:
# delete generated files older than the TTL, oldest-first beyond the size cap.
_UPLOADS_TTL_SEC = float(os.environ.get("UPLOADS_TTL_HOURS", "24")) * 3600
_UPLOADS_MAX_BYTES = int(os.environ.get("UPLOADS_MAX_MB", "2048")) * 1024 * 1024
# Only files matching generated-output prefixes are eligible — seed assets
# (uploads/images/ and any hand-placed files) are never touched.
_UPLOADS_SWEEP_PREFIXES = ("audio_", "video_", "scene_", "stem_", "tmp_")
# Grace window: files younger than this are NEVER eligible for deletion, even
# under the size cap.  Renders finish in minutes (120s job deadline), so this
# conservatively protects all in-flight intermediates and gives clients hours
# to download finished outputs before eviction can touch them.
_UPLOADS_MIN_AGE_SEC = float(os.environ.get("UPLOADS_MIN_AGE_HOURS", "6")) * 3600


def _uploads_janitor_sweep() -> None:
    try:
        entries = []
        for p in _UPLOADS_PATH.iterdir():
            if not p.is_file() or not p.name.startswith(_UPLOADS_SWEEP_PREFIXES):
                continue
            try:
                st = p.stat()
            except OSError:
                continue
            entries.append((p, st.st_mtime, st.st_size))
        now = time.time()
        removed = 0
        # Grace window: anything younger than the min age is untouchable.
        entries = [(p, m, s) for p, m, s in entries
                   if now - m > _UPLOADS_MIN_AGE_SEC]
        # Pass 1: TTL
        survivors = []
        for p, mtime, size in entries:
            if now - mtime > _UPLOADS_TTL_SEC:
                try:
                    p.unlink(missing_ok=True)
                    removed += 1
                except OSError:
                    pass
            else:
                survivors.append((p, mtime, size))
        # Pass 2: total-size cap, oldest first
        total = sum(s for _, _, s in survivors)
        if total > _UPLOADS_MAX_BYTES:
            for p, _, size in sorted(survivors, key=lambda e: e[1]):
                if total <= _UPLOADS_MAX_BYTES:
                    break
                try:
                    p.unlink(missing_ok=True)
                    total -= size
                    removed += 1
                except OSError:
                    pass
        if removed:
            print(f"[uploads-janitor] removed {removed} generated files "
                  f"(remaining ~{total // (1024*1024)} MB)", flush=True)
    except Exception as exc:  # noqa: BLE001 — janitor must never crash anything
        print(f"[uploads-janitor] sweep error: {exc}", flush=True)


def _uploads_janitor_loop() -> None:
    while True:
        _uploads_janitor_sweep()
        time.sleep(3600)


threading.Thread(target=_uploads_janitor_loop, name="uploads-janitor",
                 daemon=True).start()

# ─── AI Model Globals ────────────────────────────────────────────────────────

_model_ready = False
_model_init_error = None
_tokenizer = None
_creative_model = None
_script_agent = None
_visual_spec_agent = None
_distribution_agent = None
_optimization_agent = None
_repo = None
_adapter = None
_render_manager = None
_image_engine = None
_hyper_backend = None
_digital_gpu_backend = None
_silicon_simt_backend = None
_model_config: dict[str, Any] = {}
_serving_release_status: dict[str, Any] = {
    "requested": os.environ.get("MAXCORE_SERVING_RELEASE", "live-awareness"), "active": None, "candidate_quality": "not_selected",
    "backend_exclusive": "not_verified",
}

_model_lock = threading.Lock()
_live_serving_model = None
_live_learning_loop = None

# ─── Workers (DataPuller + ContinuousTrainer + Watchdog) ─────────────────────

_data_puller = None
_continuous_trainer = None
_watchdog = None
_asset_index = None
_coverage_watchdog = None
_gen_coalescer = None
_workers_lock = threading.Lock()

def _hyper_gpu_sizing() -> tuple[int, int]:
    """HyperGPU's modeled `lanes`/`tensor_cores` sizing — see
    ai_model/gpu/sizing.py (the one place every HyperGPU construction site
    in this process reads HYPER_GPU_LANES/HYPER_GPU_TENSOR_CORES from) for
    the full rationale. Thin re-export kept here since this module already
    imports lazily inside try/except blocks throughout and callers in this
    file reference `_hyper_gpu_sizing()` directly.
    """
    from ai_model.gpu.sizing import hyper_gpu_sizing
    return hyper_gpu_sizing()

def _init_live_awareness_model():
    global _live_serving_model, _live_learning_loop, _creative_model, _tokenizer
    global _script_agent, _visual_spec_agent, _distribution_agent, _optimization_agent
    global _repo, _adapter, _render_manager, _image_engine, _model_config
    from ai_model.generation.live_serving import LiveServingModel, LiveLearningLoop
    from ai_model.awareness import get_engine
    from ai_model.agents.script_agent import ScriptAgent
    from ai_model.agents.visual_spec_agent import VisualSpecAgent
    from ai_model.agents.distribution_agent import DistributionAgent
    from ai_model.agents.optimization_agent import OptimizationAgent
    from ai_model.boostsheets.repository import BoostSheetRepository
    from ai_model.adapters.url_adapter import UrlToBoostSheetAdapter
    from ai_model.render_manager import RenderManager
    from ai_model.image.image_engine import ImageEngine
    if _live_learning_loop is not None:
        return
    model = LiveServingModel()
    _live_serving_model = _creative_model = model
    _script_agent, _visual_spec_agent = ScriptAgent(model), VisualSpecAgent(model)
    _distribution_agent, _optimization_agent = DistributionAgent(model), OptimizationAgent(model)
    _repo = BoostSheetRepository(path="boostsheets_db")
    _adapter = UrlToBoostSheetAdapter(_repo)
    if _render_manager is None:
        _render_manager = _create_durable_render_manager(RenderManager)
    _image_engine = ImageEngine()
    public_model_config = {
        "width": int(os.environ.get("MAXCORE_PUBLIC_MODEL_WIDTH", "256")),
        "layers": int(os.environ.get("MAXCORE_PUBLIC_MODEL_LAYERS", "6")),
        "heads": int(os.environ.get("MAXCORE_PUBLIC_MODEL_HEADS", "8")),
        "expansion": int(os.environ.get("MAXCORE_PUBLIC_MODEL_EXPANSION", "4")),
    }
    _model_config = {"release": "live-awareness", "automatic_learning": True,
                     "learning_policy": "public-peak-shortform-v1",
                     "training_architecture": "public-content-transformer-v2",
                     "training_model_config": public_model_config}

    def changed(ready, status):
        global _model_ready, _model_init_error, _serving_release_status, _tokenizer
        with _model_lock:
            _model_ready = ready
            _model_init_error = None if ready else status.get(
                "unavailable_reason", "No operationally capable public peak-content model is selected")
            _serving_release_status = status
            _tokenizer = model.tokenizer if ready else None

    private = Path(os.environ.get("MAXCORE_PRIVATE_STATE_DIR", str(Path.home() / ".local/state/maxcore")))
    _live_learning_loop = LiveLearningLoop(
        get_engine, model, private, notify=changed,
        interval=int(os.environ.get("MAXCORE_LIVE_LEARNING_INTERVAL_SECONDS", "900")),
        poll=int(os.environ.get("MAXCORE_LIVE_RELOAD_SECONDS", "30")),
        steps=int(os.environ.get("MAXCORE_LIVE_LEARNING_STEPS", "4")),
        context_tokens=int(os.environ.get("MAXCORE_LIVE_CONTEXT_TOKENS", "2048")),
        peak_content=True,
        model_config=public_model_config,
        bootstrap_steps=int(os.environ.get("MAXCORE_BOOTSTRAP_STEPS", "8")),
        bootstrap_cooldown=int(os.environ.get("MAXCORE_BOOTSTRAP_COOLDOWN_SECONDS", "300")),
        bootstrap_window=int(os.environ.get("MAXCORE_BOOTSTRAP_WINDOW_SECONDS", "3600")),
        bootstrap_max_runs=int(os.environ.get("MAXCORE_BOOTSTRAP_MAX_RUNS", "12")),
        worker_timeout=int(os.environ.get("MAXCORE_LEARNING_WORKER_TIMEOUT_SECONDS", "120")),
    )
    changed(False, model.status())
    _live_learning_loop.start()


def _init_ai_model():
    global _serving_release_status, _model_ready, _model_init_error
    global _creative_model, _tokenizer, _script_agent, _visual_spec_agent
    global _distribution_agent, _optimization_agent, _repo, _adapter, _render_manager
    global _image_engine, _model_config
    from ai_model.generation.release import load_selected_release
    mode = os.environ.get("MAXCORE_SERVING_RELEASE", "live-awareness")
    _model_ready = False
    try:
        if mode == "live-awareness":
            _init_live_awareness_model()
            return
        # Resolve and authenticate bytes before allocating a model/GPU. Legacy
        # startup used to treat a missing LFS download like incompatible weights.
        if mode == "legacy":
            from ai_model.model.checkpoint_release import prepare_checkpoint
            prepare_checkpoint(
                Path(__file__).parent / "ai_model" / "weights",
                supplied_path=os.environ.get("MAXCORE_CHECKPOINT_PATH"),
            )
        selected, status = load_selected_release(mode)
        _serving_release_status = status
        if selected is None:
            if mode != "legacy":
                raise RuntimeError("Requested reviewed release is unavailable; legacy substitution is forbidden")
            _init_legacy_ai_model()
            if _model_ready:
                weights = Path(os.environ.get("MAXCORE_CHECKPOINT_PATH") or
                               Path(__file__).parent / "ai_model" / "weights" / "model.pt")
                _serving_release_status = {
                    **status, "active": "legacy-explicit-release",
                    "checkpoint_sha256": hashlib.sha256(weights.read_bytes()).hexdigest(),
                }
            else:
                raise RuntimeError(_model_init_error or "Legacy checkpoint initialization failed")
            return
        # The selected serving object is passed directly to the existing agents;
        # its generate/generate_batch reject unsupported sampling, never remap it.
        from ai_model.agents.script_agent import ScriptAgent
        from ai_model.agents.visual_spec_agent import VisualSpecAgent
        from ai_model.agents.distribution_agent import DistributionAgent
        from ai_model.agents.optimization_agent import OptimizationAgent
        from ai_model.boostsheets.repository import BoostSheetRepository
        from ai_model.adapters.url_adapter import UrlToBoostSheetAdapter
        from ai_model.render_manager import RenderManager
        from ai_model.image.image_engine import ImageEngine
        _creative_model, _tokenizer = selected, selected.tokenizer
        _script_agent = ScriptAgent(selected)
        _visual_spec_agent = VisualSpecAgent(selected)
        _distribution_agent = DistributionAgent(selected)
        _optimization_agent = OptimizationAgent(selected)
        _repo = BoostSheetRepository(path="boostsheets_db")
        _adapter = UrlToBoostSheetAdapter(_repo)
        if _render_manager is None:
            _render_manager = _create_durable_render_manager(RenderManager)
        _image_engine = ImageEngine()
        _model_config = {"release": "reviewed-candidate", "sampling": status["supported_sampling"]}
        _model_init_error = None
        _model_ready = True
    except Exception as exc:
        # A selected candidate failure cannot enter legacy checkpoint fallback.
        _model_ready = False
        _model_init_error = f"{type(exc).__name__}: {exc}"
        _serving_release_status = {
            "requested": mode, "active": None, "candidate_quality": "blocked",
            "backend_exclusive": "not_verified", "error": _model_init_error,
        }


def _init_legacy_ai_model():
    global _model_ready, _model_init_error, _tokenizer, _creative_model, _script_agent
    global _visual_spec_agent, _distribution_agent, _optimization_agent
    global _repo, _adapter, _render_manager, _model_config, _image_engine
    global _gen_coalescer, _hyper_backend, _digital_gpu_backend

    _model_ready = False
    _model_init_error = None
    try:
        sys.path.insert(0, str(Path(__file__).parent))
        from ai_model.model.tokenizer import BPETokenizer
        from ai_model.model.creative_model import CreativeModel
        from ai_model.agents.script_agent import ScriptAgent
        from ai_model.agents.visual_spec_agent import VisualSpecAgent
        from ai_model.agents.distribution_agent import DistributionAgent
        from ai_model.agents.optimization_agent import OptimizationAgent
        from ai_model.boostsheets.repository import BoostSheetRepository
        from ai_model.adapters.url_adapter import UrlToBoostSheetAdapter
        from ai_model.render_manager import RenderManager
        import torch

        print("[AI Model] Initializing MaxBooster AI Content Model...")
        _tokenizer = BPETokenizer()

        _TORCH_DEVICE = "cpu"   # PyTorch hardware device string — must be "cpu" on this host
        dim      = int(os.environ.get("AI_MODEL_DIM",     "512"))
        n_layers = int(os.environ.get("AI_MODEL_LAYERS",  "8"))
        n_heads  = int(os.environ.get("AI_MODEL_HEADS",   "8"))
        max_len  = int(os.environ.get("AI_MODEL_MAX_LEN", "1024"))

        # ── Digital GPU backend (HyperGPU + SM102 custom nvcc + pdim) ─────────
        # Initialise before the model so the pocket accelerator is warm by the
        # time the first GEMM fires during weight loading / warm-up.
        #
        # HyperGPU/HyperGPUBackend is the ONE canonical compute engine for all
        # model inference and training in this process — see
        # docs/gpu-architecture.md for the full reconciliation of the
        # "Digital GPU"-branded subsystems. `ai_model.gpu.digital_gpu.DigitalGPU`
        # (a standalone ISA/VRAM/SIMDCore emulator) is intentionally NOT
        # instantiated here: nothing in this file ever called it for real
        # compute, and keeping a live-but-unused instance around is what made
        # /gpu/status report "unavailable" even while HyperGPU was healthy.
        try:
            from ai_model.gpu.hyper_core import HyperGPU, PrecisionMode
            from ai_model.gpu.hyper_backend import HyperGPUBackend

            _lanes, _tensor_cores = _hyper_gpu_sizing()
            _hyper_backend    = HyperGPUBackend(
                lanes=_lanes, tensor_cores=_tensor_cores,
                precision=PrecisionMode.MIXED,
            )
            _hyper_gpu        = _hyper_backend.gpu   # created internally
            _digital_gpu_backend = None  # lazily created by /gpu/status if requested

            # Prime the pocket accelerator so its lazy init doesn't stall the
            # first real request.
            _hyper_gpu._pocket()

            print(
                f"[AI Model] Digital GPU ready — HyperGPU "
                f"(lanes={_hyper_gpu.core.lanes}, "
                f"tensor_cores={len(_hyper_gpu.core.tensor_core_units)}, "
                f"precision={_hyper_gpu.precision.name})"
            )
        except Exception as gpu_err:
            print(f"[AI Model] Digital GPU init skipped: {gpu_err}")
            _hyper_backend = None
            _digital_gpu_backend = None

        weights_dir  = Path(__file__).parent / "ai_model" / "weights"
        weights_path = Path(os.environ.get("MAXCORE_CHECKPOINT_PATH") or weights_dir / "model.pt")

        state_dict = None
        if weights_path.exists():
            print(f"[AI Model] Loading weights from {weights_path}")
            from ai_model.media_contract import load_checkpoint_archive
            checkpoint = load_checkpoint_archive(
                weights_path,
                map_location=_TORCH_DEVICE,
            )
            if isinstance(checkpoint, dict) and "vocab" in checkpoint:
                _tokenizer.vocab    = checkpoint["vocab"]
                _tokenizer.inv_vocab = checkpoint["inv_vocab"]
                merges = checkpoint.get("merges", [])
                _tokenizer.merges        = [tuple(p) for p in merges]
                _tokenizer._merge_ranks  = {tuple(p): i for i, p in enumerate(_tokenizer.merges)}
                _tokenizer.freeze()
                state_dict = checkpoint["model_state_dict"]
                if "config" in checkpoint:
                    cfg      = checkpoint["config"]
                    dim      = cfg.get("dim",     dim)
                    n_layers = cfg.get("layers",  n_layers)
                    n_heads  = cfg.get("heads",   n_heads)
                    max_len  = cfg.get("max_len", max_len)
            else:
                state_dict = checkpoint

        vocab_size = max(len(_tokenizer.vocab), 1000)

        # ── Prefer HyperCreativeTransformerLM — digital GPU + KV-cache ────────
        # State-dict compatible with TransformerLM so existing weights load
        # directly.  Falls back to TransformerLM if the import fails.
        base_model = None
        if _hyper_backend is not None:
            try:
                from ai_model.gpu.hyper_creative_transformer import HyperCreativeTransformerLM
                base_model = HyperCreativeTransformerLM(
                    vocab_size=vocab_size,
                    dim=dim, n_layers=n_layers, n_heads=n_heads, max_len=max_len,
                    gpu=_hyper_gpu,
                )
                if state_dict is not None:
                    # Checkpoint may be prefixed with '_orig_mod.' when it was
                    # saved from a torch.compile-wrapped model — strip it so the
                    # keys match HyperCreativeTransformerLM's clean names.
                    clean_sd = {
                        (k[len("_orig_mod."):] if k.startswith("_orig_mod.") else k): v
                        for k, v in state_dict.items()
                    }
                    target_sd = base_model.state_dict()
                    filtered = {
                        k: v for k, v in clean_sd.items()
                        if k in target_sd and v.shape == target_sd[k].shape
                    }
                    from ai_model.media_contract import load_complete_checkpoint
                    load_complete_checkpoint(base_model, state_dict)
                    print(
                        f"[AI Model] Weights loaded into HyperCreativeTransformerLM "
                        f"({len(filtered)}/{len(clean_sd)} tensors matched)"
                    )
                else:
                    raise ValueError("Inference requires trained checkpoint weights")
            except Exception as hct_err:
                print(f"[AI Model] HyperCreativeTransformerLM unavailable: {hct_err}")
                base_model = None

        if base_model is None:
            # Secondary fallback: HyperCreativeTransformerLM with a fresh HyperGPU
            # (covers the case where _hyper_backend failed to init above, e.g. a
            # transient import error, but the GPU module itself is importable).
            # This keeps ALL math on the self-contained MaxCore digital GPU stack
            # — no Replit base-env CPU kernels anywhere in the inference path.
            try:
                from ai_model.gpu.hyper_core import HyperGPU, PrecisionMode
                from ai_model.gpu.hyper_creative_transformer import HyperCreativeTransformerLM
                _fb_lanes, _fb_tensor_cores = _hyper_gpu_sizing()
                _fb_gpu = HyperGPU(lanes=_fb_lanes, tensor_cores=_fb_tensor_cores, precision=PrecisionMode.MIXED)
                base_model = HyperCreativeTransformerLM(
                    vocab_size=vocab_size,
                    dim=dim, n_layers=n_layers, n_heads=n_heads, max_len=max_len,
                    gpu=_fb_gpu,
                )
                if state_dict is not None:
                    clean_sd = {
                        (k[len("_orig_mod."):] if k.startswith("_orig_mod.") else k): v
                        for k, v in state_dict.items()
                    }
                    target_sd = base_model.state_dict()
                    filtered = {k: v for k, v in clean_sd.items()
                                if k in target_sd and v.shape == target_sd[k].shape}
                    from ai_model.media_contract import load_complete_checkpoint
                    load_complete_checkpoint(base_model, state_dict)
                    print(f"[AI Model] Fallback HyperCreativeTransformerLM — "
                          f"{len(filtered)}/{len(clean_sd)} tensors loaded")
                else:
                    raise ValueError("Inference requires trained checkpoint weights")
                backend_name = "Digital GPU fallback (HyperGPU)"
            except Exception as fb_err:
                # Absolute last resort — should never be reached on this platform.
                print(f"[AI Model] HyperGPU fallback unavailable ({fb_err}); "
                      f"no CPU base-env path exists — generation will be disabled")
                base_model = None
                backend_name = "unavailable"
        else:
            backend_name = "Digital GPU (HyperGPU + SM102 + pdim)"

        print(f"[AI Model] Backend: {backend_name}")

        if base_model is None:
            raise RuntimeError("No complete compatible inference checkpoint is available")
        _creative_model      = CreativeModel(base_model, _tokenizer, device=_TORCH_DEVICE)
        _script_agent        = ScriptAgent(_creative_model)
        _visual_spec_agent   = VisualSpecAgent(_creative_model)
        _distribution_agent  = DistributionAgent(_creative_model)
        _optimization_agent  = OptimizationAgent(_creative_model)
        _repo                = BoostSheetRepository(path="boostsheets_db")
        _adapter             = UrlToBoostSheetAdapter(_repo)
        if _render_manager is None:
            _render_manager = _create_durable_render_manager(RenderManager)

        from ai_model.image.image_engine import ImageEngine
        _image_engine = ImageEngine()
        print("[AI Model] ImageEngine ready (PIL renderer)")

        # ── Cross-request dynamic batching (on by default) ───────────────────
        # Coalesces concurrent unique generate() calls into one batched forward.
        # Each batch gets its own pocket GPU life (born → working → dead).
        # Disable with AI_DYNAMIC_BATCHING=0.
        try:
            from ai_model.generation.batching import install as _install_coalescer
            _gen_coalescer = _install_coalescer(
                _creative_model,
                gpu_pool=_get_gpu_pool(),
            )
            if _gen_coalescer is not None:
                print(
                    "[AI Model] Dynamic batching ENABLED (pipelined, pocket GPU per batch) "
                    f"max_batch={_gen_coalescer.max_batch}  "
                    f"window={_gen_coalescer.window_s * 1000:.0f}ms  "
                    f"pipe_depth={_gen_coalescer.pipe_depth}"
                )
            else:
                print("[AI Model] Dynamic batching disabled (AI_DYNAMIC_BATCHING=0)")
        except Exception as be:
            raise RuntimeError("Scoped checkpoint execution could not be installed") from be

        _model_config = {"dim": dim, "layers": n_layers, "heads": n_heads, "max_len": max_len}
        _training_state["weights_exist"] = weights_path.exists()

        print(f"[AI Model] Ready. dim={dim}, layers={n_layers}, vocab={len(_tokenizer.vocab)}")
        log_training("AI model initialized and ready", level="info")

        with _model_lock:
            _model_ready = True

    except Exception as e:
        _model_init_error = f"{type(e).__name__}: {e}"
        print(f"[AI Model] Initialization error: {e}")
        import traceback
        traceback.print_exc()
        log_training(f"AI model initialization failed: {e}", level="error")

# ─── Auth Helpers ────────────────────────────────────────────────────────────

ADMIN_KEY_ENV          = os.environ.get("ADMIN_KEY")
AI_TRAINING_KEY_PROD   = os.environ.get("AI_TRAINING_KEY_PROD")
AI_SERVER_KEY          = os.environ.get("AI_SERVER_KEY")

_ENV_BYPASS_KEYS: set = {k for k in [ADMIN_KEY_ENV, AI_TRAINING_KEY_PROD, AI_SERVER_KEY] if k}

def verify_api_key(x_api_key: str = Header(None), x_admin_key: str = Header(None),
                   authorization: str = Header(None), request: Request = None):
    """Verify API key from X-Api-Key, X-Admin-Key, or Authorization: Bearer."""
    bearer = None
    if authorization and authorization.lower().startswith("bearer "):
        bearer = authorization[7:].strip()
    raw_key = x_api_key or x_admin_key or bearer
    if not raw_key:
        raise HTTPException(status_code=401, detail="API key required")

    # The inherited channel secret is private machine authentication, not a
    # public no-key bypass. Never trust forwarded headers for the peer address.
    local_key = os.environ.get("PDIM_LOCAL_CHANNEL_TOKEN", "")
    if local_key and secrets.compare_digest(raw_key, local_key):
        import ipaddress
        peer = request.client.host if request is not None and request.client else ""
        try:
            loopback = ipaddress.ip_address(peer).is_loopback
        except ValueError:
            loopback = False
        if not loopback:
            raise HTTPException(status_code=403, detail="Private channel requires loopback peer")
        return {"id": "local-supervisor", "scopes": ["read", "write", "generate"]}

    # Allow env-based admin override for ADMIN_KEY and AI_TRAINING_KEY_PROD
    if raw_key in _ENV_BYPASS_KEYS:
        return {"id": "env-admin", "scopes": ["read", "write", "train", "admin", "generate"]}

    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    conn = None
    try:
        conn = _acquire()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(
            "SELECT * FROM api_keys WHERE key_hash = %s AND is_active = TRUE",
            (key_hash,)
        )
        key_record = cur.fetchone()
        if not key_record:
            cur.close()
            _release(conn)
            raise HTTPException(status_code=401, detail="Invalid or inactive API key")

        expires_at = key_record["expires_at"]
        if expires_at and expires_at < datetime.now(timezone.utc):
            cur.close()
            _release(conn)
            raise HTTPException(status_code=401, detail="API key expired")

        cur.execute(
            "UPDATE api_keys SET request_count = request_count + 1, last_used_at = NOW() WHERE id = %s",
            (str(key_record["id"]),)
        )
        conn.commit()
        cur.close()
        _release(conn)
        return dict(key_record)
    except HTTPException:
        if conn:
            _release(conn)
        raise
    except Exception as e:
        if conn:
            _release(conn, error=True)
        raise HTTPException(status_code=500, detail=f"Auth error: {e}")

def require_scope(scope: str):
    def checker(key: dict = Depends(verify_api_key)):
        scopes = key.get("scopes", [])
        if "admin" in scopes:
            return key
        if scope not in scopes:
            raise HTTPException(status_code=403, detail=f"Scope '{scope}' required")
        return key
    return checker


# Native analysis is authenticated exactly like generation and additionally
# requires the trusted gateway user header in its own router.
from ai_model.native_analysis.api import create_analysis_router
app.include_router(create_analysis_router(require_scope("generate"), _UPLOADS_PATH))

# Account aggregates are analyzed transiently inside MaxCore. They never enter
# the public-awareness ingestion or live-learning pipelines.
from ai_model.analytics import create_router as _account_analytics_router

def _account_analytics_snapshot():
    from ai_model.awareness import current_snapshot
    return current_snapshot()

app.include_router(_account_analytics_router(require_scope("generate"), _account_analytics_snapshot))

# Campaign Director: unified multi-modal generation (audio/video/social/ads).
# Mounted with 'generate' scope — same auth as other generation endpoints.
try:
    from ai_model.director.api import create_director_router
    _director_router = create_director_router(require_scope("generate"))
    if _director_router is not None:
        app.include_router(_director_router, prefix="/api/director")
        print("[Server] Director API mounted at /api/director")
except Exception as e:
    print(f"[Server] Director API not mounted: {e}")

def verify_admin(x_admin_key: str = Header(None), authorization: str = Header(None)):
    """Admin-only endpoint auth (X-Admin-Key or Authorization: Bearer)."""
    if not x_admin_key and authorization and authorization.lower().startswith("bearer "):
        x_admin_key = authorization[7:].strip()
    if not x_admin_key:
        raise HTTPException(status_code=401, detail="X-Admin-Key header required")

    # Allow env-based admin override
    if ADMIN_KEY_ENV and x_admin_key == ADMIN_KEY_ENV:
        return {"id": "env-admin", "scopes": ["admin"]}

    key_hash = hashlib.sha256(x_admin_key.encode()).hexdigest()
    conn = None
    try:
        conn = _acquire()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(
            "SELECT * FROM api_keys WHERE key_hash = %s AND is_active = TRUE",
            (key_hash,)
        )
        key_record = cur.fetchone()
        cur.close()
        _release(conn)
        conn = None
        if not key_record:
            raise HTTPException(status_code=401, detail="Invalid admin key")
        scopes = key_record["scopes"] or []
        if "admin" not in scopes:
            raise HTTPException(status_code=403, detail="Admin scope required")
        return dict(key_record)
    except HTTPException:
        if conn:
            _release(conn)
        raise
    except Exception as e:
        if conn:
            _release(conn, error=True)
        raise HTTPException(status_code=500, detail=f"Auth error: {e}")

# ─── Admin content flywheel ───────────────────────────────────────────────────

_flywheel_ingestor: Any = None
_flywheel_init_lock = threading.Lock()


def _get_flywheel() -> Any:
    global _flywheel_ingestor
    if _flywheel_ingestor is not None:
        return _flywheel_ingestor
    with _flywheel_init_lock:
        if _flywheel_ingestor is None:
            try:
                from workers.admin_flywheel import FlywheelIngestor  # noqa: PLC0415
                _flywheel_ingestor = FlywheelIngestor()
            except Exception as e:
                _srv_logger.warning(f"[Flywheel] init error: {e}")
    return _flywheel_ingestor


def _fw_ingest(key: dict, content_type: str, payload: dict, meta: dict) -> None:
    """
    Fire-and-forget admin flywheel ingestion.
    Only stores if the request comes from an admin key. Never raises.
    """
    if "admin" not in (key.get("scopes") or []):
        return
    fw = _get_flywheel()
    if fw is None:
        return
    try:
        fw.ingest(content_type, payload, meta, str(key.get("id", "admin")))
    except Exception as e:
        _srv_logger.debug(f"[Flywheel] ingest error ({content_type}): {e}")


# Serialises read-modify-write of the audio dataset meta/index so two
# concurrent admin renders can't clobber each other's index append.
_AUDIO_DS_INGEST_LOCK = threading.Lock()

# ── In-process audio render cache (Layer 1) ───────────────────────────────────
# Maps (bpm_bucket, key, genre, dur_bucket, fmt, lufs, stems) → result dict.
# Lets repeated requests for the same combo return in 0ms without touching
# storage or synthesis.  Max 128 entries; oldest evicted on overflow.
_AUDIO_RENDER_CACHE: "dict[tuple, dict]" = {}
_AUDIO_RENDER_CACHE_LOCK = threading.Lock()


def _fw_ingest_audio_render(key: dict, job_id: str, render: dict,
                            genres: list) -> None:
    """Audio arm of the admin content flywheel — never raises.

    Pushes an admin-generated audio render back into the real-audio dataset
    pool (``mb:dataset:audio``) so B-Lawz's generated output becomes an
    additional dataset source for future renders, mirroring what
    ``_fw_ingest`` does for text/video/image payloads.

    Guards:
      * admin-scope gated (same contract as ``_fw_ingest``)
      * derivation guard — if the render's source sample is itself a
        flywheel entry, skip (prevents copy-of-copy quality decay)
      * content-hash dedup — identical bytes are never stored twice
    """
    if "admin" not in (key.get("scopes") or []):
        return
    try:
        import base64 as _b64
        import hashlib as _hl
        from storage_client import get_storage

        url = str(render.get("url") or "")
        if not url.startswith("/uploads/"):
            return
        path = _UPLOADS_PATH / url.split("/")[-1]
        if not path.exists():
            return
        raw = path.read_bytes()
        if not raw or len(raw) > 12 * 1024 * 1024:  # sanity cap
            return
        sha = _hl.sha256(raw).hexdigest()

        storage = get_storage()
        with _AUDIO_DS_INGEST_LOCK:
            meta = storage.get("mb:dataset:audio:meta") or {}
            index = list(meta.get("index") or [])
            # Derivation guard: don't re-ingest renders derived from
            # flywheel-sourced tracks (copy-of-copy stacking).
            src = render.get("source_sample") or {}
            src_idx = src.get("idx")
            if src_idx is not None:
                for e in index:
                    if int(e.get("idx", -1)) == int(src_idx):
                        if str(e.get("source") or "") == "flywheel":
                            return
                        break
            # Content dedup
            if any(e.get("content_sha") == sha for e in index):
                return
            next_idx = max(
                [int(e.get("idx", -1)) for e in index] + [int(meta.get("num_chunks", 0)) - 1]
            ) + 1
            bpm = float(render.get("bpm") or 0.0)
            key_name = str(render.get("key") or "")
            chunk = {
                "idx": next_idx,
                "title": f"blawz_flywheel_{job_id[:8]}",
                "artist": "B-Lawz",
                "genres": list(genres or []),
                "source": "flywheel",
                "derived_from": src_idx,
                "bpm": bpm,
                "key": key_name,
                "duration_sec": render.get("duration"),
                "sample_rate": render.get("sample_rate"),
                "format": str(render.get("format") or "mp3"),
                "b64": _b64.b64encode(raw).decode("ascii"),
            }
            storage.set(f"mb:dataset:audio:chunk:{next_idx}", chunk)
            index.append({
                "idx": next_idx, "bpm": bpm, "key": key_name,
                "genres": chunk["genres"], "source": "flywheel",
                "content_sha": sha,
            })
            meta["index"] = index
            meta["num_chunks"] = next_idx + 1
            storage.set("mb:dataset:audio:meta", meta)
        print(
            f"[flywheel] audio render job={job_id[:8]} ingested as dataset "
            f"idx={next_idx} (bpm={bpm}, key={key_name!r}, genres={genres})",
            flush=True,
        )
    except Exception as e:
        _srv_logger.debug(f"[Flywheel] audio ingest error: {e}")

# ─── Pydantic Schemas ────────────────────────────────────────────────────────

class CreateApiKeyRequest(BaseModel):
    name: str
    scopes: List[str] = ["read", "generate"]
    expires_in_days: Optional[int] = None

class StartTrainingRequest(BaseModel):
    epochs: int = 3
    learning_rate: float = 5e-4
    batch_size: int = 8
    use_synthetic: bool = True
    synthetic_count: int = 1000

class BPEScaleUpRequest(BaseModel):
    epochs: int = 6
    synthetic_count: int = 4000
    vocab_size: int = 4000
    dim: int = 512
    layers: int = 8
    heads: int = 8
    max_len: int = 1024
    batch_size: int = 8
    learning_rate: float = 3e-4

class HyperScaleUpRequest(BaseModel):
    """Train a fresh model whose real forward+backward compute is routed through
    the in-house Digital GPU (HyperGPU) tensor-core kernels — not native PyTorch.

    The Digital GPU executes matmul/attention/layer-norm/SiLU via NumPy
    tensor-core simulation with hand-written autograd, so this is genuine
    backend compute (~100-1000x slower per op than native torch). Defaults are
    intentionally modest so a real run completes in this Digital GPU environment;
    ``max_samples`` caps the corpus and can be raised if you accept the time cost.
    The trained weights are transferred into the fast KV-cache serving model."""
    epochs: int = 2
    synthetic_count: int = 600
    vocab_size: int = 2000
    dim: int = 256
    layers: int = 4
    heads: int = 8
    max_len: int = 128
    batch_size: int = 8
    learning_rate: float = 3e-4
    max_samples: int = 800

class PocketMultiplyRequest(BaseModel):
    """Multiply two matrices inside a PDIM pocket.

    A pocket is one dedup + single-flight domain: identical multiplications
    inside the same pocket are computed once on the DigitalGPU backend and
    every repeat (or concurrent duplicate) shares that stored result. Pockets
    nest without limit — ``pocket: "root/sub/leaf"`` addresses a pocket inside
    a pocket inside a pocket; the zlib compression applied to every stored
    payload is what lets one pocket hold arbitrarily many sub-pockets."""
    a: list = []
    b: list = []
    pocket: str = "default"

class _AwarenessMixin(BaseModel):
    """Normalises ``awareness`` whether Node.js sends it as a plain string or as
    the structured object ``{contextString, trendingGenres, ...}`` that
    ``enrichWithAwareness`` injects.  Extracts ``contextString`` from the dict so
    the Python parsers always receive the pre-formatted multi-line text.

    Also accepts ``description`` / ``prompt_url`` for native intent detection,
    plus the structured ``intent`` / ``direction`` / ``context`` envelope
    forwarded by MaxBooster.  The latter stays structured until the canonical
    generation merge serialises it safely; it is never interpolated with
    Python's object repr.
    """

    model_config = {"extra": "allow"}
    seed: Optional[int] = Field(default=None, strict=True, ge=0, lt=2**32)
    awareness:    str = ""
    awareness_provenance: Any = None
    description:  str = ""   # free-text description of what to generate
    prompt_url:   str = ""   # URL to analyse for intent (Spotify, TikTok, etc.)
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None
    intent: Any = None
    direction: Any = None
    context: Any = None
    facts: Any = None
    artist_context: Any = None
    provenance: Any = None
    constraints: Any = None
    modalities: Optional[List[str]] = None
    dedicated_controls: Optional[Dict[str, Any]] = None
    topic: Optional[str] = None
    artist: Any = None
    subject: Any = None
    reference: Any = None

    @model_validator(mode="before")
    @classmethod
    def _normalise_awareness(cls, data: Any) -> Any:
        if isinstance(data, dict) and data.get("seed") is not None:
            if type(data["seed"]) is not int or not 0 <= data["seed"] < 2**32:
                raise ValueError("seed must be an integer in [0, 2**32)")
        if isinstance(data, dict) and isinstance(data.get("awareness"), dict):
            data = dict(data)
            data["awareness_provenance"] = dict(data["awareness"])
            data["awareness"] = json.dumps(data["awareness"], ensure_ascii=False, sort_keys=True)
        return data


def _as_text(v: Any) -> str:
    """Coerce a possibly-Any request field to a clean string ("" if not a str)."""
    return v.strip() if isinstance(v, str) else ""


_SOCIAL_PLATFORM_REGISTRY: Optional[Dict[str, Any]] = None


def _platform_optimization_awareness(req: Any) -> str:
    """Load the closed social platform registry into the actual model prompt."""
    global _SOCIAL_PLATFORM_REGISTRY
    raw_platform = _as_text(getattr(req, "platform", ""))
    if not raw_platform or raw_platform.lower().strip() in {"general", "music", "songwriting"}:
        return ""
    if _SOCIAL_PLATFORM_REGISTRY is None:
        registry_path = Path(__file__).resolve().parents[4] / "shared" / "social-platform-optimization.json"
        with registry_path.open("r", encoding="utf-8") as handle:
            _SOCIAL_PLATFORM_REGISTRY = json.load(handle)
    aliases = {
        "meta": "facebook",  # Meta Ads Manager is not a social-feed profile.
        "google business": "google_business",
        "googlebusiness": "google_business",
        "google-business": "google_business",
        "twitter": "x",
        "twitter/x": "x",
    }
    platform = aliases.get(raw_platform.lower().strip(), raw_platform.lower().strip().replace(" ", "_"))
    profiles = _SOCIAL_PLATFORM_REGISTRY["platforms"]
    if platform not in profiles or set(profiles) != {
        "facebook", "instagram", "youtube", "tiktok", "threads",
        "google_business", "x", "linkedin",
    }:
        raise HTTPException(
            status_code=400,
            detail={
                "code": "UNSUPPORTED_SOCIAL_PLATFORM",
                "platform": raw_platform,
                "allowed": [
                    "facebook", "instagram", "youtube", "tiktok",
                    "threads", "google_business", "x", "linkedin",
                ],
            },
        )
    profile = profiles[platform]
    return "\n".join([
        f"[PLATFORM_OPTIMIZATION platform={platform} revision={_SOCIAL_PLATFORM_REGISTRY['revision']}]",
        f"Content shape: {profile['contentShape']}.",
        f"Length: {profile['length']['min']}-{profile['length']['max']} {profile['length']['unit']}. Formats: {', '.join(profile['format'])}.",
        f"Audience intent: {', '.join(profile['audienceIntent'])}.",
        f"Cadence: {profile['cadence']}. CTA: {profile['cta']}.",
        f"Hashtag/keyword policy: {profile['hashtagKeywordPolicy']}.",
        f"Primary engagement signals: {', '.join(profile['engagementSignals'])}.",
        f"Quality dimensions: {', '.join(profile['qualityDimensions'])}.",
    ])


def _merged_awareness_for(req: Any) -> str:
    # The immutable plan remains attached to the request/job for provenance.
    # It is structured transport metadata, not model-conditioning prose.
    return _merged_awareness_legacy(req)


def _generation_plan_hash():
    from ai_model.generation.plan import active_plan
    from ai_model.awareness import AwarenessUnavailable
    plan = active_plan.get()
    if plan is None:
        raise AwarenessUnavailable("Generation cache requires an immutable request plan")
    return plan.plan_hash


def _merged_awareness_legacy(req: Any) -> str:
    """Build one endpoint's awareness-bridge input, now with intent detection.

    Cascade (highest priority first):
    1. [INTENT] lines  — from the intent sub-awareness layer (description +
                         prompt_url → detect_intent → structured signals)
    2. Direction lines — instruction / extra_context / content_themes serialised
                         by awareness_from_direction, leading with [HIGH]
    3. External awareness — caller-supplied awareness context string
    4. Platform awareness — from quality_awareness.platform_awareness_string

    [INTENT] lines sit above everything else so user-stated intent is the
    strongest conditioning signal throughout the whole brief pipeline.
    Never raises — falls back gracefully to the pre-intent behaviour.
    """
    from ai_model.generation import merge_awareness

    # ── Intent sub-awareness layer ────────────────────────────────────────
    # Detect intent from description and/or prompt_url (both may be empty).
    # We read the URL content once here and pass the text into detect_intent
    # so the awareness merge doesn't duplicate the HTTP call.
    intent_lines: str = ""
    intent_signals = None
    try:
        _desc       = _as_text(getattr(req, "description",  ""))
        _prompt_url = _as_text(getattr(req, "prompt_url",   ""))

        if _desc or _prompt_url:
            from ai_model.intent import detect_intent
            from ai_model.intent.url_reader import read_url as _read_url

            _url_text  = ""
            _url_plat  = ""
            _url_goal  = ""

            if _prompt_url:
                try:
                    # Universal URL Parser — richer than url_reader.read_url:
                    # platform-specific extractors, JSON-LD, music metadata,
                    # pre-formatted awareness block.
                    from ai_model.url_parser import parse_url as _parse_url_fn
                    _parsed   = _parse_url_fn(_prompt_url)
                    _url_text = _parsed.combined_text()
                    _url_plat = _parsed.platform
                    _url_goal = _parsed.goal
                    # Inject the parser's rich awareness block directly at the
                    # top of intent_lines so platform/artist/genre signals lead.
                    if _parsed.awareness_text and not _parsed.is_empty():
                        intent_lines = (
                            _parsed.awareness_text + ("\n" + intent_lines if intent_lines else "")
                        )
                except Exception:
                    pass

            intent_signals = detect_intent(
                description       = _desc,
                url               = "",           # already read above
                url_content_text  = _url_text,
                url_platform_hint = _url_plat,
                url_goal_hint     = _url_goal,
            )

            if intent_signals.is_useful():
                _new_intent = "\n".join(intent_signals.to_awareness_lines())
                # Combine with URL parser awareness (if any) rather than overwriting:
                # intent signals lead (highest priority), URL parser signals follow.
                intent_lines = (
                    _new_intent + "\n" + intent_lines
                    if intent_lines else _new_intent
                )
    except Exception:
        pass

    # ── Base awareness merge (direction + external + platform) ───────────
    base_awareness = merge_awareness(req)
    # ── Assemble final cascade ────────────────────────────────────────────
    parts = [p for p in (intent_lines, base_awareness) if p]
    return "\n".join(parts)


def _intent_signals_for(req: Any):
    """Return the :class:`IntentSignals` for *req* (None if nothing to detect).

    Detects from ``req.description`` and/or ``req.prompt_url``.
    Also merges signals from ``req.audio_ref_b64`` (if provided) — decoded
    and analysed via detect_from_audio(); caller-specified text signals win
    when their confidence is higher.
    Never raises.
    """
    try:
        _desc       = _as_text(getattr(req, "description",  ""))
        _prompt_url = _as_text(getattr(req, "prompt_url",   ""))
        _audio_b64  = _as_text(getattr(req, "audio_ref_b64", ""))

        text_sig = None
        if _desc or _prompt_url:
            from ai_model.intent import detect_intent
            from ai_model.intent.url_reader import read_url as _read_url
            _url_text, _url_plat, _url_goal = "", "", ""
            if _prompt_url:
                try:
                    _uc       = _read_url(_prompt_url)
                    _url_text = _uc.combined()
                    _url_plat = _uc.platform_hint
                    _url_goal = _uc.goal_hint
                except Exception:
                    pass
            text_sig = detect_intent(
                description       = _desc,
                url_content_text  = _url_text,
                url_platform_hint = _url_plat,
                url_goal_hint     = _url_goal,
            )
            if not text_sig.is_useful():
                text_sig = None

        audio_sig = None
        if _audio_b64:
            try:
                import base64 as _b64
                from ai_model.intent.detector import detect_from_audio as _dfa
                _raw = _b64.b64decode(_audio_b64 + "==")
                audio_sig = _dfa(_raw)
            except Exception:
                pass

        # Merge: text signals win when their confidence is higher
        if text_sig is not None and audio_sig is not None:
            # BPM: take the one with higher effective confidence
            if audio_sig.tempo_bpm is not None and text_sig.tempo_bpm is None:
                text_sig.tempo_bpm = audio_sig.tempo_bpm
            # Key: same logic
            if audio_sig.key is not None and text_sig.key is None:
                text_sig.key = audio_sig.key
            return text_sig
        if text_sig is not None:
            return text_sig
        if audio_sig is not None and audio_sig.is_useful():
            return audio_sig
        return None
    except Exception:
        return None


def _merge_audio_ref_signals(request_body: dict, existing_signals: Any) -> Any:
    """Decode audio_ref_b64 from a raw request body dict and merge into existing signals.

    If request_body contains 'audio_ref_b64', detect BPM/key from the audio
    and merge into existing_signals (caller-specified values take priority
    when they are already set).  Never raises — returns existing_signals unchanged
    on any error.
    """
    try:
        _audio_b64 = str(request_body.get("audio_ref_b64") or "").strip()
        if not _audio_b64:
            return existing_signals
        import base64 as _b64
        from ai_model.intent.detector import detect_from_audio as _dfa
        _raw = _b64.b64decode(_audio_b64 + "==")
        audio_sig = _dfa(_raw)
        if existing_signals is None:
            return audio_sig
        # Merge: only fill in fields that are not already set
        if audio_sig.tempo_bpm is not None and getattr(existing_signals, "tempo_bpm", None) is None:
            existing_signals.tempo_bpm = audio_sig.tempo_bpm
        if audio_sig.key is not None and getattr(existing_signals, "key", None) is None:
            existing_signals.key = audio_sig.key
        return existing_signals
    except Exception:
        return existing_signals


class ContentRequest(_AwarenessMixin):
    platform: str = "tiktok"
    topic: str
    tone: str = "energetic"
    goal: str = "growth"
    include_hashtags: bool = True
    # Awareness-bridge direction fields — merged into effective awareness so
    # the script agent and distribution agent are conditioned on the caller's
    # creative intent as well as live platform signals.
    instruction:    Optional[str]       = None   # free-form creative directive
    extra_context:  Optional[str]       = None   # supplementary background context
    content_themes: Optional[List[str]] = None   # thematic keywords (→ bullet, never #tags)

# ─── Startup ─────────────────────────────────────────────────────────────────

# ─── Background liveness-probe server ────────────────────────────────────────
# Runs on HEALTHZ_PORT (default 9879) in its own daemon thread, completely
# independent of uvicorn's event loop.  GC pauses, model inference, asyncio
# blocking — nothing in the main server can stall this.  Node's health monitor
# probes this port instead of the main API port so it can tell the difference
# between "process is truly hung" and "uvicorn event loop is GC-paused for
# 10-20 s while the process is otherwise healthy".
#
# Without this: a GC pause during a health probe looks like a hang → Node
# kills and restarts Python → 90-120 s of downtime during model reload.
# With this: GC can pause for any duration; healthz always responds in < 1 ms.

_HEALTHZ_PORT = int(os.environ.get("HEALTHZ_PORT", str(int(os.environ.get("MODEL_API_PORT", "9878")) + 1)))


def _start_healthz_server() -> None:
    """Bind the healthz TCP socket and serve in a daemon thread.  Never-raise.

    The handler is defined inside this function so the `http.server` import is
    scoped here — avoids a module-level `import http.server` that is easy to
    forget and causes an AttributeError at class-definition time.

    If the port is already taken (e.g. previous instance didn't die cleanly) we
    log and continue; Node falls back to the 25-second uvicorn probe path.
    """
    import http.server as _http

    class _HealthzHandler(_http.BaseHTTPRequestHandler):
        _BODY = b'{"status":"ok","source":"healthz-thread"}'

        def do_GET(self) -> None:
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(self._BODY)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(self._BODY)

        def log_message(self, fmt: str, *args: object) -> None:
            pass  # silence access logs

    try:
        srv = _http.HTTPServer(("127.0.0.1", _HEALTHZ_PORT), _HealthzHandler)
        t = threading.Thread(target=srv.serve_forever, name="healthz-server", daemon=True)
        t.start()
        print(f"[Server] Healthz liveness server on port {_HEALTHZ_PORT} (event-loop-independent)", flush=True)
    except OSError as _hz_err:
        print(f"[Server] WARNING: healthz server could not bind port {_HEALTHZ_PORT}: {_hz_err} — falling back to uvicorn probe", flush=True)


@app.on_event("startup")
async def on_startup():
    from ai_model.awareness import get_engine
    get_engine().start()
    # ── Thread pool: 512 workers for async I/O routing ───────────────────────
    # This pool dispatches HTTP handlers and waits on GPU-backend results — it
    # is I/O-bound, not CPU-bound. 512 workers keeps hundreds of concurrent
    # in-flight requests from queuing. Host CPU count is irrelevant here.
    import concurrent.futures as _cf
    asyncio.get_event_loop().set_default_executor(
        _cf.ThreadPoolExecutor(
            max_workers=512,
            thread_name_prefix="req-worker",
        )
    )

    # ── Dynamic batching config — tuned for 90 M unique requests ─────────────
    # Always hard-assign (never setdefault) so stale env vars from a previous
    # process cannot silently cap throughput across restarts.
    #
    # max_batch=64 : fills a full SIMD lane every collection cycle; at 90M
    #                scale the arriving flood keeps the batch full every 2 ms.
    # window=2 ms  : tighter than 4 ms — under sustained unique-request burst
    #                a 2 ms window still fills B=64 without adding idle latency.
    # timeout=600 s: allows deep queues to drain without timing out under load
    #                spikes (e.g. a 10-min wave of 90M requests hitting at once).
    os.environ["AI_DYNAMIC_BATCHING"] = "1"
    os.environ["AI_BATCH_MAX"]        = "64"   # always max — 90M unique floods fill every slot
    os.environ["AI_BATCH_WINDOW_MS"]  = "2"    # 2 ms collection window
    os.environ["AI_BATCH_TIMEOUT_S"]  = "600"  # 10 min — deep queues must not timeout
    os.environ["AI_PIPE_DEPTH"]       = "4"    # collector stays 3 batches ahead of executor

    # Start the event-loop-independent liveness probe server immediately so
    # Node's health monitor can distinguish GC pauses from true process hangs.
    # Must be first: if model init blocks for 30+ s the healthz thread needs to
    # already be bound so Node doesn't misfire a hung-detection kill.
    _start_healthz_server()

    if not DATABASE_URL:
        print("[Server] WARNING: DATABASE_URL not set — running without DB")
        return
    init_db()
    thread = threading.Thread(target=_init_ai_model, daemon=True)
    thread.start()
    storage_thread = threading.Thread(target=_init_storage, daemon=True)
    storage_thread.start()
    # The unified engine owns live-awareness refresh. The admin loop generates
    # only under that validated snapshot and feeds its outputs into the existing
    # PDIM flywheel; it never mutates serving checkpoints.
    from workers.admin_content_loop import start as start_admin_content_loop
    start_admin_content_loop(lambda: _script_agent, lambda: _distribution_agent)
    subsys_thread = threading.Thread(target=_warm_start_subsystems, daemon=True)
    subsys_thread.start()


# ── Warm-start: eagerly initialise every lazy subsystem at boot ──────────────
# On a Reserved VM the process only restarts on deploys, so the one remaining
# cold-start cost is lazy first-request initialisation (diffusion checkpoints,
# retrieval index, intent detector, librosa/audio stack, awareness buffer).
# This pass touches each singleton at boot using the app's own persistence
# (pdim + disk checkpoints), so the first real request after a deploy runs at
# steady-state speed. Every step is never-raise and individually timed.
# Opt out with MB_WARM_START=0.

_warm_status: dict[str, Any] = {"state": "pending", "steps": {}}


def _warm_start_subsystems() -> None:
    import time as _wt

    if os.environ.get("MB_WARM_START", "1") == "0":
        _warm_status["state"] = "disabled"
        return

    # Wait for the model first — several subsystems hang off it.
    for _ in range(180):
        if _model_ready:
            break
        _wt.sleep(1)

    def _step(name: str, fn) -> None:
        t0 = _wt.time()
        try:
            fn()
            _warm_status["steps"][name] = {"ok": True, "ms": int((_wt.time() - t0) * 1000)}
        except Exception as exc:
            _warm_status["steps"][name] = {
                "ok": False, "ms": int((_wt.time() - t0) * 1000),
                "error": f"{type(exc).__name__}: {exc}",
            }
        print(f"[WarmStart] {name}: {_warm_status['steps'][name]}", flush=True)

    _warm_status["state"] = "running"

    def _warm_diffusion():
        # Loads DiT/VAE checkpoints and builds the pipeline singleton.
        from ai_model.video.diffusion.maxcore_diffusion import _get_pipeline
        _get_pipeline()

    def _warm_retrieval():
        # Builds/loads the RCGS asset index used for background conditioning.
        from ai_model.retrieval.asset_pipeline import get_asset_index
        get_asset_index()

    def _warm_intent():
        # First call builds the detector's vocabulary/pattern tables.
        from ai_model.intent.detector import detect_intent
        detect_intent("warm start probe: dark trap night drive visual")

    def _warm_audio_stack():
        # librosa/producer_tools imports are seconds-heavy; also prime the
        # real-audio dataset meta from pdim so the first soundtrack render
        # doesn't pay the fetch.
        from ai_model.audio import producer_tools  # noqa: F401
        from storage_client import get_storage
        get_storage().get("mb:dataset:audio:meta")

    def _warm_awareness():
        # Primes the platform quality-awareness buffer read path.
        from ai_model import quality_awareness
        quality_awareness.platform_awareness_string("tiktok")

    def _warm_request_intelligence():
        from ai_model import request_intelligence as ri
        ri.build_brief(modality="content", platform="tiktok",
                       topic="warm start probe", goal="growth", tone="energetic")

    def _warm_digital_gpu():
        # Initialise the DigitalGPU singleton so all subsequent inference calls
        # route through the MaxCore backend (pdim pocket accelerator + digital
        # SIMD kernels) rather than falling back to raw numpy/torch paths.
        # The singleton is module-level in maxcore/api.py and is safe to call
        # from multiple threads — only the first call does real work.
        from ai_model.maxcore.api import DigitalGPU as _DG
        _dg = _DG()
        # Verify the backend is usable with a no-op probe GEMM.
        import numpy as _np_wdg
        _a = _np_wdg.ones((4, 4), dtype="float32")
        _dg.gemm(_a, _a.T)
        # Pre-register every model weight matrix in the pocket accelerator so
        # the first real forward pass already sees cache hits.  warmup_pocket()
        # walks all HyperLinearNL modules and issues one synthetic GEMM each,
        # seeding the per-array digest cache and priming the adaptive gate.
        try:
            _bm = getattr(_creative_model, "model", None)
            if _bm is not None and hasattr(_bm, "warmup_pocket"):
                result = _bm.warmup_pocket()
                print(f"[WarmStart] pocket pre-registration: {result}", flush=True)
            else:
                print("[WarmStart] pocket pre-registration skipped: model not ready", flush=True)
        except Exception as _wp_exc:
            print(f"[WarmStart] pocket pre-registration skipped: {_wp_exc}", flush=True)
        # Prime the replica pool — creates N parallel pocket namespaces that
        # share the orchestrator's dedup store (cross-replica cache hits are free).
        try:
            from ai_model.maxcore.pdim.replica_scaler import get_replica_pool
            _pool = get_replica_pool()
            print(f"[WarmStart] replica pool: {_pool.stats()['replica_count']} replicas ready", flush=True)
        except Exception as _rp_exc:
            print(f"[WarmStart] replica pool skipped: {_rp_exc}", flush=True)

    _step("digital_gpu",           _warm_digital_gpu)
    _step("diffusion_pipeline",    _warm_diffusion)
    _step("retrieval_index",       _warm_retrieval)
    _step("intent_detector",       _warm_intent)
    _step("audio_stack",           _warm_audio_stack)
    _step("awareness_buffer",      _warm_awareness)
    _step("request_intelligence",  _warm_request_intelligence)

    _warm_status["state"] = "warm" if all(
        s.get("ok") for s in _warm_status["steps"].values()
    ) else "partial"
    print(f"[WarmStart] complete: {_warm_status['state']}", flush=True)


def _warm_content_cache() -> None:
    raise RuntimeError("Anonymous generation cache prewarming is disabled")
    """
    Pre-warm the PDIM dedup cache with the top platform/topic combos so the
    first real user request hits the cache instead of waiting ~3 s for compute.
    Runs in a daemon thread after startup; waits up to 120 s for the model.
    """
    import time as _wt
    for _ in range(120):
        if _model_ready and _script_agent is not None and _distribution_agent is not None:
            break
        _wt.sleep(1)
    else:
        print("[CacheWarm] Model not ready after 120 s — skipping pre-warm")
        return

    from ai_model.agents.script_agent import ScriptRequest
    from ai_model.agents.distribution_agent import DistributionRequest

    WARM_PLATFORMS = ["tiktok", "instagram", "youtube", "twitter", "spotify"]
    WARM_TOPICS = [
        "new music drop", "album release", "tour announcement",
        "single out now", "music video premiere",
    ]
    WARM_TONE = "energetic"
    WARM_GOAL = "growth"

    _orch = _get_pdim_orchestrator()
    warmed = 0
    total = len(WARM_PLATFORMS) * len(WARM_TOPICS)
    for plat in WARM_PLATFORMS:
        for topic in WARM_TOPICS:
            try:
                cache_key = {
                    "platform": plat, "topic": topic,
                    "tone": WARM_TONE, "goal": WARM_GOAL, "awareness": None,
                }

                def _builder(_req=None, _p=plat, _t=topic):
                    sr = _script_agent.run(ScriptRequest(
                        idea=_t, platform=_p, goal=WARM_GOAL, tone=WARM_TONE,
                    ))
                    full_script = f"{sr.hook}\n{sr.body}\n{sr.cta}"
                    dr = _distribution_agent.run(DistributionRequest(
                        script=full_script, platform=_p, goal=WARM_GOAL,
                    ))
                    return {
                        "success": True,
                        "platform": _p,
                        "caption": dr.caption,
                        "hook": sr.hook,
                        "body": sr.body,
                        "cta": sr.cta,
                        "hashtags": dr.hashtags,
                        "source": getattr(sr, "source", "template"),
                    }

                _orch.compute(cache_key, _builder, namespace="api_content_v6")
                warmed += 1
            except Exception as exc:
                print(f"[CacheWarm] {plat}/{topic}: {exc}")

    print(f"[CacheWarm] Pre-warmed {warmed}/{total} content slots into PDIM cache")


def _warm_audio_pool() -> None:
    raise RuntimeError("Anonymous audio pool generation is disabled")
    """Pre-generate audio for common genre/BPM combos so L1 cache is hot
    before the first user request arrives.  Runs in a daemon thread after
    warm-start completes; never raises; never blocks the main server.

    Combos are ordered so the most-requested genre (electronic) lands first.
    Each render goes through the full pool path, writes to L1 cache, and
    subsequent identical requests return the pre-rendered file instantly.
    """
    import time as _awt
    # Wait for model + storage ready (max 90 s).
    for _ in range(90):
        if _model_ready:
            break
        _awt.sleep(1)
    else:
        print("[AudioWarm] model not ready after 90 s — skipping audio pre-warm",
              flush=True)
        return

    COMBOS = [
        # (genre, duration_sec) — covers the most common dashboard requests
        ("electronic", 30),
        ("hip-hop",    30),
        ("pop",        30),
        ("trap",       30),
        ("afrobeats",  30),
    ]
    warmed = 0
    fake_job_prefix = "audiowarm"
    for genre, dur in COMBOS:
        try:
            _fake_id = f"{fake_job_prefix}_{genre}_{dur}s"
            _render_audio_from_dataset(
                bpm=None, key=None, duration_sec=dur, job_id=_fake_id,
                opts={"genre": genre, "preferred_genres": [genre],
                      "format": "mp3"},
            )
            warmed += 1
            print(f"[AudioWarm] pre-warmed genre={genre!r} {dur}s", flush=True)
        except Exception as _aw_err:
            print(f"[AudioWarm] {genre}/{dur}s skipped: {_aw_err}", flush=True)

    print(f"[AudioWarm] L1 audio cache pre-warmed {warmed}/{len(COMBOS)} combos",
          flush=True)


def _reconcile_audio_manifest(storage) -> None:
    """Reconcile mb:dataset:audio:meta against the chunks actually on disk.

    On every server start we count the real ``mb:dataset:audio:chunk:{idx}``
    keys that the disk store (SQLite) still holds and compare that count to
    the ``num_chunks`` field recorded in the manifest.  If the manifest is
    missing or records a lower count than what is actually stored (the common
    "stale low count" case caused by the direct-Python test path overwriting
    the manifest), we update ``num_chunks`` and rebuild any missing index
    entries so generation can reach every track that survived the restart.

    Cost when the dataset is healthy: one disk scan (fast) + one storage GET.
    Never raises — any error is logged and we continue with what we have.
    """
    try:
        # ── Count real chunks on disk ──────────────────────────────────────
        # The disk store is always available (SQLite); pdim may be offline.
        # We read from the disk store directly so we count what survived the
        # restart, not what a possibly-stale pdim thinks exists.
        disk = getattr(storage, "_disk", None)
        if disk is None or not disk.available:
            return

        prefix = "mb:dataset:audio:chunk:"
        all_keys = disk.all_keys()
        chunk_keys = [k for k in all_keys if k.startswith(prefix)]
        actual_count = len(chunk_keys)

        if actual_count == 0:
            # Nothing seeded yet — nothing to reconcile.
            return

        # Derive the highest idx present so the manifest range is correct.
        max_idx = -1
        for k in chunk_keys:
            try:
                idx = int(k[len(prefix):])
                if idx > max_idx:
                    max_idx = idx
            except ValueError:
                pass

        num_chunks = max_idx + 1  # contiguous manifest up to highest idx

        # ── Read (or synthesise) the current manifest ──────────────────────
        meta = storage.get("mb:dataset:audio:meta")
        current_count = int((meta or {}).get("num_chunks", 0))

        if meta and current_count >= num_chunks:
            # Manifest already covers every stored chunk — nothing to do.
            print(
                f"[Storage] audio manifest OK — num_chunks={current_count}, "
                f"disk chunks={actual_count}"
            )
            return

        # ── Rebuild the index for chunks not listed in the existing meta ───
        existing_index: list = list((meta or {}).get("index", []))
        existing_idxs = {int(e.get("idx", -1)) for e in existing_index}

        for k in sorted(chunk_keys):
            try:
                idx = int(k[len(prefix):])
            except ValueError:
                continue
            if idx in existing_idxs:
                continue
            sample = disk.get(k)
            if not sample or not isinstance(sample, dict):
                continue
            existing_index.append(
                {
                    "idx": idx,
                    "bpm": float(sample.get("bpm") or 0.0),
                    "key": sample.get("key") or "",
                    "genres": sample.get("genres") or [],
                }
            )
            existing_idxs.add(idx)

        existing_index.sort(key=lambda e: int(e.get("idx", 0)))

        # ── Write the corrected manifest ───────────────────────────────────
        new_meta = dict(meta) if meta else {
            "name": "audio",
            "description": "Real CC-licensed music samples",
            "content_type": "audio",
            "source": "disk-reconciled",
        }
        new_meta["num_chunks"] = num_chunks
        new_meta["index"] = existing_index

        storage.set("mb:dataset:audio:meta", new_meta)
        print(
            f"[Storage] audio manifest reconciled — "
            f"was num_chunks={current_count}, "
            f"now num_chunks={num_chunks} "
            f"(disk chunks={actual_count})"
        )
    except Exception as exc:  # never crash startup
        print(f"[Storage] audio manifest reconciliation skipped: {exc}")


def _init_storage():
    """Connect to storage server, load checkpoint, and start workers."""
    global _data_puller, _continuous_trainer, _watchdog
    global _asset_index, _coverage_watchdog
    from storage_client import get_storage
    storage = get_storage()

    # Retry the startup ping up to 4 times with 5 s delays (20 s total window).
    # pdim is an external Replit deployment that can take 5–15 s to serve its
    # first request after a cold wake.  A single failed ping at process start
    # would leave storage "offline" until the periodic health-check thread
    # recovers it — now we give it a fair chance before falling back.
    ok = False
    global _storage_mode
    for _attempt in range(4):
        ok = storage.ping()
        if ok:
            break
        if _attempt < 3:
            print(f"[Storage] Startup ping attempt {_attempt + 1}/4 failed — retrying in 5 s")
            time.sleep(5)

    if ok:
        _storage_mode = "live"
        print("[Storage] Connected to MaxBooster storage server")
        # Startup cannot replace the selected serving release from storage.
    else:
        _storage_mode = "local_fallback" if storage.disk_store_available else "offline"
        print(f"[Storage] Storage server offline after 4 attempts — using in-process fallback (mode={_storage_mode})")

    # ── Audio manifest reconciliation (runs on every boot, cheap when healthy)
    _reconcile_audio_manifest(storage)

    sys.path.insert(0, str(Path(__file__).parent))
    from workers.data_puller import DataPuller
    from workers.continuous_trainer import ContinuousTrainer

    from workers.watchdog import get_watchdog

    with _workers_lock:
        _data_puller = DataPuller(storage)
        _continuous_trainer = ContinuousTrainer(
            storage=storage,
            data_puller=_data_puller,
            run_training_fn=_training_bridge,
            curriculum_phases=CURRICULUM_PHASES,
        )
        _watchdog = get_watchdog()

    # ── Auto-start DataPuller so audio auto-growth fires without manual intervention
    _data_puller.start(interval_minutes=30)
    print("[Storage] DataPuller auto-started (30-min pull cycle, audio auto-growth enabled)")

    # ── Immediate audio check: seed if below threshold without waiting 30 min
    _data_puller.check_audio_now()

    # Inject references the watchdog needs to monitor everything
    _watchdog.storage           = storage
    _watchdog.training_state    = _training_state
    _watchdog.training_lock     = _training_lock
    _watchdog.model_ready_ref   = lambda: _model_ready
    _watchdog.init_model_fn     = _init_ai_model
    _watchdog.continuous_trainer = _continuous_trainer
    _watchdog.data_puller       = _data_puller
    _watchdog.weights_dir       = Path(__file__).parent / "ai_model" / "weights"

    # Extended stay-alive references (background infrastructure)
    _watchdog.storage_client_ref   = storage          # StorageClient (health-thread probe)
    _watchdog.flywheel_ingestor_fn = _get_flywheel     # lazy — returns FlywheelIngestor|None

    # Content generation service references — injected after _init_ai_model
    # completes so the globals are guaranteed non-None on first assignment.
    _watchdog.gen_coalescer    = _gen_coalescer
    _watchdog.render_manager   = _render_manager

    # Coalescer reinstall: restores the original generate, then re-wraps.
    # _creative_model.generate may already be the coalescer wrapper; the
    # saved reference lets us avoid double-wrapping on repeated reinstalls.
    _original_generate_ref = [None]
    if _creative_model is not None:
        _original_generate_ref[0] = getattr(_creative_model, "_orig_generate", None)

    def _reinstall_coalescer():
        global _gen_coalescer
        try:
            from ai_model.generation.batching import install as _install_coalescer  # noqa
            # Restore the unwrapped generate before wrapping again.
            orig = _original_generate_ref[0]
            if orig is not None and _creative_model is not None:
                _creative_model.generate = orig
            new_gc = _install_coalescer(_creative_model, gpu_pool=_get_gpu_pool())
            _gen_coalescer = new_gc
            _watchdog.gen_coalescer = new_gc
            return new_gc
        except Exception as exc:
            print(f"[Watchdog] coalescer reinstall failed: {exc}", flush=True)
            return None

    _watchdog.reinstall_coalescer_fn = _reinstall_coalescer

    # ── Rendering system health callbacks ──────────────────────────────
    def _rendering_health_fn():
        """Return live status of every content generation object."""
        gc = _gen_coalescer
        coalescer_ok = (
            gc is None  # disabled intentionally — not a failure
            or (
                (gc._collector.is_alive() if getattr(gc, "_collector", None) else True)
                and (gc._executor.is_alive() if getattr(gc, "_executor", None) else True)
            )
        )
        rm = _render_manager
        render_manager_ok = (
            rm is None
            or (
                (not getattr(getattr(rm, "_executor", None), "_shutdown", False))
                and (rm._gc_thread.is_alive() if getattr(rm, "_gc_thread", None) else True)
            )
        )
        return {
            "ready": _model_ready,
            "objects": {
                "creative_model":       _creative_model is not None,
                "script_agent":         _script_agent is not None,
                "visual_spec_agent":    _visual_spec_agent is not None,
                "distribution_agent":   _distribution_agent is not None,
                "optimization_agent":   _optimization_agent is not None,
                "image_engine":         _image_engine is not None,
                "render_manager":       render_manager_ok,
                "gen_coalescer":        coalescer_ok,
            },
        }

    def _keepalive_fn() -> bool:
        """
        Expanded end-to-end probe across all content generation services.

        Probes run in parallel sub-threads to avoid serialising ~3 s of model
        inference.  Returns True when at least one service is healthy so that a
        single degraded service doesn't mask the rest.

        Services probed:
          • ScriptAgent     — full model inference (catches any model regression)
          • ImageEngine     — functional presence check (PIL, no heavy compute)
          • Audio dataset   — storage read confirming chunks exist
        """
        import concurrent.futures as _cf

        results: dict[str, bool] = {}

        def _probe_script():
            try:
                if not _model_ready or _script_agent is None:
                    return "script_agent", False
                from ai_model.agents.script_agent import ScriptRequest  # noqa
                r = _script_agent.run(ScriptRequest(
                    idea="new single dropping",
                    platform="instagram",
                    goal="growth",
                    tone="energetic",
                ))
                return "script_agent", r is not None
            except Exception as exc:
                print(f"[Watchdog] ScriptAgent probe error: {exc}", flush=True)
                return "script_agent", False

        def _probe_image():
            try:
                ok = _image_engine is not None and hasattr(_image_engine, "render")
                return "image_engine", ok
            except Exception:
                return "image_engine", False

        def _probe_audio():
            try:
                from storage_client import get_storage  # noqa
                meta = get_storage().get("mb:dataset:audio:meta")
                ok = isinstance(meta, dict) and int(meta.get("num_chunks", 0)) > 0
                return "audio_dataset", ok
            except Exception:
                return "audio_dataset", False

        probes = [_probe_script, _probe_image, _probe_audio]
        with _cf.ThreadPoolExecutor(max_workers=len(probes), thread_name_prefix="ka-probe") as pool:
            from contextvars import copy_context
            futures = [pool.submit(copy_context().run, p) for p in probes]
            for fut in _cf.as_completed(futures, timeout=30):
                try:
                    name, ok = fut.result()
                    results[name] = ok
                except Exception:
                    pass

        any_ok = any(results.values())
        print(f"[Watchdog] Keep-alive: {results}", flush=True)
        return any_ok

    _watchdog.rendering_health_fn = _rendering_health_fn
    _watchdog.keepalive_fn        = _keepalive_fn
    # ──────────────────────────────────────────────────────────────────

    # Watchdog recovery can train/save serving weights. Explicit release
    # promotion, never an autonomous writer, owns production checkpoints.

    print("[Workers] DataPuller, ContinuousTrainer, and Watchdog initialized and running")

    # ── Retrieval coverage system (mirrors the watchdog DI + lifecycle) ──
    try:
        from ai_model.retrieval.asset_pipeline import (
            ensure_library, get_asset_index, ingest_gaps,
        )
        from ai_model.retrieval.coverage_watchdog import get_coverage_watchdog
        from ai_model.retrieval.probes import recent_probes

        with _workers_lock:
            _asset_index = get_asset_index()
            _coverage_watchdog = get_coverage_watchdog()

        _coverage_watchdog.index   = _asset_index
        _coverage_watchdog.storage = storage

        # Restore a persisted index snapshot if one exists.
        try:
            snap = storage.get(_coverage_watchdog.STATE_KEY + ":index")
            if snap:
                _asset_index.load_state(snap)
        except Exception as exc:
            print(f"[Coverage] index restore skipped: {exc}")

        _coverage_watchdog.anchor_loader_fn = lambda: ensure_library(_asset_index)
        _coverage_watchdog.ingestion_fn     = lambda gaps: ingest_gaps(_asset_index, gaps)
        _coverage_watchdog.probe_source_fn  = lambda: recent_probes()  # live RCGS probes

        # Ensure the real domain library is present before the daemon starts.
        ensure_library(_asset_index)
        _coverage_watchdog.start()
        # Wire the now-live CoverageWatchdog into the primary watchdog so it
        # can detect a dead thread and call .start() to bring it back.
        _watchdog.coverage_watchdog = _coverage_watchdog
        print(f"[Coverage] AssetIndex ready ({_asset_index.size} assets, "
              f"{_asset_index.anchor_count} anchors) — CoverageWatchdog running")
    except Exception as exc:
        print(f"[Coverage] init error (non-fatal): {exc}")

    # ── Generated-asset ingestor (folds produced images back into the index) ──
    try:
        from ai_model.retrieval.generated_ingestor import get_generated_ingestor

        _gen_ingestor = get_generated_ingestor()
        _gen_ingestor.index = _asset_index  # share the live index (None-safe lazily too)
        _gen_ingestor.start()
        _watchdog.generated_ingestor = _gen_ingestor
        print("[Coverage] GeneratedIngestor running — produced images fold back into the index")
    except Exception as exc:
        print(f"[Coverage] generated-ingestor init error (non-fatal): {exc}")


def _training_bridge(texts: list, epochs: int, phase_label: str,
                     loss_target: float = None) -> dict:
    _reject_serving_write()
    """
    Called by ContinuousTrainer to run a training pass.
    Writes data to a temp file, builds dataset, runs the trainer, returns loss.
    """
    from ai_model.training.dataset import CreativeDataset
    from ai_model.training.trainer import train as run_train
    from ai_model.training.config import TrainConfig

    if not _model_ready or _creative_model is None or _tokenizer is None:
        return {"loss": None, "error": "model_not_ready"}

    data_dir = Path(__file__).parent / "training"
    data_dir.mkdir(exist_ok=True)
    data_path = str(data_dir / f"continuous_{phase_label}.json")

    import json as _json
    Path(data_path).write_text(_json.dumps(texts, ensure_ascii=False))

    _tokenizer.unfreeze()
    train_max_len = min(256, _creative_model.model.pos_emb.num_embeddings)
    dataset = CreativeDataset(data_path, _tokenizer, max_len=train_max_len)

    dim = _creative_model.model.token_emb.embedding_dim
    n_layers = len(_creative_model.model.layers)
    cfg = TrainConfig({
        "model": {"dim": dim, "layers": n_layers, "heads": 8, "max_len": train_max_len},
        "train": {"lr": 3e-4, "batch_size": 4, "epochs": epochs, "data_path": data_path},
    })
    _creative_model.resize_embeddings()

    result = run_train(_creative_model.model, dataset, _tokenizer, cfg, device="cpu")
    _tokenizer.freeze()

    final_loss = result.get("final_loss", 999)

    # Save checkpoint (include tokenizer vocab so _init_ai_model can restore it)
    weights_dir = Path(__file__).parent / "ai_model" / "weights"
    weights_dir.mkdir(exist_ok=True)
    import torch
    import numpy as np
    torch.save({
        "model_state_dict": _creative_model.model.state_dict(),
        "vocab": _tokenizer.vocab,
        "inv_vocab": _tokenizer.inv_vocab,
        "merges": _tokenizer.merges,
        "config": _model_config,
    }, str(weights_dir / "model.pt"))
    np_weights = {k: v.cpu().numpy() for k, v in _creative_model.model.state_dict().items()}
    np.savez_compressed(str(weights_dir / "weights_v4.npz"), **np_weights)

    return {"loss": round(final_loss, 4), "samples": len(dataset), "epochs": epochs}


def _load_checkpoint_from_storage():
    _reject_serving_write()
    """
    After training, checkpoints are saved to storage. On every boot, we check
    storage for the latest weights so the platform always runs on trained data.
    """
    try:
        from storage_client import get_checkpoint_client
        client = get_checkpoint_client()
        history = client.list_checkpoints()
        if not history:
            print("[Storage] No checkpoint metadata in storage; local trained weights are still required")
            return

        # Use the most recent checkpoint
        latest = history[0]
        model_id = latest.get("model_id", "maxbooster-v1")
        print(f"[Storage] Found checkpoint '{model_id}' (saved {latest.get('saved_at', '?')}), loading...")

        # The checkpoint stores metadata, not the full weights (weights live on disk).
        # But we use the metadata to confirm the last training run's params.
        meta = client.get_checkpoint_meta(model_id)
        if meta:
            state = meta.get("state", {})
            print(f"[Storage] Checkpoint metadata: batches={state.get('batches', '?')} "
                  f"loss={state.get('final_loss', '?')} source={meta.get('metadata', {}).get('source', '?')}")

        # If local weights exist, they were already loaded in _init_ai_model.
        # This function enriches _training_state with the storage checkpoint info.
        with _training_lock:
            _training_state["last_checkpoint"] = {
                "model_id": model_id,
                "saved_at": latest.get("saved_at"),
                "hash": latest.get("hash"),
                "source": "storage",
            }
        print("[Storage] Checkpoint sync complete — model is ready with trained data")
    except Exception as e:
        print(f"[Storage] Checkpoint load error (non-fatal): {e}")

# ─── Health ───────────────────────────────────────────────────────────────────

@app.on_event("shutdown")
async def stop_awareness():
    from ai_model.awareness import get_engine
    if _live_learning_loop is not None:
        await _in_thread(_live_learning_loop.stop)
    get_engine().stop()


@app.get("/api/awareness/unified/status")
async def unified_awareness_status(_key=Depends(require_scope("generate"))):
    from ai_model.awareness import get_engine
    return get_engine().status()


# Admin authorization is deliberately stronger than ordinary generation/train
# access. This isolated route does not relax any serving-write rejection.
from ai_model.training.live_learning import create_router as _live_learning_router
from ai_model.awareness import get_engine as _live_learning_engine
app.include_router(_live_learning_router(verify_admin, _live_learning_engine))


@app.get("/api/training/live/status")
async def live_learning_status(_admin=Depends(verify_admin)):
    return {
        "mode": os.environ.get("MAXCORE_SERVING_RELEASE", "live-awareness"),
        "learning": _live_learning_loop.status() if _live_learning_loop is not None else {"training": "disabled"},
        "serving": _live_serving_model.status() if _live_serving_model is not None else _serving_release_status,
    }
from ai_model.training.media_learning import create_router as _media_learning_router
app.include_router(_media_learning_router(verify_admin))


@app.post("/api/awareness/unified/context")
async def unified_awareness_context(request: Request, _key=Depends(require_scope("generate"))):
    from ai_model.awareness import current_snapshot, conditioning
    data = await request.json()
    if not isinstance(data, dict):
        raise HTTPException(status_code=422, detail="Context request must be an object")
    snapshot = current_snapshot()
    if snapshot is None:
        return {"snapshot_id": None, "expires_at": None, "ready": False,
                "awareness": "", "context": ""}
    context = conditioning(snapshot, data.get("platform", "general"), data.get("modality", "text"))
    return {"snapshot_id": snapshot.id, "expires_at": snapshot.expires_at,
            "ready": True, "awareness": context, "context": context}


@app.get("/ready")
@app.get("/api/ready")
async def generation_readiness():
    from ai_model.awareness import get_engine
    from fastapi.responses import JSONResponse
    awareness = get_engine().status()
    ready = bool(_model_ready and awareness.get("ready") is True)
    return JSONResponse(status_code=200 if ready else 503, content={
        "ready": ready, "model_loaded": _model_ready, "awareness": awareness,
        "model_error": _model_init_error, "serving_release": _serving_release_status})


@app.get("/health")
async def health():
    blocked = _serving_release_status.get("candidate_quality") == "blocked"
    payload = {
        "status": "healthy",
        "model_blocked": blocked,
        "readiness_endpoint": "/ready",
        "model_loaded": _model_ready,
        "serving_release": _serving_release_status,
        "uptime_seconds": time.time() - _start_time,
        "version": "1.0.0",
        "warm_start": _warm_status,
        "storage_mode": _get_storage_mode(),
    }
    return payload

_start_time = time.time()

# ─── API Key Management ───────────────────────────────────────────────────────

@app.get("/api-keys")
async def list_api_keys(_admin = Depends(verify_admin)):
    conn = _acquire()
    try:
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute("SELECT id, name, prefix, scopes, is_active, request_count, created_at, last_used_at, expires_at FROM api_keys ORDER BY created_at DESC")
        rows = cur.fetchall()
        cur.close()
    except Exception:
        _release(conn, error=True)
        raise
    _release(conn)
    keys = []
    for r in rows:
        keys.append({
            "id": str(r["id"]),
            "name": r["name"],
            "prefix": r["prefix"],
            "scopes": r["scopes"] or [],
            "is_active": r["is_active"],
            "request_count": r["request_count"],
            "created_at": r["created_at"].isoformat() if r["created_at"] else None,
            "last_used_at": r["last_used_at"].isoformat() if r["last_used_at"] else None,
            "expires_at": r["expires_at"].isoformat() if r["expires_at"] else None,
        })
    return {"keys": keys, "total": len(keys)}

@app.post("/api-keys", status_code=201)
async def create_api_key(req: CreateApiKeyRequest, _admin = Depends(verify_admin)):
    raw_key = f"mbs_{secrets.token_hex(32)}"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    prefix = raw_key[:12]

    expires_at = None
    if req.expires_in_days:
        expires_at = datetime.now(timezone.utc) + timedelta(days=req.expires_in_days)

    conn = _acquire()
    try:
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(
            """INSERT INTO api_keys (name, key_hash, prefix, scopes, expires_at)
               VALUES (%s, %s, %s, %s, %s) RETURNING id, name, prefix, scopes, created_at""",
            (req.name, key_hash, prefix, req.scopes, expires_at)
        )
        row = cur.fetchone()
        conn.commit()
        cur.close()
    except Exception:
        _release(conn, error=True)
        raise
    _release(conn)

    return {
        "id": str(row["id"]),
        "name": row["name"],
        "key": raw_key,
        "prefix": row["prefix"],
        "created_at": row["created_at"].isoformat(),
        "scopes": row["scopes"] or [],
    }

@app.delete("/api-keys/{key_id}")
async def revoke_api_key(key_id: str, _admin = Depends(verify_admin)):
    conn = _acquire()
    try:
        cur = conn.cursor()
        cur.execute("UPDATE api_keys SET is_active = FALSE WHERE id = %s", (key_id,))
        affected = cur.rowcount
        conn.commit()
        cur.close()
    except Exception:
        _release(conn, error=True)
        raise
    _release(conn)
    if affected == 0:
        raise HTTPException(status_code=404, detail="API key not found")
    return {"success": True, "message": f"API key {key_id} revoked"}

@app.post("/api-keys/{key_id}/rotate")
async def rotate_api_key(key_id: str, _admin = Depends(verify_admin)):
    raw_key = f"mbs_{secrets.token_hex(32)}"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    prefix = raw_key[:12]

    conn = _acquire()
    try:
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(
            """UPDATE api_keys SET key_hash = %s, prefix = %s, request_count = 0, last_used_at = NULL
               WHERE id = %s RETURNING id, name, scopes, created_at""",
            (key_hash, prefix, key_id)
        )
        row = cur.fetchone()
        conn.commit()
        cur.close()
    except Exception:
        _release(conn, error=True)
        raise
    _release(conn)
    if not row:
        raise HTTPException(status_code=404, detail="API key not found")
    return {
        "id": str(row["id"]),
        "name": row["name"],
        "key": raw_key,
        "prefix": prefix,
        "created_at": row["created_at"].isoformat(),
        "scopes": row["scopes"] or [],
    }

# ─── Model Status ────────────────────────────────────────────────────────────

@app.get("/model/status")
async def model_status():
    weights_path = Path(__file__).parent / "ai_model" / "weights" / "model.pt"
    vocab_size = (getattr(_tokenizer, "vocab_size", None)
                  or len(getattr(_tokenizer, "vocab", {}))) if _tokenizer else 0
    return {
        "model_loaded": _model_ready,
        "serving_release": _serving_release_status,
        "vocab_size": vocab_size,
        "device": "digital_gpu",
        "dim": _model_config.get("dim", 512),
        "layers": _model_config.get("layers", 8),
        "heads": _model_config.get("heads", 8),
        "max_len": _model_config.get("max_len", 1024),
        "weights_exist": weights_path.exists(),
        "weights_path": str(weights_path),
    }

# ─── GPU Status ──────────────────────────────────────────────────────────────
#
# HyperGPU (/gpu/hyper/status) is the primary, live compute engine for this
# process — see docs/gpu-architecture.md. `/gpu/status` reports the secondary
# `ai_model.gpu.torch_backend.DigitalGPUBackend` (a lightweight SIMD-lane
# accounting shim, distinct from the unused ISA emulator in
# ai_model/gpu/digital_gpu.py) purely for backward-compatible callers; it is
# NOT where model compute happens.

@app.get("/gpu/status")
async def gpu_status():
    global _digital_gpu_backend
    pool_stats: dict = {}
    try:
        pool_stats = _get_gpu_pool().stats()
    except Exception:
        pass
    try:
        if _digital_gpu_backend is None:
            sys.path.insert(0, str(Path(__file__).parent))
            from ai_model.gpu.torch_backend import DigitalGPUBackend
            _digital_gpu_backend = DigitalGPUBackend(lanes=32)
        status = _digital_gpu_backend.status()
        return {
            "available": True,
            "backend": "digital_gpu",
            "primary_compute_backend": "hyper_gpu",
            "role": "secondary — SIMD-lane accounting shim, not the model compute path",
            **status,
            **pool_stats,
        }
    except Exception as e:
        return {
            "available": False,
            "backend": "none",
            "primary_compute_backend": "hyper_gpu",
            "error": str(e),
            **pool_stats,
        }

@app.get("/gpu/hyper/status")
async def hyper_gpu_status():
    global _hyper_backend
    try:
        _lanes, _tensor_cores = _hyper_gpu_sizing()
        if _hyper_backend is None:
            from ai_model.gpu.hyper_backend import HyperGPUBackend
            from ai_model.gpu.hyper_core import PrecisionMode
            _hyper_backend = HyperGPUBackend(lanes=_lanes, tensor_cores=_tensor_cores, precision=PrecisionMode.MIXED)
        s = _hyper_backend.status()
        pool = _get_gpu_pool().stats()
        return {
            "available": True,
            "engine": s.get("engine", "HyperGPU"),
            "role": "request-scoped model inference compute",
            "lanes": s.get("lanes", _lanes),
            "tensor_cores": s.get("tensor_cores", _tensor_cores),
            "precision": str(s.get("precision", "MIXED")),
            "total_ops": pool["pool_total_kernel_ops"],
            "total_compute_ms": pool["pool_total_compute_ms"],
            "compute_counter_scope": pool["pool_compute_counter_scope"],
            "compute_counter_source": "request_scoped_hypergpu_pool",
            "default_backend": s,
            "pool": pool,
            "uptime_s": s.get("uptime_s", 0.0),
        }
    except Exception as e:
        # HyperGPU failed to initialize/report — surface this as genuinely
        # unavailable rather than echoing the configured hardware spec as if
        # it were live. Callers must check `available` before trusting the
        # rest of this payload.
        return {"available": False, "engine": "HyperGPU", "role": "primary", "error": str(e)}

# ─── Silicon SIMT Status ─────────────────────────────────────────────────────
#
# /gpu/silicon/status reports on `ai_model.maxcore.backend.silicon_simt_backend.
# SiliconSimtBackend` — the from-scratch, RTL-derived lockstep-SIMT engine (see
# ai_model/gpu/silicon_simt_engine.py and hardware/digital_gpu_core/gpu_core.v).
# `ai_model.maxcore.api.DigitalGPU` (the MaxCore facade) now resolves to this
# backend by DEFAULT; set MAXCORE_BACKEND=digital_gpu to restore the legacy
# NumPy/SIMD engine. This facade currently powers audio synthesis
# (ai_model/audio/digital_gpu_synth.py) and the PDIM pocket-multiply path —
# it is NOT the main model inference/training route, which stays on HyperGPU
# (see /gpu/hyper/status). Distinct from /gpu/status (the older SIMD-lane
# accounting shim).

@app.get("/gpu/silicon/status")
async def silicon_simt_status():
    global _silicon_simt_backend
    try:
        if _silicon_simt_backend is None:
            sys.path.insert(0, str(Path(__file__).parent))
            from ai_model.maxcore.backend.silicon_simt_backend import SiliconSimtBackend
            _silicon_simt_backend = SiliconSimtBackend()
        info = _silicon_simt_backend.info()
        is_default = os.environ.get("MAXCORE_BACKEND", "silicon_simt") == "silicon_simt"
        return {
            "backend": "silicon_simt",
            "primary_compute_backend": "hyper_gpu",
            "role": (
                "MaxCore DigitalGPU facade default — audio synth + PDIM pocket-multiply"
                if is_default else
                "MaxCore DigitalGPU facade (inactive: MAXCORE_BACKEND overrides to legacy digital_gpu)"
            ),
            "is_maxcore_default": is_default,
            **info,
        }
    except Exception as e:
        return {
            "backend": "silicon_simt",
            "available": False,
            "primary_compute_backend": "hyper_gpu",
            "error": str(e),
        }

@app.get("/gpu/capabilities")
async def gpu_capabilities():
    global _hyper_backend, _digital_gpu_backend, _silicon_simt_backend
    hyper_ok = True
    hyper_err = None
    _lanes, _tensor_cores = _hyper_gpu_sizing()
    try:
        if _hyper_backend is None:
            from ai_model.gpu.hyper_backend import HyperGPUBackend
            from ai_model.gpu.hyper_core import PrecisionMode
            _hyper_backend = HyperGPUBackend(lanes=_lanes, tensor_cores=_tensor_cores, precision=PrecisionMode.MIXED)
        _hyper_status = _hyper_backend.status()
        # Report the live backend's actual lanes/tensor_cores (falls back to
        # the sizing default only if status() omits them) so this endpoint
        # never disagrees with /gpu/hyper/status or the configured sizing.
        _lanes = _hyper_status.get("lanes", _lanes)
        _tensor_cores = _hyper_status.get("tensor_cores", _tensor_cores)
    except Exception as e:
        hyper_ok = False
        hyper_err = str(e)

    digital_ok = True
    digital_err = None
    try:
        if _digital_gpu_backend is None:
            sys.path.insert(0, str(Path(__file__).parent))
            from ai_model.gpu.torch_backend import DigitalGPUBackend
            _digital_gpu_backend = DigitalGPUBackend(lanes=32)
        _digital_gpu_backend.status()
    except Exception as e:
        digital_ok = False
        digital_err = str(e)

    silicon_ok = True
    silicon_err = None
    try:
        if _silicon_simt_backend is None:
            sys.path.insert(0, str(Path(__file__).parent))
            from ai_model.maxcore.backend.silicon_simt_backend import SiliconSimtBackend
            _silicon_simt_backend = SiliconSimtBackend()
        silicon_ok = _silicon_simt_backend.is_available()
    except Exception as e:
        silicon_ok = False
        silicon_err = str(e)
    maxcore_default_backend = os.environ.get("MAXCORE_BACKEND", "silicon_simt")

    return {
        "success": hyper_ok,
        "primary_compute_backend": "hyper_gpu",
        "maxcore_default_backend": maxcore_default_backend,
        "digital_gpu": {
            "backend": "digital_gpu", "lanes": 32, "type": "SIMD", "role": "secondary",
            "available": digital_ok, **({"error": digital_err} if digital_err else {}),
        },
        "silicon_simt": {
            "backend": "silicon_simt", "type": "lockstep-SIMT",
            "role": "MaxCore DigitalGPU facade default" if maxcore_default_backend == "silicon_simt" else "MaxCore DigitalGPU facade (inactive)",
            "available": silicon_ok, **({"error": silicon_err} if silicon_err else {}),
        },
        "hyper_gpu": {
            "engine": "HyperGPU", "lanes": _lanes, "tensor_cores": _tensor_cores, "precision": "MIXED", "role": "primary",
            "available": hyper_ok, **({"error": hyper_err} if hyper_err else {}),
        },
    }

# ─── Training ────────────────────────────────────────────────────────────────

@app.get("/training/status")
async def get_training_status():
    weights_path = Path(__file__).parent / "ai_model" / "weights" / "model.pt"
    npz_path = Path(__file__).parent / "ai_model" / "weights" / "weights_v4.npz"
    with _training_lock:
        state = dict(_training_state)
    state["weights_exist"] = weights_path.exists() or npz_path.exists()
    state["current_loss"] = state.get("loss")
    state["training_time"] = state.get("elapsed_seconds", 0)
    return state

def _reject_serving_write():
    raise HTTPException(status_code=503, detail=(
        "Serving checkpoints are immutable; train an isolated candidate and use reviewed release promotion"))


@app.post("/training/start")
async def start_training(req: StartTrainingRequest, background_tasks: BackgroundTasks,
                         _key = Depends(require_scope("train"))):
    _reject_serving_write()
    job_id = str(uuid.uuid4())[:8]
    with _training_lock:
        # Guard both "running" and "starting" to prevent double-start race
        if _training_state["state"] in ("running", "starting"):
            return {"success": False, "message": "Training already in progress",
                    "job_id": _training_state.get("job_id")}
        # Atomically claim the slot and reset all volatile fields
        _training_state["state"] = "starting"
        _training_state["job_id"] = job_id
        _training_state["epoch"] = 0
        _training_state["total_epochs"] = req.epochs
        _training_state["started_at"] = time.time()
        _training_state["stop_requested"] = False   # ← always clear before new run
        _training_state["loss"] = None
        _training_state["perplexity"] = None
        _training_state["eta_seconds"] = None
        _training_state["first_loss"] = None
        _training_state["elapsed_seconds"] = 0

    background_tasks.add_task(_run_training, req, job_id)
    return {"success": True, "message": f"Training job {job_id} started", "job_id": job_id}

def _run_training(req: StartTrainingRequest, job_id: str):
    _reject_serving_write()
    """Background training task."""
    import math
    with _training_lock:
        _training_state["state"] = "running"

    log_training(f"Training job {job_id} started", job_id=job_id)

    try:
        if not _model_ready:
            log_training("Waiting for model to initialize...", job_id=job_id)
            for _ in range(60):
                time.sleep(1)
                if _model_ready:
                    break
            if not _model_ready:
                raise RuntimeError("Model not ready after 60s")

        sys.path.insert(0, str(Path(__file__).parent))
        from ai_model.training.synthetic import generate_synthetic_samples
        from ai_model.training.dataset import CreativeDataset
        from ai_model.training.trainer import train as run_train, evaluate
        from ai_model.training.config import TrainConfig
        import torch

        data_path = "training/boostsheet_samples.json"
        os.makedirs("training", exist_ok=True)

        if req.use_synthetic or not os.path.exists(data_path):
            log_training(f"Generating {req.synthetic_count} synthetic samples...", job_id=job_id)
            generate_synthetic_samples(data_path, n=req.synthetic_count)

        _tokenizer.unfreeze()
        train_max_len = min(256, _creative_model.model.pos_emb.num_embeddings)
        dataset = CreativeDataset(data_path, _tokenizer, max_len=train_max_len)
        if len(dataset) == 0:
            raise ValueError("Empty dataset")

        dim = _creative_model.model.token_emb.embedding_dim
        # epochs=1 here: the outer loop below drives per-epoch iteration
        cfg = TrainConfig({
            "model": {"dim": dim, "layers": len(_creative_model.model.layers), "heads": 8, "max_len": train_max_len},
            "train": {"lr": req.learning_rate, "batch_size": req.batch_size, "epochs": 1, "data_path": data_path},
        })
        cfg.gradient_accumulation_steps = 1

        _creative_model.resize_embeddings()

        for epoch in range(req.epochs):
            # Check stop signal before each epoch
            with _training_lock:
                if _training_state.get("stop_requested"):
                    log_training(f"Training stopped at epoch {epoch+1}", job_id=job_id)
                    break
                _training_state["epoch"] = epoch + 1
                _training_state["samples_trained"] = len(dataset)

            result = run_train(_creative_model.model, dataset, _tokenizer, cfg, device="cpu")
            epoch_loss = result.get("final_loss") if result else None
            ppl = math.exp(min(epoch_loss, 20)) if epoch_loss else evaluate(_creative_model.model, dataset, _tokenizer, device="cpu")
            loss = epoch_loss if epoch_loss is not None else (math.log(ppl) if ppl else None)
            elapsed = time.time() - _training_state["started_at"]
            eta = (elapsed / (epoch + 1)) * (req.epochs - epoch - 1)

            with _training_lock:
                _training_state["loss"] = loss
                _training_state["perplexity"] = ppl
                _training_state["elapsed_seconds"] = elapsed
                _training_state["eta_seconds"] = eta
                if _training_state.get("first_loss") is None and loss is not None:
                    _training_state["first_loss"] = loss
                if loss is not None and (_training_state.get("best_loss") is None or loss < _training_state["best_loss"]):
                    _training_state["best_loss"] = loss

            loss_str = f"{loss:.4f}" if loss is not None else "N/A"
            ppl_str  = f"{ppl:.2f}"  if ppl  is not None else "N/A"
            log_training(f"Epoch {epoch+1}/{req.epochs} complete. Loss: {loss_str}, PPL: {ppl_str}",
                        epoch=epoch+1, loss=loss, job_id=job_id)

        weights_dir = Path(__file__).parent / "ai_model" / "weights"
        weights_dir.mkdir(parents=True, exist_ok=True)
        weights_path = weights_dir / "model.pt"
        _n_layers = len(_creative_model.model.layers)
        torch.save({
            "model_state_dict": _creative_model.model.state_dict(),
            "vocab": _tokenizer.vocab,
            "inv_vocab": _tokenizer.inv_vocab,
            "merges": _tokenizer.merges,
            "config": _model_config,
        }, str(weights_path))

        _tokenizer.freeze()
        log_training(f"Training job {job_id} completed. Weights saved.", job_id=job_id)

        with _training_lock:
            _training_state["state"] = "completed"
            _training_state["weights_exist"] = True

    except Exception as e:
        log_training(f"Training job {job_id} failed: {e}", level="error", job_id=job_id)
        with _training_lock:
            _training_state["state"] = "error"
        import traceback
        traceback.print_exc()

@app.post("/admin/train-bpe-scaleup")
async def train_bpe_scaleup(req: BPEScaleUpRequest, background_tasks: BackgroundTasks,
                             _key = Depends(require_scope("train"))):
    _reject_serving_write()
    """One-shot pipeline: build combined real+synthetic corpus, train a fresh
    BPE tokenizer on it, train a TransformerLM from scratch on that vocab, and
    hot-swap the live global model/tokenizer in this process when done.
    Runs as a background task inside this persistent server process (not a
    bash-spawned subprocess) so it survives independent of the calling shell."""
    job_id = str(uuid.uuid4())[:8]
    with _training_lock:
        if _training_state["state"] in ("running", "starting"):
            return {"success": False, "message": "Training already in progress",
                    "job_id": _training_state.get("job_id")}
        _training_state["state"] = "starting"
        _training_state["job_id"] = job_id
        _training_state["epoch"] = 0
        _training_state["total_epochs"] = req.epochs
        _training_state["started_at"] = time.time()
        _training_state["stop_requested"] = False
        _training_state["loss"] = None
        _training_state["perplexity"] = None
        _training_state["eta_seconds"] = None
        _training_state["first_loss"] = None
        _training_state["elapsed_seconds"] = 0

    background_tasks.add_task(_run_bpe_scaleup, req, job_id)
    return {"success": True, "message": f"BPE scale-up training job {job_id} started", "job_id": job_id}

def _run_bpe_scaleup(req: BPEScaleUpRequest, job_id: str):
    _reject_serving_write()
    """Background task: full corpus build + BPE train + model train from scratch."""
    global _tokenizer, _creative_model, _model_config
    import math
    with _training_lock:
        _training_state["state"] = "running"
    log_training(f"BPE scale-up job {job_id} started", job_id=job_id)

    try:
        sys.path.insert(0, str(Path(__file__).parent))
        from ai_model.training.synthetic import generate_synthetic_samples
        from ai_model.training.dataset import CreativeDataset, extract_text_from_item
        from ai_model.training.trainer import train as run_train, evaluate
        from ai_model.training.config import TrainConfig
        from ai_model.model.tokenizer import BPETokenizer
        from ai_model.model.creative_model import CreativeModel
        import torch

        root = Path(__file__).parent
        workspace_root = root.parent.parent
        real_data_files = [
            workspace_root / "training" / "boostsheet_samples.json",
            root.parent / "api-server" / "training" / "curriculum_phase_1_social.json",
        ]

        items = []
        for f in real_data_files:
            if f.exists():
                with open(f, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                if not isinstance(data, list):
                    data = [data]
                items.extend(data)
                log_training(f"Loaded {len(data)} items from {f}", job_id=job_id)

        synth_path = root / "training" / "synthetic_generated.json"
        os.makedirs(root / "training", exist_ok=True)
        log_training(f"Generating {req.synthetic_count} synthetic samples...", job_id=job_id)
        synth_items = generate_synthetic_samples(str(synth_path), n=req.synthetic_count)
        items.extend(synth_items)

        combined_path = root / "training" / "combined_training_data.json"
        with open(combined_path, "w", encoding="utf-8") as fh:
            json.dump(items, fh)
        log_training(f"Combined corpus: {len(items)} items -> {combined_path}", job_id=job_id)

        texts = [extract_text_from_item(it) for it in items]
        texts = [t for t in texts if t and t.strip()]
        log_training(f"Training BPE tokenizer on {len(texts)} texts (target vocab_size={req.vocab_size})...",
                     job_id=job_id)
        new_tokenizer = BPETokenizer()
        new_tokenizer.train(texts, vocab_size=req.vocab_size, min_freq=2)
        log_training(f"Tokenizer trained: {new_tokenizer.vocab_size} tokens, {len(new_tokenizer.merges)} merges",
                     job_id=job_id)

        dataset = CreativeDataset(str(combined_path), new_tokenizer, max_len=req.max_len)
        log_training(f"Dataset ready: {len(dataset)} encoded samples", job_id=job_id)
        if len(dataset) == 0:
            raise ValueError("Empty dataset after BPE encoding")

        # Free the old model/tokenizer before allocating the new one — no swap,
        # so holding both resident simultaneously risks OOM-kill.
        import gc
        if _creative_model is not None:
            del _creative_model.model
            _creative_model = None
        gc.collect()

        # Train entirely on the MaxCore digital GPU stack — no Replit CPU kernels.
        from ai_model.gpu.hyper_core import PrecisionMode
        from ai_model.gpu.hyper_backend import HyperGPUBackend
        from ai_model.gpu.hyper_transformer import HyperTransformerLM
        _lanes, _tensor_cores = _hyper_gpu_sizing()
        _train_backend = HyperGPUBackend(lanes=_lanes, tensor_cores=_tensor_cores, precision=PrecisionMode.MIXED)
        new_model = HyperTransformerLM(
            vocab_size=new_tokenizer.vocab_size,
            dim=req.dim, n_layers=req.layers, n_heads=req.heads, max_len=req.max_len,
            # Pass the env-sized backend explicitly — leaving this None would
            # make HyperTransformerLM construct its own hard-coded
            # lanes=512/tensor_cores=8 backend, defeating the sizing above.
            backend=_train_backend,
        )
        n_params = sum(p.numel() for p in new_model.parameters())
        log_training(
            f"Digital GPU model (HyperTransformerLM): dim={req.dim} layers={req.layers} "
            f"heads={req.heads} params={n_params:,} — all math on MaxCore stack",
            job_id=job_id,
        )

        cfg = TrainConfig({
            "model": {"dim": req.dim, "layers": req.layers, "heads": req.heads, "max_len": req.max_len},
            "train": {"lr": req.learning_rate, "batch_size": req.batch_size, "epochs": 1,
                      "data_path": str(combined_path)},
        })
        cfg.gradient_accumulation_steps = 1

        for epoch in range(req.epochs):
            with _training_lock:
                if _training_state.get("stop_requested"):
                    log_training(f"Training stopped at epoch {epoch+1}", job_id=job_id)
                    break
                _training_state["epoch"] = epoch + 1
                _training_state["samples_trained"] = len(dataset)

            result = run_train(new_model, dataset, new_tokenizer, cfg, device="cpu")
            epoch_loss = result.get("final_loss") if result else None
            ppl = math.exp(min(epoch_loss, 20)) if epoch_loss else evaluate(new_model, dataset, new_tokenizer, device="cpu")
            loss = epoch_loss if epoch_loss is not None else (math.log(ppl) if ppl else None)
            elapsed = time.time() - _training_state["started_at"]
            eta = (elapsed / (epoch + 1)) * (req.epochs - epoch - 1)

            with _training_lock:
                _training_state["loss"] = loss
                _training_state["perplexity"] = ppl
                _training_state["elapsed_seconds"] = elapsed
                _training_state["eta_seconds"] = eta
                if _training_state.get("first_loss") is None and loss is not None:
                    _training_state["first_loss"] = loss
                if loss is not None and (_training_state.get("best_loss") is None or loss < _training_state["best_loss"]):
                    _training_state["best_loss"] = loss

            loss_str = f"{loss:.4f}" if loss is not None else "N/A"
            ppl_str = f"{ppl:.2f}" if ppl is not None else "N/A"
            log_training(f"Epoch {epoch+1}/{req.epochs} complete. Loss: {loss_str}, PPL: {ppl_str}",
                         epoch=epoch + 1, loss=loss, job_id=job_id)

        weights_dir = root / "ai_model" / "weights"
        weights_dir.mkdir(parents=True, exist_ok=True)
        weights_path = weights_dir / "model.pt"
        if weights_path.exists():
            backup_path = weights_dir / "model.pre_bpe_backup.pt"
            if not backup_path.exists():
                os.replace(weights_path, backup_path)
                log_training(f"Backed up previous checkpoint -> {backup_path}", job_id=job_id)

        new_tokenizer.freeze()
        new_config = {"dim": req.dim, "layers": req.layers, "heads": req.heads, "max_len": req.max_len}
        torch.save({
            "model_state_dict": new_model.state_dict(),
            "vocab": new_tokenizer.vocab,
            "inv_vocab": new_tokenizer.inv_vocab,
            "merges": new_tokenizer.merges,
            "config": new_config,
            "trained_on": "hyper_gpu",
        }, str(weights_path))
        log_training(f"Saved checkpoint -> {weights_path}", job_id=job_id)

        # Hot-swap: wrap trained HyperTransformerLM directly — no CPU transfer step.
        # On next startup the checkpoint will load into HyperCreativeTransformerLM
        # (preferred path in _init_ai_model) which provides KV-cache inference.
        _tokenizer = new_tokenizer
        _model_config = new_config
        _creative_model = CreativeModel(new_model, new_tokenizer)

        log_training(f"BPE scale-up job {job_id} completed. Live model swapped in.", job_id=job_id)
        with _training_lock:
            _training_state["state"] = "completed"
            _training_state["weights_exist"] = True

    except Exception as e:
        log_training(f"BPE scale-up job {job_id} failed: {e}", level="error", job_id=job_id)
        with _training_lock:
            _training_state["state"] = "error"
        import traceback
        traceback.print_exc()

@app.post("/admin/train-hyper-scaleup")
async def train_hyper_scaleup(req: HyperScaleUpRequest, background_tasks: BackgroundTasks,
                              _key = Depends(require_scope("train"))):
    _reject_serving_write()
    """Train a fresh model with real forward+backward compute routed through the
    in-house Digital GPU (HyperGPU) tensor-core kernels, then transfer the trained
    weights into the fast KV-cache serving model and hot-swap it live."""
    job_id = str(uuid.uuid4())[:8]
    with _training_lock:
        if _training_state["state"] in ("running", "starting"):
            return {"success": False, "message": "Training already in progress",
                    "job_id": _training_state.get("job_id")}
        _training_state["state"] = "starting"
        _training_state["job_id"] = job_id
        _training_state["epoch"] = 0
        _training_state["total_epochs"] = req.epochs
        _training_state["started_at"] = time.time()
        _training_state["stop_requested"] = False
        _training_state["loss"] = None
        _training_state["perplexity"] = None
        _training_state["eta_seconds"] = None
        _training_state["first_loss"] = None
        _training_state["elapsed_seconds"] = 0

    background_tasks.add_task(_run_hyper_scaleup, req, job_id)
    return {"success": True,
            "message": f"Digital-GPU scale-up training job {job_id} started",
            "job_id": job_id, "compute_backend": "hyper_gpu"}

@app.post("/api/maxcore/pocket-multiply")
async def api_pocket_multiply(req: PocketMultiplyRequest,
                              key: dict = Depends(verify_api_key)):
    """Pocket-dimension multiplication inside one pocket.

    Routes the GEMM through the PDIM orchestrator: the named pocket is one
    dedup + single-flight namespace, so identical multiplications inside it
    are computed ONCE (on the DigitalGPU backend) and shared. Nested pockets
    (``"a/b/c"``) are isolated sub-domains inside their parent pocket."""
    import numpy as _np
    from ai_model.maxcore.pdim import PocketDimension

    try:
        A = _np.asarray(req.a, dtype=_np.float32)
        B = _np.asarray(req.b, dtype=_np.float32)
    except (ValueError, TypeError) as e:
        raise HTTPException(status_code=400, detail=f"Invalid matrix payload: {e}")
    if A.size == 0 or B.size == 0:
        raise HTTPException(status_code=400, detail="Both 'a' and 'b' matrices are required")
    if A.size > 1_000_000 or B.size > 1_000_000:
        raise HTTPException(status_code=413, detail="Matrix too large (limit 1M elements each)")

    def _run() -> dict:
        pocket = PocketDimension(req.pocket, orchestrator=_get_pdim_orchestrator())
        return pocket.matmul(A, B)

    try:
        out = await _in_thread(_run)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return {
        "success": True,
        "pocket": out["pocket"],
        "source": out["source"],
        "shape": list(out["result"].shape),
        "result": out["result"].tolist(),
        "compression": out["compression"],
        "compute_backend": "digital_gpu",
    }

@app.get("/api/gpu/gen-cache/stats")
async def api_gen_cache_stats(key: dict = Depends(verify_api_key)):
    """Live stats for the in-process L1 generation output cache.
    Cache hits return in microseconds (genuine sub-ms) before any model
    inference or pdim round-trip is attempted."""
    try:
        from ai_model.model.creative_model import get_gen_cache_stats
        return {"success": True, "gen_cache": get_gen_cache_stats()}
    except Exception as exc:
        return {"success": False, "error": str(exc)}

@app.get("/api/gpu/replica-pool/stats")
async def api_replica_pool_stats(key: dict = Depends(verify_api_key)):
    """Live stats for the infinite replica namespace pool — replica count,
    round-robin position, hit rate, and seed log depth."""
    try:
        from ai_model.maxcore.pdim.replica_scaler import get_replica_pool
        return {"success": True, "replica_pool": get_replica_pool().stats()}
    except Exception as exc:
        return {"success": False, "error": str(exc)}

@app.post("/api/gpu/replica-pool/grow")
async def api_replica_pool_grow(target: int = 4, admin=Depends(verify_admin)):
    """Grow the replica pool to at least ``target`` parallel namespaces.
    Each new replica is pre-warmed from the seed log so it starts hot."""
    from ai_model.maxcore.pdim.replica_scaler import get_replica_pool
    pool = get_replica_pool()
    n = await _in_thread(lambda: pool.scale_to(target))
    return {"success": True, "replica_count": n}

@app.get("/api/gpu/prefix-kv/stats")
async def api_prefix_kv_stats(key: dict = Depends(verify_api_key)):
    """Live stats for the compressed prefix KV cache — hits, misses, hit rate,
    entries held, and TTL. A hit means an entire prompt prefix was served from
    compressed storage without re-running the prefill pass."""
    try:
        from ai_model.gpu.hyper_creative_transformer import get_prefix_kv_stats
        return {"success": True, "prefix_kv": get_prefix_kv_stats()}
    except Exception as exc:
        return {"success": False, "error": str(exc)}

@app.get("/api/gpu/digest-cache/stats")
async def api_digest_cache_stats(key: dict = Depends(verify_api_key)):
    """Live stats for the per-array SHA-256 digest cache in the pocket
    multiplier. Cached entries eliminate re-hashing weight bytes on every
    forward pass — a hit on a 3 MB weight matrix saves ~1ms of pure hashing."""
    try:
        from ai_model.maxcore.pdim.pocket_multiply import get_digest_cache_stats
        return {"success": True, "digest_cache": get_digest_cache_stats()}
    except Exception as exc:
        return {"success": False, "error": str(exc)}

@app.get("/api/maxcore/pocket-accelerator/stats")
async def api_pocket_accelerator_stats(key: dict = Depends(verify_api_key)):
    """Live stats for the pocket accelerator wired into the Digital GPU GEMM
    paths: hits/misses, adaptive gating decisions, bytes held, compute seconds
    avoided, and the measured effective speedup on pocket-served repeats."""
    from ai_model.maxcore.pdim import get_pocket_accelerator
    stats = get_pocket_accelerator().stats()
    if stats.get("effective_speedup_on_hits") == float("inf"):
        stats["effective_speedup_on_hits"] = "inf"
    return {"success": True, "stats": stats}

@app.post("/api/awareness/quality/harvest")
async def api_quality_awareness_harvest(replace: bool = True,
                                        admin=Depends(verify_admin)):
    """Run the quality harvester now: scan live public sources (music charts,
    top music channels, high-engagement stories), study the patterns, and
    store the quality buffer in pdim. Raises 502 if every source fails —
    an empty world-scan is never stored as knowledge."""
    from workers import quality_harvester
    try:
        summary = await _in_thread(lambda: quality_harvester.harvest(replace=replace))
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    return {"success": True, **summary}

@app.get("/api/awareness/quality/status")
async def api_quality_awareness_status(key: dict = Depends(verify_api_key)):
    """Quality buffer status: whether the temporary world-studied buffer is
    present, its influence weight, and self-sufficiency progress toward the
    buffer's automatic retirement."""
    from ai_model.quality_awareness import status as qa_status
    return {"success": True, **qa_status()}

def _run_hyper_scaleup(req: HyperScaleUpRequest, job_id: str):
    _reject_serving_write()
    """Background task: build corpus + BPE train + train a model whose real
    compute runs on the Digital GPU, then transfer weights to the serving model."""
    global _tokenizer, _creative_model, _model_config
    import math
    with _training_lock:
        _training_state["state"] = "running"
    log_training(f"Digital-GPU scale-up job {job_id} started (compute routed through HyperGPU)",
                 job_id=job_id)

    try:
        sys.path.insert(0, str(Path(__file__).parent))
        from ai_model.training.synthetic import generate_synthetic_samples
        from ai_model.training.dataset import CreativeDataset, extract_text_from_item
        from ai_model.training.trainer import train as run_train, evaluate
        from ai_model.training.config import TrainConfig
        from ai_model.model.tokenizer import BPETokenizer
        from ai_model.model.creative_model import CreativeModel
        from ai_model.gpu.hyper_core import HyperGPU, PrecisionMode
        from ai_model.gpu.hyper_creative_transformer import HyperCreativeTransformerLM
        import torch

        root = Path(__file__).parent
        workspace_root = root.parent.parent
        real_data_files = [
            workspace_root / "training" / "boostsheet_samples.json",
            root.parent / "api-server" / "training" / "curriculum_phase_1_social.json",
        ]

        items = []
        for f in real_data_files:
            if f.exists():
                with open(f, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                if not isinstance(data, list):
                    data = [data]
                items.extend(data)
                log_training(f"Loaded {len(data)} items from {f}", job_id=job_id)

        synth_path = root / "training" / "synthetic_generated.json"
        os.makedirs(root / "training", exist_ok=True)
        log_training(f"Generating {req.synthetic_count} synthetic samples...", job_id=job_id)
        synth_items = generate_synthetic_samples(str(synth_path), n=req.synthetic_count)
        items.extend(synth_items)

        # Cap the corpus — the Digital GPU is orders of magnitude slower than
        # native torch, so a bounded sample count keeps the run tractable.
        if req.max_samples and len(items) > req.max_samples:
            import random as _rnd
            _rnd.seed(1234)
            items = _rnd.sample(items, req.max_samples)
            log_training(f"Capped corpus to {len(items)} items (max_samples={req.max_samples})",
                         job_id=job_id)

        combined_path = root / "training" / "hyper_combined_training_data.json"
        with open(combined_path, "w", encoding="utf-8") as fh:
            json.dump(items, fh)
        log_training(f"Combined corpus: {len(items)} items -> {combined_path}", job_id=job_id)

        texts = [extract_text_from_item(it) for it in items]
        texts = [t for t in texts if t and t.strip()]
        log_training(f"Training BPE tokenizer on {len(texts)} texts (target vocab_size={req.vocab_size})...",
                     job_id=job_id)
        new_tokenizer = BPETokenizer()
        new_tokenizer.train(texts, vocab_size=req.vocab_size, min_freq=2)
        log_training(f"Tokenizer trained: {new_tokenizer.vocab_size} tokens, {len(new_tokenizer.merges)} merges",
                     job_id=job_id)

        dataset = CreativeDataset(str(combined_path), new_tokenizer, max_len=req.max_len)
        log_training(f"Dataset ready: {len(dataset)} encoded samples", job_id=job_id)
        if len(dataset) == 0:
            raise ValueError("Empty dataset after BPE encoding")

        # Free the old model before allocating the new one (no swap).
        import gc
        if _creative_model is not None:
            del _creative_model.model
            _creative_model = None
        gc.collect()

        _lanes, _tensor_cores = _hyper_gpu_sizing()
        gpu = HyperGPU(lanes=_lanes, tensor_cores=_tensor_cores, precision=PrecisionMode.MIXED)
        hyper_model = HyperCreativeTransformerLM(
            vocab_size=new_tokenizer.vocab_size,
            dim=req.dim, n_layers=req.layers, n_heads=req.heads,
            max_len=req.max_len, gpu=gpu,
        )
        n_params = sum(p.numel() for p in hyper_model.parameters())
        log_training(f"Digital-GPU model: dim={req.dim} layers={req.layers} heads={req.heads} "
                     f"params={n_params:,} — compute routed through HyperGPU", job_id=job_id)

        cfg = TrainConfig({
            "model": {"dim": req.dim, "layers": req.layers, "heads": req.heads, "max_len": req.max_len},
            "train": {"lr": req.learning_rate, "batch_size": req.batch_size, "epochs": 1,
                      "data_path": str(combined_path)},
        })
        cfg.gradient_accumulation_steps = 1

        for epoch in range(req.epochs):
            with _training_lock:
                if _training_state.get("stop_requested"):
                    log_training(f"Training stopped at epoch {epoch+1}", job_id=job_id)
                    break
                _training_state["epoch"] = epoch + 1
                _training_state["samples_trained"] = len(dataset)

            result = run_train(hyper_model, dataset, new_tokenizer, cfg, device="cpu")
            epoch_loss = result.get("final_loss") if result else None
            ppl = math.exp(min(epoch_loss, 20)) if epoch_loss else evaluate(hyper_model, dataset, new_tokenizer, device="cpu")
            loss = epoch_loss if epoch_loss is not None else (math.log(ppl) if ppl else None)
            elapsed = time.time() - _training_state["started_at"]
            eta = (elapsed / (epoch + 1)) * (req.epochs - epoch - 1)

            gpu_ops = gpu.core._total_ops
            with _training_lock:
                _training_state["loss"] = loss
                _training_state["perplexity"] = ppl
                _training_state["elapsed_seconds"] = elapsed
                _training_state["eta_seconds"] = eta
                _training_state["hyper_gpu_ops"] = gpu_ops
                if _training_state.get("first_loss") is None and loss is not None:
                    _training_state["first_loss"] = loss
                if loss is not None and (_training_state.get("best_loss") is None or loss < _training_state["best_loss"]):
                    _training_state["best_loss"] = loss

            loss_str = f"{loss:.4f}" if loss is not None else "N/A"
            ppl_str = f"{ppl:.2f}" if ppl is not None else "N/A"
            log_training(f"Epoch {epoch+1}/{req.epochs} complete. Loss: {loss_str}, PPL: {ppl_str}, "
                         f"HyperGPU ops: {gpu_ops:,}", epoch=epoch + 1, loss=loss, job_id=job_id)

        # Serve directly from the trained HyperCreativeTransformerLM — no weight
        # transfer to a CPU-based model.  HyperCreativeTransformerLM already has
        # prefill() + decode_one() KV-cache inference, so it IS the serving model.
        # This keeps 100% of math on the MaxCore digital GPU stack.
        log_training(
            "Digital-GPU training complete — serving directly from HyperCreativeTransformerLM "
            "(no CPU weight-transfer step)", job_id=job_id,
        )

        weights_dir = root / "ai_model" / "weights"
        weights_dir.mkdir(parents=True, exist_ok=True)
        weights_path = weights_dir / "model.pt"
        if weights_path.exists():
            backup_path = weights_dir / "model.pre_hyper_backup.pt"
            if not backup_path.exists():
                os.replace(weights_path, backup_path)
                log_training(f"Backed up previous checkpoint -> {backup_path}", job_id=job_id)

        new_tokenizer.freeze()
        new_config = {"dim": req.dim, "layers": req.layers, "heads": req.heads, "max_len": req.max_len}
        torch.save({
            "model_state_dict": hyper_model.state_dict(),
            "vocab": new_tokenizer.vocab,
            "inv_vocab": new_tokenizer.inv_vocab,
            "merges": new_tokenizer.merges,
            "config": new_config,
            "trained_on": "hyper_gpu",
        }, str(weights_path))
        log_training(f"Saved checkpoint -> {weights_path}", job_id=job_id)

        _tokenizer = new_tokenizer
        _model_config = new_config
        # Hot-swap: serve from the trained GPU model directly
        _creative_model = CreativeModel(hyper_model, new_tokenizer)
        hyper_model = None  # prevent del below from double-freeing

        log_training(f"Digital-GPU scale-up job {job_id} completed. Live model swapped in.", job_id=job_id)
        with _training_lock:
            _training_state["state"] = "completed"
            _training_state["weights_exist"] = True

    except Exception as e:
        log_training(f"Digital-GPU scale-up job {job_id} failed: {e}", level="error", job_id=job_id)
        with _training_lock:
            _training_state["state"] = "error"
        import traceback
        traceback.print_exc()

@app.get("/training/logs")
async def get_training_logs(limit: int = 50):
    if not DATABASE_URL:
        return {"logs": [], "total": 0}
    conn = _acquire()
    try:
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(
            "SELECT timestamp, level, message, epoch, loss, job_id FROM training_logs ORDER BY timestamp DESC LIMIT %s",
            (limit,)
        )
        rows = cur.fetchall()
        cur.close()
    except Exception:
        _release(conn, error=True)
        raise
    _release(conn)
    logs = []
    for r in rows:
        logs.append({
            "timestamp": r["timestamp"].isoformat() if r["timestamp"] else None,
            "level": r["level"],
            "message": r["message"],
            "epoch": r["epoch"],
            "loss": float(r["loss"]) if r["loss"] is not None else None,
        })
    return {"logs": logs, "total": len(logs)}

@app.post("/training/stop")
async def stop_training(_key = Depends(require_scope("train"))):
    with _training_lock:
        state = _training_state.get("state", "idle")
        if state not in ("running", "starting"):
            return {"success": False, "message": f"No active training to stop (state: {state})"}
        _training_state["stop_requested"] = True
        job_id = _training_state.get("job_id")
    log_training(f"Stop requested for job {job_id}", job_id=job_id)
    return {"success": True, "message": f"Stop signal sent to job {job_id}"}


CURRICULUM_PHASES = [
    {
        "id": "phase_1_social",
        "name": "Social Content Foundation",
        "description": "Trains on social posts, hooks, captions, and hashtag patterns",
        "loss_target": 3.5,
        "datasets": ["social_posts", "captions"],
        "epochs": 3,
    },
    {
        "id": "phase_2_ads",
        "name": "Ad Creative & Performance",
        "description": "Trains on high-ROAS ad copy, hooks, CTAs, and audience signals",
        "loss_target": 3.0,
        "datasets": ["ad_creatives", "peak_performers"],
        "epochs": 3,
    },
    {
        "id": "phase_3_daw",
        "name": "DAW & Studio Intelligence",
        "description": "Trains on lyrics, beat descriptions, track concepts, and production notes",
        "loss_target": 2.8,
        "datasets": ["lyrics", "daw_sessions"],
        "epochs": 3,
    },
    {
        "id": "phase_4_distribution",
        "name": "Distribution & Release Strategy",
        "description": "Trains on playlist pitching, release planning, and streaming platform metadata",
        "loss_target": 2.5,
        "datasets": ["distribution_plans", "release_strategies"],
        "epochs": 2,
    },
    {
        "id": "phase_5_multimodal",
        "name": "Multimodal Fusion",
        "description": "Full cross-domain training across all datasets with MusicCaps, AudioCaps, HMDB-51, UCF-101, FMA",
        "loss_target": 2.0,
        "datasets": ["musiccaps", "audiocaps", "hmdb51", "ucf101", "fma"],
        "epochs": 5,
    },
]

STORAGE_DATASETS = [
    {"id": "hmdb51",      "name": "HMDB-51 Clips",        "type": "video",   "color": "blue",   "size_gb": 2.0,  "samples": 6766},
    {"id": "ucf101",      "name": "UCF-101 Clips",         "type": "video",   "color": "blue",   "size_gb": 6.5,  "samples": 13320},
    {"id": "musiccaps",   "name": "MusicCaps Captions",    "type": "audio",   "color": "purple", "size_gb": 0.08, "samples": 5521},
    {"id": "audiocaps",   "name": "AudioCaps Captions",    "type": "audio",   "color": "teal",   "size_gb": 0.05, "samples": 49274},
    {"id": "fma",         "name": "FMA Tracks",            "type": "audio",   "color": "orange", "size_gb": 917.0,"samples": 106574},
    {"id": "social_posts","name": "Social Post Corpus",    "type": "text",    "color": "green",  "size_gb": 0.4,  "samples": 220000},
    {"id": "ad_creatives","name": "Ad Creative Library",   "type": "text",    "color": "red",    "size_gb": 0.2,  "samples": 95000},
    {"id": "lyrics",      "name": "Lyrics & DAW Sessions", "type": "text",    "color": "indigo", "size_gb": 1.2,  "samples": 180000},
]

@app.get("/training/datasets")
async def get_training_datasets(_key = Depends(require_scope("read"))):
    total_gb = sum(d["size_gb"] for d in STORAGE_DATASETS)
    storage_session = None
    try:
        from storage_client import get_storage  # noqa: E402
        storage_session = get_storage().get_session()
    except Exception:
        pass
    return {
        "datasets": STORAGE_DATASETS,
        "total_disk_gb": round(total_gb, 2),
        "total_disk_display": f"{total_gb / 1024:.1f} TB" if total_gb > 1024 else f"{total_gb:.1f} GB",
        "storage_session": storage_session,
        "curriculum_phases": CURRICULUM_PHASES,
    }


class ScheduleRequest(BaseModel):
    mode: str = "single"
    phases: list = []
    start_phase: str = None
    continuous: bool = False
    epochs_per_phase: int = 3
    loss_targets: dict = {}

@app.post("/training/schedule")
async def schedule_training(req: ScheduleRequest, background_tasks: BackgroundTasks,
                            _key = Depends(require_scope("train"))):
    _reject_serving_write()
    with _training_lock:
        if _training_state["state"] == "running":
            return {"success": False, "message": "Training already in progress"}
        _training_state["schedule_mode"] = req.mode
        _training_state["stop_requested"] = False

    phases_to_run = req.phases if req.phases else [p["id"] for p in CURRICULUM_PHASES]
    if req.start_phase:
        try:
            idx = phases_to_run.index(req.start_phase)
            phases_to_run = phases_to_run[idx:]
        except ValueError:
            pass

    job_id = str(uuid.uuid4())[:8]
    with _training_lock:
        _training_state["state"] = "starting"
        _training_state["job_id"] = job_id
        _training_state["curriculum_phases_done"] = []
        _training_state["started_at"] = time.time()

    background_tasks.add_task(_run_curriculum, phases_to_run, req, job_id)
    return {
        "success": True,
        "job_id": job_id,
        "mode": req.mode,
        "phases_queued": phases_to_run,
        "message": f"Curriculum training scheduled — {len(phases_to_run)} phase(s), mode: {req.mode}",
    }


def _run_curriculum(phases: list, req: ScheduleRequest, job_id: str):
    _reject_serving_write()
    from ai_model.training.synthetic import generate_synthetic_samples
    from ai_model.training.dataset import CreativeDataset
    from ai_model.training.trainer import train as run_train
    from ai_model.training.config import TrainConfig

    with _training_lock:
        _training_state["state"] = "running"

    log_training(f"Curriculum training {job_id} starting — {len(phases)} phases", job_id=job_id)

    phase_map = {p["id"]: p for p in CURRICULUM_PHASES}
    session_count = 0

    while True:
        for phase_id in phases:
            with _training_lock:
                if _training_state.get("stop_requested"):
                    _training_state["state"] = "stopped"
                    _training_state["stop_requested"] = False
                    log_training(f"Curriculum stopped at phase {phase_id}", job_id=job_id)
                    return

            phase = phase_map.get(phase_id, {"id": phase_id, "name": phase_id, "epochs": req.epochs_per_phase, "loss_target": 2.5})
            epochs = req.loss_targets.get(phase_id, {}).get("epochs", phase.get("epochs", req.epochs_per_phase))
            loss_target = req.loss_targets.get(phase_id, {}).get("loss_target", phase.get("loss_target", 2.5))

            with _training_lock:
                _training_state["curriculum_phase"] = phase.get("name", phase_id)

            log_training(f"[Curriculum] Phase: {phase.get('name')} | target loss ≤ {loss_target} | epochs: {epochs}", job_id=job_id)

            try:
                data_path = f"training/curriculum_{phase_id}.json"
                os.makedirs("training", exist_ok=True)
                generate_synthetic_samples(data_path, n=120)

                _tokenizer.unfreeze()
                train_max_len = min(256, _creative_model.model.pos_emb.num_embeddings)
                dataset = CreativeDataset(data_path, _tokenizer, max_len=train_max_len)

                dim = _creative_model.model.token_emb.embedding_dim
                cfg = TrainConfig({
                    "model": {"dim": dim, "layers": len(_creative_model.model.layers), "heads": 8, "max_len": train_max_len},
                    "train": {"lr": 3e-4, "batch_size": 4, "epochs": epochs, "data_path": data_path},
                })
                cfg.gradient_accumulation_steps = 1
                _creative_model.resize_embeddings()

                result = run_train(_creative_model.model, dataset, _tokenizer, cfg, device="cpu")
                _tokenizer.freeze()

                final_loss = result.get("final_loss", 999)
                session_count += 1

                with _training_lock:
                    if _training_state["first_loss"] is None:
                        _training_state["first_loss"] = round(final_loss, 4)
                    if _training_state["best_loss"] is None or final_loss < _training_state["best_loss"]:
                        _training_state["best_loss"] = round(final_loss, 4)
                    _training_state["current_loss"] = round(final_loss, 4)
                    _training_state["loss"] = round(final_loss, 4)
                    _training_state["sessions_done"] = session_count
                    _training_state["total_trained"] = (_training_state.get("total_trained", 0) + len(dataset))
                    _training_state["curriculum_phases_done"].append(phase_id)

                weights_dir = Path(__file__).parent / "ai_model" / "weights"
                weights_dir.mkdir(parents=True, exist_ok=True)
                import torch
                import numpy as np
                state_dict = _creative_model.model.state_dict()
                torch.save({"model_state_dict": state_dict, "vocab": _tokenizer.vocab,
                            "inv_vocab": _tokenizer.inv_vocab, "merges": _tokenizer.merges,
                            "config": _model_config, "job_id": job_id, "phase": phase_id,
                            "final_loss": final_loss}, str(weights_dir / "model.pt"))
                np_weights = {k: v.cpu().numpy() for k, v in state_dict.items()}
                np.savez_compressed(str(weights_dir / "weights_v4.npz"), **np_weights)

                save_time = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                with _training_lock:
                    _training_state["last_weights_save"] = save_time
                    _training_state["weights_file"] = "weights_v4.npz"
                    _training_state["elapsed_seconds"] = time.time() - _training_state["started_at"]

                log_training(f"[Curriculum] Phase {phase.get('name')} done — loss={final_loss:.4f} (target≤{loss_target})", job_id=job_id)

                if final_loss <= loss_target:
                    log_training(f"[Curriculum] Phase {phase_id} hit loss target {loss_target} ✓", job_id=job_id)

            except Exception as e:
                log_training(f"[Curriculum] Phase {phase_id} error: {e}", level="error", job_id=job_id)

        if req.mode != "continuous":
            break

        log_training(f"[Curriculum] Continuous mode — restarting cycle (sessions done: {session_count})", job_id=job_id)

    with _training_lock:
        _training_state["state"] = "completed"
        _training_state["sessions_done"] = session_count
        _training_state["elapsed_seconds"] = time.time() - _training_state.get("started_at", time.time())

    log_training(f"[Curriculum] Job {job_id} complete — {session_count} sessions, best loss: {_training_state.get('best_loss')}", job_id=job_id)


# ─── Continuous Training & Data Puller Endpoints ─────────────────────────────

class ContinuousStartRequest(BaseModel):
    interval_minutes: int = 60
    phases: list = []
    epochs_per_phase: int = 1
    pull_every_n_cycles: int = 2


@app.get("/training/continuous/status")
async def continuous_status(_key = Depends(require_scope("read"))):
    with _workers_lock:
        ct = _continuous_trainer
    if ct is None:
        return {"running": False, "status": "not_initialized"}
    return ct.get_state()


@app.post("/training/continuous/start")
async def continuous_start(req: ContinuousStartRequest, _key = Depends(require_scope("train"))):
    _reject_serving_write()
    with _workers_lock:
        ct = _continuous_trainer
        dp = _data_puller
    if ct is None or dp is None:
        ct, dp = await _wait_for_workers()
    if not dp.state.get("status") == "pulling" and not dp._running:
        dp.start(interval_minutes=req.interval_minutes * req.pull_every_n_cycles)
    return ct.start(
        interval_minutes=req.interval_minutes,
        phases=req.phases or None,
        epochs_per_phase=req.epochs_per_phase,
        pull_every_n=req.pull_every_n_cycles,
    )


@app.post("/training/continuous/stop")
async def continuous_stop(_key = Depends(require_scope("train"))):
    with _workers_lock:
        ct = _continuous_trainer
        dp = _data_puller
    if ct is None:
        return {"success": False, "message": "Workers not initialized"}
    if dp:
        dp.stop()
    return ct.stop()


@app.get("/training/continuous/history")
async def continuous_history(_key = Depends(require_scope("read"))):
    from storage_client import get_storage
    storage = get_storage()
    history = storage.lrange("mb:training:continuous:history", 0, 49) if storage.is_available else []
    return {"history": history or [], "count": len(history or [])}


@app.get("/training/puller/status")
async def puller_status(_key = Depends(require_scope("read"))):
    with _workers_lock:
        dp = _data_puller
    if dp is None:
        return {"status": "not_initialized"}
    state = dp.get_state()
    state["local_files"] = len(list(
        (Path(__file__).parent / "ai_model" / "training_data").glob("pull_*.json")
    ))
    return state


@app.get("/training/puller/sources")
async def puller_sources(_key = Depends(require_scope("read"))):
    from workers.data_puller import PUBLIC_SOURCES
    return {
        "public_sources": [{"id": s["id"], "name": s["name"], "category": s["category"]} for s in PUBLIC_SOURCES],
        "pdim_patterns": [
            "mbs:data", "mbs:downloads", "mbs_training",
            "mb:ads:*:peaks", "mb:social:posts:*", "mb:analytics:*",
            "mb:content:*", "mb:dataset:*:chunk:*",
        ],
    }


@app.post("/training/puller/pull")
async def puller_pull(background_tasks: BackgroundTasks, _key = Depends(require_scope("train"))):
    with _workers_lock:
        dp = _data_puller
    if dp is None:
        _, dp = await _wait_for_workers()
    background_tasks.add_task(dp.pull_now)
    return {"success": True, "message": "Data pull triggered in background"}


@app.post("/training/puller/start")
async def puller_start_auto(interval_minutes: int = 30, _key = Depends(require_scope("train"))):
    with _workers_lock:
        dp = _data_puller
    if dp is None:
        _, dp = await _wait_for_workers()
    return dp.start(interval_minutes=interval_minutes)


@app.post("/training/puller/stop")
async def puller_stop_auto(_key = Depends(require_scope("train"))):
    with _workers_lock:
        dp = _data_puller
    if dp is None:
        return {"success": False, "message": "DataPuller not initialized"}
    dp.stop()
    return {"success": True, "message": "DataPuller auto-pull stopped"}


# ─── Watchdog Endpoints ────────────────────────────────────────────────────────

@app.get("/watchdog/status")
async def watchdog_status(_key = Depends(require_scope("read"))):
    with _workers_lock:
        wd = _watchdog
    if wd is None:
        return {"status": "not_initialized", "running": False}
    return wd.get_status()


@app.get("/watchdog/log")
async def watchdog_log(limit: int = 50, _key = Depends(require_scope("read"))):
    with _workers_lock:
        wd = _watchdog
    if wd is None:
        return {"log": [], "count": 0}
    entries = wd.get_log(limit=limit)
    return {"log": entries, "count": len(entries)}


@app.post("/watchdog/reset")
async def watchdog_reset(_key = Depends(require_scope("train"))):
    with _workers_lock:
        wd = _watchdog
    if wd is None:
        return {"success": False, "message": "Watchdog not initialized"}
    wd.reset_alerts()
    return {"success": True, "message": "Watchdog alert log cleared"}


# ─── Coverage (Retrieval) Endpoints ─────────────────────────────────────────────

@app.get("/coverage/status")
async def coverage_status(_key = Depends(require_scope("read"))):
    with _workers_lock:
        wd = _coverage_watchdog
    if wd is None:
        return {"status": "not_initialized", "running": False}
    return wd.get_status()


@app.get("/coverage/log")
async def coverage_log(limit: int = 50, _key = Depends(require_scope("read"))):
    with _workers_lock:
        wd = _coverage_watchdog
    if wd is None:
        return {"log": [], "count": 0}
    entries = wd.get_log(limit=limit)
    return {"log": entries, "count": len(entries)}


@app.get("/coverage/report")
async def coverage_report(_key = Depends(require_scope("read"))):
    with _workers_lock:
        idx = _asset_index
    if idx is None:
        return {"status": "not_initialized"}
    try:
        from ai_model.retrieval.probes import probe_count, recent_probes
        probes = recent_probes()
        vectors = [p["vector"] for p in probes]
        report = idx.coverage_report(vectors or None)
        report["live_probes_total"] = probe_count()
        report["live_probes_sampled"] = len(vectors)
        try:
            report["brands"] = idx.brand_stats()
        except Exception:
            pass
        return report
    except Exception:
        return idx.coverage_report()


@app.get("/coverage/ingestor")
async def coverage_ingestor(_key = Depends(require_scope("read"))):
    """Status of the generated-asset ingestor (produced images folded back in)."""
    try:
        from ai_model.retrieval.generated_ingestor import get_generated_ingestor
        return get_generated_ingestor().get_status()
    except Exception:
        return {"status": "not_initialized", "running": False}


@app.post("/coverage/reset")
async def coverage_reset(_key = Depends(require_scope("train"))):
    with _workers_lock:
        wd = _coverage_watchdog
    if wd is None:
        return {"success": False, "message": "CoverageWatchdog not initialized"}
    wd.reset_alerts()
    return {"success": True, "message": "Coverage alert log cleared"}


# ─── Content Generation ───────────────────────────────────────────────────────

PLATFORM_NORMALIZE = {
    "googlebusiness": "google_business", "google_business": "google_business",
    "twitter": "twitter", "x": "twitter",
}

def normalize_platform(p: str) -> str:
    return PLATFORM_NORMALIZE.get(p.lower(), p.lower())


_srv_logger = logging.getLogger(__name__)

_MUSIC_PLATFORM_LABELS: dict[str, str] = {
    "spotify.com":       "music release on Spotify",
    "open.spotify.com":  "music release on Spotify",
    "youtube.com":       "music video on YouTube",
    "youtu.be":          "music video on YouTube",
    "music.youtube.com": "music video on YouTube",
    "soundcloud.com":    "track on SoundCloud",
    "music.apple.com":   "music release on Apple Music",
    "tidal.com":         "music release on Tidal",
    "deezer.com":        "music release on Deezer",
    "bandcamp.com":      "music release on Bandcamp",
    "audiomack.com":     "track on Audiomack",
    "distrokid.com":     "release via DistroKid",
}

_URL_RE = re.compile(r"^(https?://|www\.)\S+", re.IGNORECASE)
_DOMAIN_ONLY_RE = re.compile(r"^([\w-]+\.)+[\w-]{2,}(/[\w.~%-]*)?$", re.IGNORECASE)


_URL_TITLE_SUFFIXES = re.compile(
    r"\s*[\|–—\-]\s*(?:Spotify|YouTube|SoundCloud|Apple Music|Tidal|Deezer"
    r"|Bandcamp|Audiomack|DistroKid|Instagram|TikTok|Twitter|X\.com|Facebook"
    r"|LinkedIn|Pinterest|Reddit|Twitch|Snapchat|BeReal|Substack"
    r"|SoundOn|Triller|Clapper|Lemon8|Threads)\s*$",
    re.IGNORECASE,
)


def _fetch_page_title(url_str: str) -> str:
    """Try to fetch a URL and return the best available title string (never raises)."""
    try:
        from ai_model.native_analysis.safe_http import fetch_bytes
        raw, _ = fetch_bytes(
            url_str, max_bytes=32768, allowed_content_types=("text/html",),
            deadline_seconds=3,
        )
        body = raw.decode("utf-8", errors="replace")

        # og:title is richest — try both attribute orderings
        og = re.search(
            r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\'<>]+)["\']',
            body, re.IGNORECASE,
        ) or re.search(
            r'<meta[^>]+content=["\']([^"\'<>]+)["\'][^>]+property=["\']og:title["\']',
            body, re.IGNORECASE,
        )
        if og:
            title = _html.unescape(og.group(1)).strip()
            return _URL_TITLE_SUFFIXES.sub("", title).strip()

        # Fall back to <title> tag
        title_m = re.search(r"<title[^>]*>([^<]{3,})</title>", body, re.IGNORECASE)
        if title_m:
            title = _html.unescape(title_m.group(1)).strip()
            return _URL_TITLE_SUFFIXES.sub("", title).strip()
    except Exception:
        pass
    return ""


def _clean_idea_from_parsed(parsed) -> str:
    """Build a ScriptAgent-friendly idea string from a ParsedUrl.

    Unlike ``ParsedUrl.topic_string`` (which is designed for the URL Inspector
    panel and includes the platform-label suffix such as "(TikTok video)"),
    this function produces a natural short phrase that won't echo metadata
    labels verbatim into generated copy.

    Rules:
    • Strip leading ``@`` from artist/title (TikTok creator handles).
    • De-duplicate: if title and artist normalise to the same string use only
      the more readable one (avoids "Lunarvoss — lunarvoss" repetition).
    • Never include the platform or content-type suffix.
    • Always falls back to the raw ``topic_string`` so resolution is never lost.
    """
    title  = (parsed.title  or "").lstrip("@").strip()
    artist = (parsed.artist or "").lstrip("@").strip()

    # Normalise for de-duplication: strip spaces and lowercase
    def _norm(s: str) -> str:
        return s.lower().replace(" ", "").replace("-", "").replace("_", "")

    if title and artist:
        if _norm(title) == _norm(artist):
            # Same entity twice — keep the title (typically has better casing)
            return title
        return f"{title} — {artist}"
    return title or artist or parsed.topic_string


def _resolve_topic_from_url(raw_topic: str) -> str:
    """Convert any URL/domain/Spotify-URI topic into a human-readable idea string.

    For plain-text topics (not URLs) the input is returned unchanged — no
    network calls or parsing are attempted.  Only inputs that pass the URL
    heuristic (http/https scheme, spotify: URI, or bare domain) are handed to
    the Universal URL Parser.

    Delegates entirely to the Universal URL Parser which handles 30+ platforms
    with platform-specific extractors, JSON-LD, og:title, path slugs, and
    music metadata (genre, mood, BPM, key).  Never raises.

    Returns a clean idea string (no platform-label suffixes) suitable for
    direct use in ScriptAgent ``idea`` fields.
    """
    if not raw_topic or not raw_topic.strip():
        return raw_topic
    t = raw_topic.strip()
    try:
        from ai_model.url_parser.core import is_url as _is_url, parse_url as _parse_url_direct
    except Exception:
        return t

    # Gate: plain-text topics (e.g. "midnight piano ballad") pass through
    # unchanged — no DNS resolution, no network calls, no parsing overhead.
    if not _is_url(t):
        return t

    try:
        parsed = _parse_url_direct(t)
        idea   = _clean_idea_from_parsed(parsed)
        if idea and idea != t:
            _srv_logger.info("[url-parser] topic resolved: %r → %r", t, idea)
        return idea if idea else t
    except Exception:
        return t


def _effective_awareness(platform: str, raw_awareness: str) -> str:
    """Always combine caller-provided awareness with platform strategy signals.

    Caller awareness comes FIRST so request-specific signals lead and
    synchronize with (rather than get drowned out by) the generic platform
    buffer. Platform signals (fire/viral/drop/finally/exclusive etc.) are
    appended after, so the hook-selector and body-builder still always have
    arousal-rich [HIGH] signals available. When the caller sends no awareness,
    only platform signals are used. Never-raise.
    """
    from ai_model.generation.awareness import ensure_context_once
    return ensure_context_once(raw_awareness, platform)


@app.get("/api/url-parser/content")
async def url_parser_content(url: str = "", platform: str = "",
                             _key = Depends(require_scope("generate"))):
    """Full content extraction for a URL + Veo DNA from the awareness systems.

    Query params:
      url      — the URL (or Spotify URI) to extract content from
      platform — optional target platform (instagram / tiktok / …) to blend
                 platform-specific awareness into the Veo DNA block

    Returns every extracted field plus:
      veo_dna        — Veo scoring DNA block (hook/length/structure/CTA rules
                       + live chart patterns from the quality-awareness buffer)
      awareness_full — awareness_text + veo_dna, ready for any generation
                       ``awareness`` field

    Never raises on parse failures (fetch_ok=False + error instead).
    """
    if not url or not url.strip():
        raise HTTPException(status_code=422, detail="url query parameter is required")

    try:
        from ai_model.url_parser import get_content_from_url as _get_content
    except Exception as import_err:
        raise HTTPException(status_code=500, detail=f"URL parser unavailable: {import_err}")

    return await _in_thread(lambda: _get_content(url.strip(), platform=platform.strip()))


@app.get("/api/url-parser/inspect")
async def url_parser_inspect(url: str = "", _key = Depends(require_scope("generate"))):
    """Parse any URL and return the full structured metadata the AI pipeline sees.

    Query param:
      url — the URL (or Spotify URI) to inspect

    Returns the ParsedUrl fields as a JSON object, plus a ready-to-use
    topic_string and awareness_text block.  Never raises.
    """
    if not url or not url.strip():
        raise HTTPException(status_code=422, detail="url query parameter is required")

    try:
        from ai_model.url_parser.core import parse_url as _parse_url_core
    except Exception as import_err:
        raise HTTPException(status_code=500, detail=f"URL parser unavailable: {import_err}")

    try:
        parsed = await _in_thread(lambda: _parse_url_core(url.strip()))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Parse error: {exc}")

    return {
        # Input echo
        "raw_url":        parsed.raw_url,
        "canonical_url":  parsed.canonical_url,
        # Platform
        "platform":       parsed.platform,
        "platform_label": parsed.platform_label,
        "content_type":   parsed.content_type,
        # Content metadata
        "title":          parsed.title,
        "artist":         parsed.artist,
        "album":          parsed.album,
        "label":          parsed.label,
        "description":    parsed.description,
        # Music signals
        "genre":          parsed.genre,
        "mood":           parsed.mood,
        "bpm":            parsed.bpm,
        "key":            parsed.key,
        "release_year":   parsed.release_year,
        # Derived
        "intent":         parsed.intent,
        "goal":           parsed.goal,
        "content_themes": parsed.content_themes,
        # Pipeline outputs
        "topic_string":   parsed.topic_string,
        "awareness_text": parsed.awareness_text,
        # Diagnostics
        "fetch_ok":       parsed.fetch_ok,
        "error":          parsed.error,
    }


def _planned_generation(modality, *, specification=False, deterministic_planner=False,
                        dedicated_media=False):
    """Apply the same immutable contract to direct and HTTP handler calls."""
    import functools
    import inspect
    from ai_model.generation.plan import GenerationPlan, active_plan, validate_output

    def decorate(handler):
        signature = inspect.signature(handler, eval_str=True)
        @functools.wraps(handler)
        async def wrapped(*args, **kwargs):
            from ai_model.awareness import bind, current_snapshot, AwarenessUnavailable
            from contextlib import ExitStack
            from ai_model.generation.awareness import sampling_snapshot
            scope = ExitStack()
            bound = signature.bind(*args, **kwargs)
            req = bound.arguments.get("req", bound.arguments.get("body", bound.arguments.get("request")))
            try:
                plan_input = (await req.json() if isinstance(req, Request) else
                              {"operation": handler.__name__} if req is None else req)
                # Only the explicitly opted-in text entrypoints have this
                # deterministic branch. It routes requested modality slots;
                # it never samples a generative checkpoint or produces copy.
                planning_only = deterministic_planner and getattr(req, "mode", None) == "planner"
                controls = (plan_input.get("dedicated_controls") if isinstance(plan_input, dict)
                            else getattr(req, "dedicated_controls", None))
                rendering_only = dedicated_media and controls is not None
                if controls is not None:
                    if not dedicated_media or specification or planning_only:
                        raise HTTPException(status_code=422, detail="This route does not support dedicated media controls")
                    if modality not in {"image", "audio", "video"} or not isinstance(controls, dict):
                        raise HTTPException(status_code=422, detail="dedicated_controls must be a media controls object")
                    if not _request_job_owner.get():
                        raise HTTPException(status_code=403, detail="Authenticated private owner required for durable media")
                model_independent = planning_only or rendering_only
                snapshot = sampling_snapshot() if active_plan.get() is not None else current_snapshot()
                if snapshot is not None:
                    try:
                        scope.enter_context(bind(snapshot))
                    except AwarenessUnavailable:
                        snapshot = None
                if (model_independent or globals().get("_live_serving_model") is not None) and snapshot is None:
                    raise AwarenessUnavailable("Live awareness unavailable for generation: fresh public snapshot required")
                pinned_release = None
                if not model_independent and globals().get("_live_serving_model") is not None:
                    from ai_model.generation.live_serving import LiveModelUnavailable
                    try:
                        pinned_release = scope.enter_context(_live_serving_model.pin())
                    except LiveModelUnavailable as exc:
                        raise HTTPException(status_code=503, detail=str(exc)) from exc
                if not model_independent and pinned_release is None and not _model_ready:
                    raise HTTPException(status_code=503, detail="Selected model unavailable")
                plan = GenerationPlan.from_request(plan_input, modality,
                    checkpoint=("" if model_independent else
                                (pinned_release or _serving_release_status).get("checkpoint_sha256", "")))
            except AwarenessUnavailable as exc:
                scope.close()
                raise HTTPException(status_code=503, detail=str(exc)) from exc
            except (TypeError, ValueError) as exc:
                scope.close()
                raise HTTPException(status_code=422, detail=str(exc)) from exc
            except BaseException:
                scope.close()
                raise
            token = active_plan.set(plan)
            from ai_model.generation.release import candidate_errors
            previous_failures = candidate_errors.get()
            failure_token = candidate_errors.set(previous_failures if previous_failures is not None else [])
            try:
                if controls is not None:
                    # Never drop unsupported semantic controls simply because
                    # the caller put them outside the dedicated control object.
                    controls = dict(controls)
                    request_data = plan.to_dict()["request"]
                    for name in ("subject", "reference", "style"):
                        value = request_data.get(name)
                        if value is not None:
                            if name in controls and controls[name] != value:
                                raise HTTPException(status_code=422, detail=f"Conflicting {name} controls")
                            controls[name] = value
                    if modality == "video":
                        supplied_audio = request_data.get("user_audio_path")
                        if supplied_audio is not None:
                            if "audio_path" in controls and controls["audio_path"] != supplied_audio:
                                raise HTTPException(status_code=422, detail="Conflicting video audio controls")
                            controls["audio_path"] = supplied_audio
                        if controls.get("audio_path") is not None:
                            http_request = bound.arguments.get("request")
                            if not isinstance(http_request, Request):
                                raise HTTPException(status_code=422, detail="Video audio requires an owner-scoped upload request")
                            controls["audio_path"] = _resolve_owner_audio_upload(controls["audio_path"], http_request)
                    from ai_model.generation.dedicated import render
                    owner_id = _request_job_owner.get()
                    if not owner_id:
                        raise HTTPException(status_code=403, detail="Authenticated private owner required for durable media")
                    from uuid import uuid4
                    delivery_job_id = uuid4().hex
                    try:
                        result = await _in_thread(lambda: render(
                            modality, controls, _UPLOADS_PATH, owner_id=owner_id,
                            persist_job=_persist_generation_job, read_job=_job_read,
                            job_id=delivery_job_id))
                    except ValueError as exc:
                        if (_job_read(delivery_job_id) or {}).get("status") == "committing":
                            raise HTTPException(status_code=503, detail={
                                "error": str(exc), "job_id": delivery_job_id,
                                "status": "committing", "retry_stage": "delivery_only"}) from exc
                        raise HTTPException(status_code=422, detail=str(exc)) from exc
                    except Exception as exc:
                        raise HTTPException(status_code=503, detail={
                            "error": str(exc), "job_id": delivery_job_id,
                            "status": (_job_read(delivery_job_id) or {}).get("status", "failed"),
                        }) from exc
                else:
                    try:
                        request_data = plan.to_dict()["request"]
                        if (modality in {"image", "video", "audio"} and not specification
                                and request_data.get("render_engine") not in {"procedural", "rta", "pathtraced", "raytraced"}):
                            raise HTTPException(status_code=503, detail=(
                                "Learned media generation unavailable on this legacy route; "
                                "select explicit procedural dedicated_controls"))
                        result = await handler(*args, **kwargs)
                    except AwarenessUnavailable as exc:
                        raise HTTPException(status_code=503, detail=str(exc)) from exc
                    except RuntimeError as exc:
                        raise HTTPException(status_code=503, detail=str(exc)) from exc
                    except HTTPException:
                        raise
                    except Exception as exc:
                        if candidate_errors.get():
                            failure = candidate_errors.get()[0]
                            raise HTTPException(
                                status_code=422 if isinstance(failure, (ValueError, TypeError, NotImplementedError)) else 503,
                                detail=str(failure),
                            )
                        raise HTTPException(
                            status_code=422 if isinstance(exc, (ValueError, TypeError, NotImplementedError)) else 503,
                            detail=str(exc)) from exc
                    if candidate_errors.get():
                        failure = candidate_errors.get()[0]
                        raise HTTPException(
                            status_code=422 if isinstance(failure, (ValueError, TypeError, NotImplementedError)) else 503,
                            detail=str(failure),
                        )
                from starlette.responses import StreamingResponse, Response
                if isinstance(result, StreamingResponse):
                    # Validate generation before committing HTTP headers. This
                    # deliberately buffers streams so expiry/model failures
                    # remain real HTTP errors rather than a truncated 200.
                    chunks = []
                    size = 0
                    try:
                        async for chunk in result.body_iterator:
                            chunk = chunk.encode(result.charset) if isinstance(chunk, str) else bytes(chunk)
                            size += len(chunk)
                            if size > 16 * 1024 * 1024:
                                raise ValueError("Generation stream exceeds 16 MiB delivery limit")
                            chunks.append(chunk)
                        if candidate_errors.get():
                            raise candidate_errors.get()[0]
                    except Exception as exc:
                        raise HTTPException(
                            status_code=422 if isinstance(exc, (ValueError, TypeError)) else 503,
                            detail=str(exc)) from exc
                    finally:
                        if hasattr(result.body_iterator, "aclose"):
                            await result.body_iterator.aclose()
                    headers = {k: v for k, v in result.headers.items()
                               if k.lower() not in {"content-length", "transfer-encoding"}}
                    headers["x-generation-plan-hash"] = plan.plan_hash
                    if plan.snapshot_hash is not None:
                        headers["x-awareness-snapshot-id"] = plan.snapshot_hash
                    return Response(content=b"".join(chunks), status_code=result.status_code,
                                    headers=headers, media_type=result.media_type,
                                    background=result.background)
                if not isinstance(result, dict):
                    raise HTTPException(status_code=503, detail="Generation returned an unsupported response")
                if isinstance(result, dict):
                    if result.get("success") is False or result.get("status") in {"failed", "error"}:
                        raise HTTPException(status_code=503, detail=result.get("error", "Generation failed"))
                    is_spec = specification or getattr(req, "mode", None) == "planner"
                    try:
                        if model_independent:
                            # Recheck the bound receipt before returning the
                            # specification, including through nested aliases.
                            from ai_model.awareness import bound_snapshot
                            bound_snapshot()
                        validation = (result["validation"] if controls is not None
                                      else validate_output(plan, result, specification=is_spec))
                    except (ValueError, AwarenessUnavailable) as exc:
                        raise HTTPException(status_code=503, detail=str(exc)) from exc
                    result = dict(result)
                    result["generation_plan"] = plan.to_dict()
                    if plan.snapshot_hash is not None:
                        result["snapshot_id"] = plan.snapshot_hash
                    else:
                        result.pop("snapshot_id", None)
                    result["seed"] = plan.seed
                    result["validation"] = validation
                    result["capability_status"] = {
                        "runtime": "executed" if controls is not None else "handler_returned",
                        "quality": "not_evaluated",
                        "digital_gpu_exclusive": "not_verified",
                    }
                    if rendering_only:
                        result["source"] = result["capability"]["renderer"]
                        result["checkpoint_inference"] = False
                    if is_spec:
                        result["kind"] = "specification"
                return result
            finally:
                candidate_errors.reset(failure_token)
                active_plan.reset(token)
                scope.close()
        wrapped.__signature__ = signature
        return wrapped
    return decorate


@app.get("/api/generation/capabilities")
async def generation_capabilities():
    from ai_model.capabilities import capabilities
    from ai_model.generation.plan import GENERATION_PLAN_VERSION
    return {"renderers": capabilities(), "quality": "not_evaluated",
            "serving_release": _serving_release_status,
            "runtime": "not_probed", "digital_gpu_exclusive": "not_verified",
            "plan_version": GENERATION_PLAN_VERSION}


@app.post("/api/content/generate")
@app.post("/content/generate")
@_planned_generation("content")
async def generate_content(req: ContentRequest, _key = Depends(require_scope("generate"))):
    start = time.time()
    platform = normalize_platform(req.platform)
    topic = _resolve_topic_from_url(req.topic)
    effective_awareness = _effective_awareness(platform, _merged_awareness_for(req))

    await _wait_for_model_ready()

    async def _run_content_inference():
        from ai_model.agents.script_agent import ScriptRequest
        from ai_model.agents.distribution_agent import DistributionRequest
        script_result = await _in_thread(lambda: _script_agent.run(ScriptRequest(
            idea=topic, platform=platform, goal=req.goal, tone=req.tone,
            awareness=effective_awareness,
        )))
        full_script = f"{script_result.hook}\n{script_result.body}\n{script_result.cta}"
        dist_result = await _in_thread(lambda: _distribution_agent.run(DistributionRequest(
            script=full_script, platform=platform, goal=req.goal,
            awareness=effective_awareness,
        )))
        return script_result, dist_result

    def _build_result(_request=None):
        from ai_model.agents.script_agent import ScriptRequest, ScriptResponse
        from ai_model.agents.distribution_agent import DistributionRequest
        sr = _script_agent.run(ScriptRequest(
            idea=topic, platform=platform, goal=req.goal,
            tone=req.tone, awareness=effective_awareness,
        ))

        _require_model_script(sr)
        from ai_model.request_intelligence import looks_garbled
        if looks_garbled(f"{sr.hook}\n{sr.body}"):
            raise HTTPException(status_code=503, detail="Model returned garbled content")

        full_script = f"{sr.hook}\n{sr.body}\n{sr.cta}"
        dr = _distribution_agent.run(DistributionRequest(
            script=full_script, platform=platform,
            goal=req.goal, awareness=effective_awareness,
        ))
        if not isinstance(dr.caption, str) or not dr.caption.strip():
            raise HTTPException(status_code=503, detail="Distribution returned empty caption")
        return {
            "success": True,
            "platform": platform,
            "caption": dr.caption,
            "hook": sr.hook,
            "body": sr.body,
            "cta": sr.cta,
            "hashtags": dr.hashtags if req.include_hashtags else [],
            **_script_provenance(sr),
            "generation_contract": _GENERATION_CONTRACT,
        }

    try:
        # ── Dedup + single-flight via PDIM orchestrator ───────────────────────
        # Identical concurrent requests collapse to one compute; all share result.
        _orch = _get_pdim_orchestrator()
        _cache_key = {"generation_contract": _GENERATION_CONTRACT,
                      "plan_hash": _generation_plan_hash(),
                      "platform": platform, "topic": topic, "tone": req.tone,
                      "goal": req.goal, "awareness": effective_awareness,
                      "platform_optimization": _platform_optimization_awareness(req)}
        _out = await _in_thread(lambda: _orch.compute(_cache_key, _build_result, namespace="api_content_model_v2"))
        _result = dict(_out["result"])
        if (_result.get("source") not in {"ai_model", "model", "model_composed"}
                or _result.get("generation_contract") != _GENERATION_CONTRACT):
            raise HTTPException(status_code=503, detail="Cached content lacks model provenance")
        if _out.get("source") in ("cache", "coalesced"):
            _result["cached"] = True
        _result["processing_time_ms"] = round((time.time() - start) * 1000, 1)
        _fw_ingest(_key, "scripts", _result, {
            "topic": topic, "platform": platform,
            "tone": req.tone, "awareness": effective_awareness,
        })
        return _result
    except HTTPException:
        raise
    except ValueError as e:
        _srv_logger.warning("[generate-from-url] %s topic=%r platform=%s", e, topic, platform)
        raise HTTPException(status_code=503, detail=f"Generation returned empty output: {e}")
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Content generation unavailable: {e}")

# ─── BoostSheets ─────────────────────────────────────────────────────────────

@app.get("/boostsheets")
async def list_boostsheets():
    if not _repo:
        return {"sheet_ids": [], "count": 0}
    ids = _repo.list_ids()
    return {"sheet_ids": ids, "count": len(ids)}

# ─── Dashboard Stats ──────────────────────────────────────────────────────────

@app.get("/dashboard/stats")
async def dashboard_stats():
    total_keys = 0
    active_keys = 0
    total_requests_today = 0
    boostsheet_count = 0
    try:
        conn = _acquire()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM api_keys")
        total_keys = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM api_keys WHERE is_active = TRUE")
        active_keys = cur.fetchone()[0]
        cur.execute("SELECT COALESCE(SUM(request_count), 0) FROM api_keys WHERE last_used_at > NOW() - INTERVAL '1 day'")
        total_requests_today = cur.fetchone()[0] or 0
        cur.close()
        _release(conn)
    except Exception:
        pass

    if _repo:
        try:
            boostsheet_count = len(_repo.list_ids())
        except Exception:
            pass

    with _training_lock:
        training_state = _training_state.get("state", "idle")

    return {
        "total_api_keys": total_keys,
        "active_api_keys": active_keys,
        "total_requests_today": int(total_requests_today),
        "model_status": (
            "loaded" if _model_ready
            else "failed" if _model_init_error is not None
            else "initializing"
        ),
        "model_error": _model_init_error,
        "training_state": training_state,
        "vocab_size": len(_tokenizer.vocab) if _tokenizer else 0,
        "weights_exist": (Path(__file__).parent / "ai_model" / "weights" / "model.pt").exists(),
        "gpu_lanes": _hyper_gpu_sizing()[0],
        "boostsheet_count": boostsheet_count,
    }

# ─── Storage Sync Endpoints ───────────────────────────────────────────────────

class CurriculumFeedback(BaseModel):
    user_id: str
    platform: str
    engagement_rate: float = Field(ge=0.0, le=100.0)
    content_type: str = "post"
    style_tags: List[str] = []


class DatasetRegister(BaseModel):
    name: str
    description: str = ""
    size_bytes: int = 0
    num_chunks: int = 0
    content_type: str = "text"


class CheckpointSave(BaseModel):
    model_id: str
    state: dict
    metadata: Optional[dict] = None


@app.get("/storage/status")
async def storage_status(_key = Depends(verify_api_key)):
    from storage_client import get_storage, get_checkpoint_client
    storage = get_storage()
    st = storage.status()
    # Derive canonical storage_mode so callers never have to re-implement the logic.
    if st.get("available"):
        _mode = "live"
    elif st.get("disk_store_available"):
        _mode = "local_fallback"
    else:
        _mode = "offline"
    checkpoints = get_checkpoint_client().list_checkpoints()
    return {
        **st,
        "storage_mode": _mode,
        # Alias: some older dashboard code checks `connected`
        "connected": st.get("available", False),
        "recent_checkpoints": checkpoints[:5],
    }


@app.post("/storage/feedback")
async def record_curriculum_feedback(feedback: CurriculumFeedback, _key = Depends(verify_api_key)):
    from storage_client import get_curriculum_client
    get_curriculum_client().record_feedback(
        user_id=feedback.user_id,
        platform=feedback.platform,
        engagement_rate=feedback.engagement_rate,
        content_type=feedback.content_type,
        style_tags=feedback.style_tags,
    )
    return {"status": "recorded", "user_id": feedback.user_id}


@app.get("/storage/curriculum/{user_id}")
async def get_curriculum(user_id: str, limit: int = 50, _key = Depends(verify_api_key)):
    from storage_client import get_curriculum_client
    client = get_curriculum_client()
    return {
        "user_id": user_id,
        "feedback": client.get_user_curriculum(user_id, limit=limit),
        "top_performers": client.get_top_performers(user_id, top_n=10),
        "stats": client.get_user_stats(user_id),
    }


class ArtistProfileRequest(BaseModel):
    artist_name: Optional[str] = None
    current_single: Optional[str] = None
    current_album: Optional[str] = None
    audience_age: Optional[str] = None
    audience_geo: Optional[str] = None
    # ── Brand Voice (research-driven, see storage_client.ArtistProfileClient) ──
    # Saved once, then pulled automatically into text/image/video generation so
    # output "sounds like the brand" instead of generic AI copy, and so the
    # artist controls whether generated content discloses AI assistance.
    genre: Optional[str] = None
    tone: Optional[str] = None
    vocabulary: Optional[List[str]] = None
    avoid_words: Optional[List[str]] = None
    palette: Optional[List[str]] = None
    ai_disclosure: Optional[bool] = None


class ArtistReleaseRequest(BaseModel):
    title: str
    kind: str = "single"          # single | album | ep
    release_date: Optional[str] = None
    streaming_url: Optional[str] = None
    status: str = "released"      # released | upcoming
    platforms: List[str] = []


@app.get("/storage/artist/{profile_id}")
async def get_artist_profile(profile_id: str, _key = Depends(verify_api_key)):
    """Return the artist profile + release catalog for generation enrichment."""
    from storage_client import get_artist_client
    return get_artist_client().get_enrichment(profile_id)


@app.post("/storage/artist/{profile_id}")
async def save_artist_profile(profile_id: str, profile: ArtistProfileRequest,
                              _key = Depends(verify_api_key)):
    """Create or merge-update an artist profile (name, single/album, audience)."""
    from storage_client import get_artist_client
    saved = get_artist_client().save_profile(profile_id, profile.model_dump())
    return {"status": "saved", "profile": saved}


@app.post("/storage/artist/{profile_id}/releases")
async def add_artist_release(profile_id: str, release: ArtistReleaseRequest,
                             _key = Depends(verify_api_key)):
    """Append a release / streaming record to the artist's catalog."""
    from storage_client import get_artist_client
    rec = get_artist_client().add_release(profile_id, release.model_dump())
    return {"status": "added", "release": rec}


@app.get("/storage/datasets")
async def list_datasets(_key = Depends(verify_api_key)):
    from storage_client import get_dataset_client
    return {"datasets": get_dataset_client().list_datasets()}


@app.post("/storage/datasets/register")
async def register_dataset(dataset: DatasetRegister, _admin = Depends(verify_admin)):
    from storage_client import get_dataset_client
    get_dataset_client().register_dataset(
        name=dataset.name,
        description=dataset.description,
        size_bytes=dataset.size_bytes,
        num_chunks=dataset.num_chunks,
        content_type=dataset.content_type,
    )
    return {"status": "registered", "name": dataset.name}


# Single-flight for audio seeding is now enforced inside
# workers/seed_audio_dataset.py (_SEED_LOCK + AlreadySeedingError).
# is_seeding() lets the HTTP endpoint return an immediate response without
# waiting for the background thread to race-fail on the module lock.


@app.get("/storage/datasets/audio/status")
async def get_audio_dataset_status(_key = Depends(verify_api_key)):
    """Return the current audio dataset manifest and auto-growth state.

    Combines the stored dataset meta (num_chunks, source, seeded_at) with the
    DataPuller's audio auto-growth counters so the dashboard can show dataset
    size and freshness in one call.
    """
    from storage_client import get_storage
    storage = get_storage()
    meta: dict = {}
    try:
        raw = storage.get("mb:dataset:audio:meta")
        if isinstance(raw, dict):
            meta = {
                "num_chunks": int(raw.get("num_chunks", 0)),
                "source": str(raw.get("source", "")),
                "seeded_at": raw.get("seeded_at"),
                "description": str(raw.get("description", "")),
            }
    except Exception:
        pass

    auto_growth: dict = {}
    if _data_puller is not None:
        try:
            s = _data_puller.get_state()
            auto_growth = {
                "enabled": True,
                "threshold": s.get("audio_growth_threshold", 20),
                "last_auto_seed_at": s.get("last_audio_seed_at"),
                "auto_seed_count": s.get("audio_auto_seed_count", 0),
                "interval_hours": s.get("audio_growth_interval_hours", 6),
            }
        except Exception:
            auto_growth = {"enabled": False}
    else:
        auto_growth = {"enabled": False}

    from workers.seed_audio_dataset import is_seeding as _is_seeding
    seeding_now = _is_seeding()

    return {
        "dataset": meta,
        "auto_growth": auto_growth,
        "seeding_now": seeding_now,
    }


@app.post("/storage/datasets/audio/seed")
async def seed_audio_dataset(
    count: int = 12,
    replace: bool = False,
    source: Optional[str] = None,
    _admin = Depends(verify_admin),
):
    """Seed REAL music samples from a public dataset into pdim storage so that
    ``/api/generate/audio`` produces output from real audio. Runs in the
    background; poll ``GET /storage/datasets/audio/status`` for the manifest.

    ``source`` overrides the automatic HF/librosa probe:
      - ``"hf"``      — force HuggingFace FMA-small (falls back to librosa on error)
      - ``"librosa"`` — use librosa bundled CC examples directly
      - omit / ``null`` — auto-detect (probe HF, fall back to librosa)
    """
    from storage_client import get_storage
    from workers import seed_audio_dataset as _seed

    storage = get_storage()
    if not storage.is_available and not getattr(storage, "disk_store_available", False):
        raise HTTPException(
            status_code=503,
            detail="storage backend unavailable — cannot seed audio dataset",
        )

    from workers.seed_audio_dataset import is_seeding as _is_seeding
    if _is_seeding():
        return {"status": "already_seeding"}

    force_source = source.strip().lower() if source else None

    def _run():
        try:
            _seed.seed(
                storage,
                count=int(count),
                replace=bool(replace),
                force_source=force_source,
            )
        except Exception as exc:  # background — surface explicit failure
            print(f"[seed_audio] seeding failed: {exc}", flush=True)

    threading.Thread(target=_run, daemon=True).start()
    return {
        "status": "seeding",
        "count": int(count),
        "replace": bool(replace),
        "source": force_source or "auto",
    }


@app.post("/storage/checkpoint/save")
async def save_checkpoint(payload: CheckpointSave, _admin = Depends(verify_admin)):
    _reject_serving_write()
    from storage_client import get_checkpoint_client
    ok = get_checkpoint_client().save_checkpoint(
        model_id=payload.model_id,
        state=payload.state,
        metadata=payload.metadata,
    )
    return {"status": "saved" if ok else "fallback", "model_id": payload.model_id}


@app.get("/storage/checkpoint/{model_id}")
async def load_checkpoint(model_id: str, _admin = Depends(verify_admin)):
    from storage_client import get_checkpoint_client
    client = get_checkpoint_client()
    meta = client.get_checkpoint_meta(model_id)
    if not meta:
        raise HTTPException(status_code=404, detail=f"Checkpoint '{model_id}' not found")
    return {"model_id": model_id, "meta": meta}


@app.get("/storage/checkpoints")
async def list_checkpoints(_admin = Depends(verify_admin)):
    from storage_client import get_checkpoint_client
    return {"checkpoints": get_checkpoint_client().list_checkpoints()}


# ─── Platform API — Main Music Platform Integration ───────────────────────────
#
# These endpoints are called by the main MaxBooster music platform
# (DAW, beat marketplace, social media management, music distribution).
# They run on top of the model trained from the 7TB storage dataset.

from ai_model.generation.social_controls import (
    SocialGenerationControls,
    apply_social_controls,
    control_awareness,
)


class PlatformSocialRequest(_AwarenessMixin, SocialGenerationControls):
    user_id: str
    platform: str = "instagram"
    topic: str
    tone: str = "authentic"
    goal: str = "growth"
    style_tags: List[str] = []
    include_hashtags: bool = True
    num_variants: int = Field(1, ge=1, le=5)
    instruction:    Optional[str]       = None
    extra_context:  Optional[str]       = None
    content_themes: Optional[List[str]] = None


class PlatformDAWRequest(_AwarenessMixin):
    user_id: str
    mode: str = "lyrics"        # lyrics | hook | beat_description | track_concept
    genre: str = "hip-hop"
    mood: str = "energetic"
    bpm: Optional[int] = None
    key: Optional[str] = None
    reference_track: Optional[str] = None
    context: Optional[str] = None
    instruction:    Optional[str]       = None
    extra_context:  Optional[str]       = None
    content_themes: Optional[List[str]] = None


class PlatformAutopilotRequest(_AwarenessMixin):
    user_id: str
    platform: str = "instagram"
    recent_posts: List[dict] = []
    target_metric: str = "engagement"   # engagement | reach | conversions
    instruction:    Optional[str]       = None
    extra_context:  Optional[str]       = None
    content_themes: Optional[List[str]] = None


class PlatformDistributionRequest(_AwarenessMixin):
    user_id: str
    track_title: str
    genre: str = "hip-hop"
    release_date: Optional[str] = None
    target_platforms: List[str] = ["spotify", "apple_music", "tidal"]
    bio: Optional[str] = None
    instruction:    Optional[str]       = None
    extra_context:  Optional[str]       = None
    content_themes: Optional[List[str]] = None


class PlatformVideoRequest(_AwarenessMixin):
    user_id: str
    topic: str
    platform: str = "youtube"           # youtube | tiktok | instagram | general
    style: str = "cinematic"            # cinematic | documentary | animated | social
    goal: str = "engagement"            # engagement | education | promotion | storytelling
    tone: str = "energetic"             # energetic | calm | dramatic | inspirational | playful
    duration_seconds: int = Field(30, ge=5, le=300)
    aspect_ratio: str = "16:9"          # 16:9 | 9:16 | 1:1 | 4:5
    include_captions: bool = True
    instruction:    Optional[str]       = None
    extra_context:  Optional[str]       = None
    content_themes: Optional[List[str]] = None
    # ── Veo-parity generation controls ───────────────────────────────────
    camera_motion: Optional[str] = None      # pan_left/pan_right/zoom_in/zoom_out/
                                             # tilt_up/tilt_down/dolly_in/dolly_out/
                                             # crane_up/crane_down/static/auto
    negative_prompt: Optional[str] = None   # content/style/elements to avoid
    seed: Optional[int] = None              # explicit seed for reproducible output
    fps: Optional[int] = None               # output frame rate (8/16/24/30); default 24
    motion_intensity: Optional[float] = None # 0.0–1.0; overrides tone-derived energy
    enhance_prompt: bool = True             # False = skip AI awareness augmentation
    lighting: Optional[str] = None          # cinematic/dramatic/natural/studio/
                                            # golden_hour/night/neon
    color_temperature: Optional[str] = None # warm/cool/neutral
    style_reference: Optional[str] = None   # URL or asset ID for style conditioning
    output_resolution: Optional[str] = None # 720p/1080p/4k — overrides derived resolution


def _build_personalized_tone(user_id: str, platform: str, base_tone: str) -> str:
    """Pull user engagement signals from storage to bias the model tone."""
    try:
        from storage_client import get_curriculum_client
        client = get_curriculum_client()
        top = client.get_top_performers(user_id, platform=platform, top_n=3)
        if top:
            tags = []
            for fb in top:
                tags.extend(fb.get("style_tags", []))
            if tags:
                dominant = max(set(tags), key=tags.count)
                return f"{base_tone}, {dominant}"
    except Exception:
        pass
    return base_tone


@app.post("/platform/social/generate")
@_planned_generation("content")
async def platform_social_generate(req: PlatformSocialRequest, _key = Depends(require_scope("generate"))):
    """
    Main platform social media content generation.
    Uses per-user curriculum signals to personalize tone/style.
    """
    start = time.time()
    platform = normalize_platform(req.platform)
    # Content URLs must be safely fetched. A public profile URL may instead
    # supply a literal handle; that is disclosed as unverified caller input,
    # never as fetched biography, release metadata, or proof of an account.
    _url_awareness = ""
    _input_resolution = {"source": "caller_text"}
    try:
        from ai_model.url_parser.core import (
            is_url as _is_url, parse_url as _parse_url, supplied_profile_identity,
        )
        _profile_identity = supplied_profile_identity(req.topic)
        if _profile_identity:
            _social_topic = _profile_identity
            _input_resolution = {
                "source": "caller_supplied_profile_handle",
                "fetch_ok": False,
                "account_verified": False,
            }
        elif _is_url(req.topic):
            _parsed_url = _parse_url(req.topic)
            if not _parsed_url.fetch_ok:
                raise HTTPException(
                    status_code=422,
                    detail="URL could not be safely fetched and resolved",
                )
            _social_topic = _clean_idea_from_parsed(_parsed_url)
            if not _social_topic or _social_topic == req.topic.strip():
                raise HTTPException(
                    status_code=422,
                    detail="URL did not contain analyzable social content",
                )
            _url_awareness = _parsed_url.awareness_text or ""
            _input_resolution = {"source": "fetched_url", "fetch_ok": True}
        else:
            _social_topic = req.topic.strip()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=422,
            detail=f"URL resolution failed: {str(exc)[:160]}",
        )

    # Personalize tone based on user's past engagement data in storage
    personalized_tone = _build_personalized_tone(req.user_id, platform, req.tone)
    _request_controls = control_awareness(req)
    effective_awareness = _effective_awareness(
        platform,
        "\n".join(
            part for part in (
                _merged_awareness_for(req),
                _url_awareness,
                _request_controls,
            )
            if part
        ),
    )

    variants = []
    await _wait_for_model_ready()

    for i in range(req.num_variants):
        try:
            from ai_model.agents.script_agent import ScriptRequest
            from ai_model.agents.distribution_agent import DistributionRequest

            _vidx = i   # capture loop variable before async boundary
            async def _run_variant(vidx=_vidx):
                s = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=_social_topic, platform=platform,
                    goal=req.goal, tone=personalized_tone,
                    awareness=effective_awareness,
                    variant_idx=vidx,
                     target_audience=req.target_audience or "",
                     output_format=req.output_format,
                     caption_length=req.caption_length or "optimal",
                     cta_strength=req.call_to_action_strength or "medium",
                     genre=req.genre or "",
                )))
                _require_model_script(s)
                d = await _in_thread(lambda: _distribution_agent.run(DistributionRequest(
                    script=f"{s.hook}\n{s.body}\n{s.cta}",
                    platform=platform, goal=req.goal,
                    awareness=effective_awareness,
                )))
                return s, d

            script, dist = await _run_variant()
            controlled = apply_social_controls(
                hook=script.hook,
                body=script.body,
                cta=script.cta,
                hashtags=dist.hashtags if req.include_hashtags else [],
                topic=_social_topic,
                controls=req,
                awareness=effective_awareness,
            )
            if not controlled["caption"]:
                raise HTTPException(
                    status_code=503,
                    detail="native social generation produced no usable content",
                )
            variant: dict[str, Any] = {
                **controlled,
                "source": getattr(script, "source", "model"),
                "output_format": req.output_format,
            }
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=503,
                                detail=f"Social model generation unavailable: {e}") from e
        variant["variant"] = i + 1
        variants.append(variant)

    _result = {
        "success": True,
        "user_id": req.user_id,
        "platform": platform,
        "topic": _social_topic,
        "input_resolution": _input_resolution,
        "personalized_tone": personalized_tone,
        "variants": variants,
        "model_ready": _model_ready,
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }
    _fw_ingest(_key, "social", _result, {
        "topic": _social_topic, "platform": platform,
        "tone": personalized_tone, "awareness": effective_awareness,
    })
    return _result


@app.post("/platform/social/autopilot")
@_planned_generation("content")
async def platform_social_autopilot(req: PlatformAutopilotRequest, _key = Depends(require_scope("generate"))):
    """
    Autopilot endpoint: analyses a user's recent post performance and recommends
    the next content strategy using the trained model + engagement signals.
    """
    start = time.time()
    platform = normalize_platform(req.platform)

    try:
        from storage_client import get_curriculum_client
        curriculum = get_curriculum_client()
        top_content = curriculum.get_top_performers(req.user_id, platform=platform, top_n=5)
        _user_stats = curriculum.get_user_stats(req.user_id)
    except Exception:
        top_content = []
        _user_stats = {}

    # Analyse what's working
    top_tags = []
    top_types = []
    avg_engagement = 0.0
    for post in (top_content or req.recent_posts[:5]):
        top_tags.extend(post.get("style_tags", []))
        top_types.append(post.get("content_type", "post"))
        avg_engagement += post.get("engagement_rate", 0.0)

    if top_content or req.recent_posts:
        avg_engagement /= max(len(top_content or req.recent_posts), 1)

    dominant_tags = list(dict.fromkeys(top_tags))[:3]
    dominant_type = max(set(top_types), key=top_types.count) if top_types else "post"

    await _wait_for_model_ready()

    next_topics = []
    schedule: list[str] = []
    try:
        from ai_model.agents.script_agent import ScriptRequest
        from ai_model.agents.distribution_agent import DistributionRequest
        _auto_aw = _effective_awareness(platform, _merged_awareness_for(req))
        for tag in (dominant_tags or ["music", "artist", "studio"])[:2]:
            s = await _in_thread(lambda t=tag: _script_agent.run(ScriptRequest(
                idea=t, platform=platform, goal=req.target_metric, tone="authentic",
                awareness=_auto_aw,
            )))
            next_topics.append({
                "topic": tag,
                "hook": s.hook,
                "cta": s.cta,
                "source": getattr(s, "source", "model"),
            })
        # Get posting time from distribution agent instead of static dict
        d = await _in_thread(lambda: _distribution_agent.run(DistributionRequest(
            script=next_topics[0]["hook"] if next_topics else platform,
            platform=platform, goal=req.target_metric,
            awareness=_auto_aw,
        )))
        schedule = [d.posting_time] if d.posting_time else []
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {
        "success": True,
        "user_id": req.user_id,
        "platform": platform,
        "analysis": {
            "avg_engagement_rate": round(avg_engagement, 2),
            "top_style_tags": dominant_tags,
            "best_content_type": dominant_type,
            "data_points": len(top_content),
        },
        "recommendations": {
            "next_topics": next_topics,
            "best_posting_times": schedule,
            "content_type": dominant_type,
            "style_focus": dominant_tags[:2] if dominant_tags else ["authentic", "music"],
        },
        "autopilot_ready": bool(top_content),
        "model_powered": _model_ready,
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


@app.post("/platform/daw/generate")
@_planned_generation("text")
async def platform_daw_generate(req: PlatformDAWRequest, _key = Depends(require_scope("generate"))):
    """
    DAW / Studio AI generation endpoint.
    Powers the AI assistant inside the MaxBooster DAW:
    lyrics, hooks, beat descriptions, track concepts — all model-generated.
    """
    start = time.time()

    context_prompt = f"Genre: {req.genre}. Mood: {req.mood}."
    if req.bpm:
        context_prompt += f" BPM: {req.bpm}."
    if req.key:
        context_prompt += f" Key: {req.key}."
    if req.reference_track:
        context_prompt += f" Inspired by: {req.reference_track}."
    if req.context:
        context_prompt += f" {req.context}"

    if req.mode == "lyrics":
        topic = f"song lyrics — {context_prompt}"
        goal = "creative expression"
        tone = req.mood
    elif req.mode == "hook":
        topic = f"catchy hook — {context_prompt}"
        goal = "virality"
        tone = "punchy"
    elif req.mode == "beat_description":
        topic = f"beat description — {context_prompt}"
        goal = "production"
        tone = "technical"
    else:  # track_concept
        topic = f"full track concept — {context_prompt}"
        goal = "artistry"
        tone = req.mood

    await _wait_for_model_ready()

    try:
        from ai_model.agents.script_agent import ScriptRequest
        from ai_model.agents.visual_spec_agent import VisualSpecRequest

        _daw_aw = _effective_awareness("youtube", _merged_awareness_for(req))
        script = await _in_thread(lambda: _script_agent.run(ScriptRequest(
            idea=topic, platform="youtube", goal=goal, tone=tone,
            awareness=_daw_aw,
        )))
        _require_model_script(script)
        visual = await _in_thread(lambda: _visual_spec_agent.run(VisualSpecRequest(
            idea=topic, platform="youtube", tone=tone, awareness=_daw_aw,
        )))

        _result = {
            "success": True,
            "user_id": req.user_id,
            "mode": req.mode,
            "genre": req.genre,
            "mood": req.mood,
            "bpm": req.bpm,
            "key": req.key,
            "output": {
                "main": script.hook,
                "body": script.body,
                "cta": script.cta,
                "visual_direction": getattr(visual, "thumbnail_prompt", "cinematic"),
                "color_scheme": getattr(visual, "color_scheme", "dark_neon"),
                "layout": getattr(visual, "layout", "landscape_16_9"),
            },
            "source": getattr(script, "source", "model"),
            "processing_time_ms": round((time.time() - start) * 1000, 1),
        }
        _fw_ingest(_key, "daw", _result, {
            "genre": req.genre, "mood": req.mood, "mode": req.mode,
            "bpm": req.bpm, "key": req.key, "awareness": req.awareness,
            "context_prompt": context_prompt,
        })
        return _result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=503,
                            detail=f"DAW model generation unavailable: {e}") from e


@app.post("/platform/distribution/plan")
@_planned_generation("content", specification=True)
async def platform_distribution_plan(req: PlatformDistributionRequest, _key = Depends(require_scope("generate"))):
    """
    Music distribution planning endpoint.
    Generates a release strategy for a track across streaming platforms,
    powered by the trained model's knowledge of platform dynamics.
    """
    start = time.time()

    await _wait_for_model_ready()

    try:
        from ai_model.agents.distribution_agent import DistributionRequest
        bio_context = req.bio or f"{req.genre} artist"
        _dist_awareness = _effective_awareness("spotify", _merged_awareness_for(req))
        dist = await _in_thread(lambda: _distribution_agent.run(DistributionRequest(
            script=f"New {req.genre} track: '{req.track_title}'. Artist: {bio_context}.",
            platform="spotify", goal="streams",
            awareness=_dist_awareness,
        )))
        _result = {
            "success": True,
            "user_id": req.user_id,
            "track": req.track_title,
            "plan": {
                "pitch": dist.caption,
                "hashtags": dist.hashtags,
                "target_platforms": req.target_platforms,
                "release_window": "Friday release recommended",
                "pre_release_steps": [
                    "Submit to distributor 7 days before release",
                    "Pitch to Spotify editorial playlist curators",
                    "TikTok teaser campaign 5 days before drop",
                    "Apple Music pre-save link campaign",
                ],
                "post_release": [
                    "24h engagement blitz on all platforms",
                    "Reply to every comment in the first 2 hours",
                    "Share stream milestone updates as Stories",
                ],
            },
            "source": getattr(dist, "source", "model"),
            "processing_time_ms": round((time.time() - start) * 1000, 1),
        }
        _fw_ingest(_key, "distribution", _result, {
            "track": req.track_title, "genre": req.genre,
            "target_platforms": req.target_platforms,
            "awareness": req.awareness,
        })
        return _result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/platform/video/generate")
async def platform_video_generate_schema():
    """
    Schema discovery for the video generation platform endpoint.
    Returns parameter definitions and expected response shape.
    """
    return {
        "endpoint": "POST /platform/video/generate",
        "description": (
            "Generate a complete AI video production package for the MaxBooster platform — "
            "includes personalized script, scene-by-scene visual directions, captions, "
            "thumbnail concept, and distribution metadata. Personalised per user via "
            "curriculum engagement signals."
        ),
        "parameters": {
            "user_id":          {"type": "string",  "required": True},
            "topic":            {"type": "string",  "required": True},
            "platform":         {"type": "string",  "required": False, "default": "youtube",    "options": ["youtube", "tiktok", "instagram", "general"]},
            "style":            {"type": "string",  "required": False, "default": "cinematic",  "options": ["cinematic", "documentary", "animated", "social"]},
            "goal":             {"type": "string",  "required": False, "default": "engagement", "options": ["engagement", "education", "promotion", "storytelling"]},
            "tone":             {"type": "string",  "required": False, "default": "energetic",  "options": ["energetic", "calm", "dramatic", "inspirational", "playful"]},
            "duration_seconds": {"type": "integer", "required": False, "default": 30, "min": 5, "max": 300},
            "aspect_ratio":     {"type": "string",  "required": False, "default": "16:9",       "options": ["16:9", "9:16", "1:1", "4:5"]},
            "include_captions": {"type": "boolean", "required": False, "default": True},
        },
        "returns": {
            "user_id":           "Echoed user identifier",
            "title":             "Video title",
            "hook":              "Opening hook line",
            "script":            "Full narration / dialogue script",
            "scenes":            "List of scene objects — description, visual_direction, narration, duration_seconds",
            "captions":          "Caption blocks with start_sec / end_sec / text",
            "hashtags":          "Platform-tuned hashtags",
            "thumbnail_concept": "AI-generated thumbnail concept description",
            "distribution":      "Platform caption, goal, and recommended post time",
            "duration_seconds":  "Planned duration",
            "aspect_ratio":      "Output aspect ratio",
            "source":            "'model' or 'template'",
            "processing_time_ms":"Generation latency",
        },
    }


@app.post("/platform/video/generate")
@_planned_generation("video", specification=True)
async def platform_video_generate(req: PlatformVideoRequest, _key = Depends(require_scope("generate"))):
    """
    Main platform video generation endpoint.
    Generates a complete AI video production package personalised to the user's
    engagement history via the curriculum feedback store.
    """
    start = time.time()
    platform = normalize_platform(req.platform)
    personalized_tone = _build_personalized_tone(req.user_id, platform, req.tone)
    scene_count = max(3, req.duration_seconds // 10)
    # Universal URL Parser: resolve topic from any URL/platform link
    _vid_topic = _resolve_topic_from_url(req.topic)

    await _wait_for_model_ready()

    _vid_awareness = _effective_awareness(platform, _merged_awareness_for(req))

    async def _run_model_inference():
        from ai_model.agents.script_agent import ScriptRequest
        from ai_model.agents.visual_spec_agent import VisualSpecRequest
        from ai_model.agents.distribution_agent import DistributionRequest

        _vid_aw = _vid_awareness
        script_result = await _in_thread(lambda: _script_agent.run(ScriptRequest(
            idea=_vid_topic, platform=platform, goal=req.goal, tone=personalized_tone,
            awareness=_vid_aw,
        )))
        full_script = f"{script_result.hook}\n{script_result.body}\n{script_result.cta}"

        visual_result = await _in_thread(lambda: _visual_spec_agent.run(VisualSpecRequest(
            idea=_vid_topic, platform=platform, tone=personalized_tone, awareness=_vid_aw,
        ))) if _visual_spec_agent else None

        dist_result = await _in_thread(lambda: _distribution_agent.run(DistributionRequest(
            script=full_script, platform=platform, goal=req.goal,
            awareness=_vid_aw,
        )))
        return script_result, full_script, visual_result, dist_result

    # Async coalescer: identical video requests share one Future — followers are
    # suspended coroutines, not threads.  Only unique digests hit the model.
    _vkey = {
        "topic":    _vid_topic,
        "platform": platform,
        "style":    req.style or "",
        "goal":     req.goal  or "",
        "tone":     personalized_tone or "",
        "awareness": _vid_awareness,
        "duration": req.duration_seconds,
    }
    _coalesced_inference: list = []

    async def _coalesced_video():
        result = await _run_model_inference()
        _coalesced_inference.append(result)
        return result

    try:
        script_result, full_script, visual_result, dist_result = \
            await _get_async_coalescer().compute(_vkey, _coalesced_video)

        raw_scenes = getattr(visual_result, "scenes", None) or []
        if not raw_scenes:
            lines = full_script.split("\n")
            raw_scenes = [
                {
                    "scene": i + 1,
                    "duration_seconds": req.duration_seconds // scene_count,
                    "description": f"{_vid_topic} — {req.style} scene {i + 1}",
                    "visual_direction": f"{req.style.capitalize()} framing, {personalized_tone} energy",
                    "narration": lines[min(i, len(lines) - 1)],
                }
                for i in range(scene_count)
            ]

        caption_blocks = []
        if req.include_captions:
            per_scene = req.duration_seconds // max(len(raw_scenes), 1)
            for idx, scene in enumerate(raw_scenes):
                caption_blocks.append({
                    "start_sec": idx * per_scene,
                    "end_sec": (idx + 1) * per_scene,
                    "text": scene.get("narration", f"Scene {idx + 1}"),
                })

        thumbnail_concept = (
            getattr(visual_result, "thumbnail_concept", None)
            or f"Bold '{_vid_topic.upper()}' text over {req.style} background with {personalized_tone} color grading"
        )

        _result = {
            "success": True,
            "user_id": req.user_id,
            "title": f"{_vid_topic} — {req.style.capitalize()} Video",
            "hook": script_result.hook,
            "body": script_result.body,
            "cta":  script_result.cta,
            "script": full_script,
            "scenes": raw_scenes,
            "captions": caption_blocks,
            "hashtags": dist_result.hashtags if req.include_captions else [],
            "thumbnail_concept": thumbnail_concept,
            "distribution": {
                "platform": platform,
                "caption": dist_result.caption,
                "goal": req.goal,
                "recommended_post_time": getattr(dist_result, "recommended_post_time", "peak hours"),
            },
            "duration_seconds": req.duration_seconds,
            "aspect_ratio": req.aspect_ratio,
            "source": getattr(script_result, "source", "model"),
            "processing_time_ms": round((time.time() - start) * 1000, 1),
        }
        _fw_ingest(_key, "video", _result, {
            "topic": _vid_topic, "platform": platform, "style": req.style,
            "tone": personalized_tone, "awareness": req.awareness,
            "duration_seconds": req.duration_seconds,
        })
        return _result
    except HTTPException:
        raise
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=503,
                            detail=f"Video generation unavailable: {exc}") from exc
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/platform/model/info")
async def platform_model_info(_key = Depends(verify_api_key)):
    """
    Returns the current model state for the main platform UI.
    Shows whether a compatible trained checkpoint is available.
    """
    from storage_client import get_storage
    storage = get_storage()

    with _training_lock:
        t_state = dict(_training_state)

    weights_path = Path(__file__).parent / "ai_model" / "weights" / "model.pt"

    return {
        "model_ready": _model_ready,
        "model_error": _model_init_error,
        "model_config": _model_config,
        "weights_source": "disk" if weights_path.exists() else "unavailable",
        "weights_exist": weights_path.exists(),
        "last_checkpoint": t_state.get("last_checkpoint"),
        "training": {
            "state": t_state.get("state", "idle"),
            "source": t_state.get("source"),
            "final_loss": t_state.get("final_loss"),
            "batches_from_storage": t_state.get("batches_from_storage", 0),
        },
        "storage": {
            # Cached flag only — never trigger a lazy network ping from this
            # route. It must answer in <1 s even when pdim is cold/offline.
            "connected": bool(getattr(storage, "_available", False)),
            "dataset_bytes": 7696581394432,
            "dataset_tb": round(7696581394432 / 1e12, 2),
        },
        "platform_endpoints": [
            "POST /platform/social/generate",
            "POST /platform/social/autopilot",
            "POST /platform/daw/generate",
            "POST /platform/distribution/plan",
            "GET  /platform/video/generate",
            "POST /platform/video/generate",
            "POST /platform/model/reload",
        ],
    }


@app.post("/platform/model/reload")
async def platform_model_reload(_admin = Depends(verify_admin)):
    _reject_serving_write()
    """
    Hot-reload: pull the latest checkpoint from storage and update model state.
    Call this from the main platform after a new training run completes.
    """
    thread = threading.Thread(target=_load_checkpoint_from_storage, daemon=True)
    thread.start()
    return {
        "status": "reloading",
        "message": "Checkpoint reload triggered from storage. Model state will update in ~5s.",
    }


# ─── MaxCore Multimodal Generation API ────────────────────────────────────────
#
# Five endpoints called by the Express orchestration layer (multimodal.ts).
# They form the generation backbone for all modalities:
#   POST /analyze              — normalize any input into a semantic representation
#   POST /generate/text        — mode=planner → TaskPlan | mode=content → text assets
#   POST /generate/image       — image asset specs per platform slot
#   POST /generate/audio       — voiceover/audio asset specs per platform slot
#   POST /generate/video       — video asset packs per platform slot

_platform_rules: dict = {}

def _load_platform_rules() -> dict:
    rules_path = Path(__file__).parent.parent.parent / "artifacts" / "api-server" / "src" / "platform_rules.json"
    try:
        with open(rules_path) as f:
            return json.load(f)
    except Exception:
        return {}

_platform_rules = _load_platform_rules()


class MaxcoreAnalyzeRequest(_AwarenessMixin):
    modality: str = "text"
    payload: str
    artistProfileId: Optional[str] = None
    platforms: List[str] = []
    intent: Optional[str] = None
    awareness: str = ""


class MaxcoreTextRequest(_AwarenessMixin):
    mode: str = "content"
    system: Optional[str] = None
    input: dict = {}        # used by mode='planner'
    step: dict = {}         # used by mode='content'
    inputs: dict = {}       # used by mode='content'


class MaxcoreMediaRequest(_AwarenessMixin):
    step: dict = {}
    inputs: dict = {}


@app.post("/analyze")
@_planned_generation("content", specification=True)
async def maxcore_analyze(req: MaxcoreAnalyzeRequest, _key = Depends(require_scope("generate"))):
    """
    Normalize any input modality (text, URL, image, audio, video) into a unified
    semantic representation. Fed directly into the planner by the TS orchestrator.
    """
    start = time.time()

    if req.modality == "url":
        content_hint = f"Content from URL: {req.payload}"
    elif req.modality in ("image", "audio", "video"):
        content_hint = f"{req.modality.capitalize()} asset: {req.payload}"
    else:
        content_hint = req.payload

    intent_hint = req.intent or "general content promotion"
    first_platform = req.platforms[0] if req.platforms else "general"

    normalized: dict = {
        "modality": req.modality,
        "payload_summary": content_hint,
        "intent": intent_hint,
        "platforms": req.platforms,
        "artistProfileId": req.artistProfileId,
        "semantic": {
            "topic": content_hint,
            "intent": intent_hint,
            "platforms": req.platforms,
            "style_tags": [],
        },
        "source": "template",
        "processing_time_ms": 0,
    }

    if _model_ready and _script_agent:
        try:
            from ai_model.agents.script_agent import ScriptRequest
            result = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                idea=content_hint,
                platform=normalize_platform(first_platform),
                goal=intent_hint,
                tone="authentic",
                awareness=_effective_awareness(
                    normalize_platform(first_platform), _merged_awareness_for(req)),
            )))
            normalized["semantic"]["hook"] = result.hook
            normalized["semantic"]["core_message"] = result.body
            normalized["source"] = getattr(result, "source", "model")
        except Exception:
            pass

    normalized["processing_time_ms"] = round((time.time() - start) * 1000, 1)
    return normalized


@app.post("/generate/text")
@_planned_generation("text", deterministic_planner=True)
async def maxcore_generate_text(req: MaxcoreTextRequest, _key = Depends(require_scope("generate"))):
    """
    Dual-mode text endpoint:
      mode='planner'  → returns a TaskPlan for the multimodal orchestrator
      mode='content'  → returns platform-specific text assets for a given step
    """
    start = time.time()
    data = req.input

    if req.mode == "planner":
        normalized = data.get("normalized", {})
        request_data = data.get("request", {})
        pack_spec = data.get("packSpec") or []
        if (not isinstance(normalized, dict) or not isinstance(request_data, dict)
                or not isinstance(pack_spec, list)):
            raise HTTPException(status_code=422, detail="Planner requires request object and packSpec list")

        modality_slots: dict = {}
        for slot in pack_spec:
            if not isinstance(slot, dict):
                raise HTTPException(status_code=422, detail="Planner slots must be objects")
            m = slot.get("modality", "text")
            if m not in {"text", "image", "audio", "video"}:
                raise HTTPException(status_code=422, detail=f"Unsupported planner modality: {m}")
            modality_slots.setdefault(m, []).append(slot)

        steps = [{
            "id": "analysis_step",
            "type": "analyze",
            "worker": "text",
            "inputFrom": "normalizedInput",
            "params": {
                **normalized,
                "intent": normalized.get("intent", "engagement"),
                "awareness": _merged_awareness_for(req),
            },
        }]

        for modality, slots in modality_slots.items():
            steps.append({
                "id": f"step_{modality}",
                "type": "generate",
                "worker": modality,
                "inputFrom": ["analysis_step"],
                "params": {
                    "slots": slots,
                    "platforms": [s.get("platform") for s in slots],
                    "constraints": request_data.get("constraints", {}),
                    "instruction": request_data.get("instruction"),
                    "content_themes": request_data.get("content_themes"),
                    "awareness": _merged_awareness_for(req),
                },
            })

        return {
            "requestId": request_data.get("id", str(uuid.uuid4())),
            "steps": steps,
            "normalizedInput": normalized,
            "request": request_data,
            "source": "deterministic_planner",
            "checkpoint_inference": False,
            "generation_contract": _GENERATION_CONTRACT,
            "processing_time_ms": round((time.time() - start) * 1000, 1),
        }

    # mode == 'content'
    step = req.step or data.get("step", {})
    inputs = req.inputs or data.get("inputs", {})
    slots = step.get("params", {}).get("slots", [])
    if not slots:
        raise HTTPException(status_code=422, detail="Text generation requires at least one slot")
    normalized = inputs.get("normalized", {}) if isinstance(inputs, dict) else {}
    topic = (normalized.get("semantic") or {}).get("topic") or normalized.get("payload_summary", "content")
    intent = (normalized.get("semantic") or {}).get("intent", "engagement")
    outputs = []
    if not (_model_ready and _script_agent and _distribution_agent):
        raise HTTPException(status_code=503, detail="Text model or distribution agent unavailable")
    for slot in slots:
        platform = normalize_platform(slot.get("platform", "general"))
        effective_awareness = _effective_awareness(
            platform, _merged_awareness_for(req))
        slot_id = slot.get("id", "")
        purpose = slot.get("purpose", "")
        rules = _platform_rules.get(platform, {}).get("text", {})
        max_len = rules.get("recommendedLength", 150)
        tone_list = rules.get("tone") or ["authentic"]
        tone = tone_list[0] if tone_list else "authentic"
        max_hashtags = rules.get("hashtags", {}).get("max", 0)
        hashtags_allowed = rules.get("hashtags", {}).get("allowed", False)

        tags: list = []
        from ai_model.agents.script_agent import ScriptRequest
        from ai_model.agents.distribution_agent import DistributionRequest
        try:
            script = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                idea=topic, platform=platform, goal=intent, tone=tone,
                awareness=effective_awareness,
            )))
            _require_model_script(script)
            hook_line, body_line, cta_line = script.hook, script.body, script.cta
            full_script = f"{hook_line}\n{body_line}\n{cta_line}".strip()
            dist = await _in_thread(lambda: _distribution_agent.run(DistributionRequest(
                script=full_script, platform=platform, goal=intent,
                awareness=effective_awareness,
            )))
            text = dist.caption
            if not isinstance(text, str) or not text.strip():
                raise HTTPException(status_code=503, detail="Distribution returned empty caption")
            posting_time = getattr(dist, "posting_time", "") or ""
            if hashtags_allowed:
                tags = getattr(dist, "hashtags", [])[:max_hashtags]
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(status_code=503,
                                detail=f"Text slot generation unavailable: {exc}") from exc

        if max_len:
            text = text[:max_len]
        if tags:
            text = f"{text}\n{' '.join(tags)}"

        outputs.append({
            "text": text,
            "platform": platform,
            "slotId": slot_id,
            "meta": {
                "purpose": purpose,
                "tone": tone,
                "length": len(text),
                "hook": hook_line,
                "body": body_line,
                "cta": cta_line,
                "posting_time": posting_time,
                "hashtags": tags,
                **_script_provenance(script),
            },
        })

    return {
        "outputs": outputs,
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


@app.post("/generate/image")
@_planned_generation("image", specification=True)
async def maxcore_generate_image(req: MaxcoreMediaRequest, _key = Depends(require_scope("generate"))):
    """
    Generate image asset specs (concept + aspect ratio + style guidance) per slot.
    Returns asset URIs and generation metadata for downstream rendering pipelines.
    """
    start = time.time()
    step = req.step
    inputs = req.inputs
    slots = step.get("params", {}).get("slots", [])
    normalized = inputs.get("normalized", {}) if isinstance(inputs, dict) else {}
    topic = (normalized.get("semantic") or {}).get("topic") or normalized.get("payload_summary", "content")
    constraints = step.get("params", {}).get("constraints", {})
    style_tags: list = constraints.get("styleTags", ["cinematic"])

    outputs = []
    for slot in slots:
        platform = slot.get("platform", "instagram")
        effective_awareness = _effective_awareness(
            normalize_platform(platform), _merged_awareness_for(req))
        slot_id = slot.get("id", "")
        rules = _platform_rules.get(platform, {}).get("image", {})
        aspect_ratio = rules.get("recommended") or (rules.get("aspectRatios") or ["1:1"])[0]
        style = ", ".join(style_tags)
        concept = (
            f"{style.capitalize()} visual for '{topic}' — {slot.get('purpose', '')}. "
            f"Aspect ratio {aspect_ratio}. Platform: {platform}."
        )

        if _model_ready and _visual_spec_agent:
            try:
                from ai_model.agents.visual_spec_agent import VisualSpecRequest
                vis = await _in_thread(lambda: _visual_spec_agent.run(VisualSpecRequest(
                    idea=topic,
                    platform=normalize_platform(platform),
                    tone=style_tags[0] if style_tags else "cinematic",
                    awareness=effective_awareness,
                )))
                concept = getattr(vis, "thumbnail_concept", concept) or concept
            except Exception:
                pass

        outputs.append({
            "url": f"asset://{slot_id}/{aspect_ratio.replace(':', 'x')}.png",
            "asset_status": "spec_only",
            "platform": platform,
            "slotId": slot_id,
            "meta": {
                "aspect_ratio": aspect_ratio,
                "style_tags": style_tags,
                "concept": concept,
                "format": "png",
                "source": "concept_spec",
            },
        })

    return {
        "outputs": outputs,
        "kind": "specification",
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


@app.post("/generate/audio")
@_planned_generation("audio", specification=True)
async def maxcore_generate_audio(req: MaxcoreMediaRequest, _key = Depends(require_scope("generate"))):
    """
    Generate audio asset specs (voiceover script + duration + style) per slot.
    Applies per-platform audio rules (max duration, style, voiceover eligibility).
    """
    start = time.time()
    step = req.step
    inputs = req.inputs
    slots = step.get("params", {}).get("slots", [])
    normalized = inputs.get("normalized", {}) if isinstance(inputs, dict) else {}
    topic = (normalized.get("semantic") or {}).get("topic") or normalized.get("payload_summary", "content")
    hook = (normalized.get("semantic") or {}).get("hook", "")

    outputs = []
    for slot in slots:
        platform = slot.get("platform", "general")
        effective_awareness = _effective_awareness(
            normalize_platform(platform), _merged_awareness_for(req))
        slot_id = slot.get("id", "")
        rules = _platform_rules.get(platform, {}).get("audio", {})

        if not rules.get("voiceover", True):
            continue

        max_dur = rules.get("maxDurationSec", 30)
        style_list = rules.get("style") or rules.get("tone") or ["authentic"]
        style = style_list[0] if isinstance(style_list, list) else "authentic"
        script_text = hook or f"Don't miss '{topic}' — out now."

        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                res = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=topic,
                    platform=normalize_platform(platform),
                    goal="engagement",
                    tone=style,
                    awareness=effective_awareness,
                )))
                script_text = res.hook
            except Exception:
                pass

        outputs.append({
            "url": f"asset://{slot_id}/voiceover.mp3",
            "asset_status": "spec_only",
            "platform": platform,
            "slotId": slot_id,
            "meta": {
                "script": script_text,
                "max_duration_sec": max_dur,
                "style": style,
                "sample_rate": 44100,
                "format": "mp3",
                "source": "voiceover_spec",
            },
        })

    return {
        "outputs": outputs,
        "kind": "specification",
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


@app.post("/generate/video")
@_planned_generation("video", specification=True)
async def maxcore_generate_video(req: MaxcoreMediaRequest, _key = Depends(require_scope("generate"))):
    """
    Generate video asset packs per slot.
    Applies per-platform rules: aspect ratio, duration, hook requirement.
    """
    start = time.time()
    step = req.step
    inputs = req.inputs
    slots = step.get("params", {}).get("slots", [])
    normalized = inputs.get("normalized", {}) if isinstance(inputs, dict) else {}
    topic = (normalized.get("semantic") or {}).get("topic") or normalized.get("payload_summary", "content")
    hook = (normalized.get("semantic") or {}).get("hook", "")
    constraints = step.get("params", {}).get("constraints", {})
    style_tags: list = constraints.get("styleTags", ["cinematic"])

    outputs = []
    for slot in slots:
        platform = slot.get("platform", "youtube")
        effective_awareness = _effective_awareness(
            normalize_platform(platform), _merged_awareness_for(req))
        slot_id = slot.get("id", "")
        params = step.get("params", {})
        rules = _platform_rules.get(platform, {}).get("video", {})
        aspect_ratio = params.get("aspectRatio") or (rules.get("aspectRatios") or ["16:9"])[0]
        duration = (
            params.get("maxDurationSec")
            or rules.get("recommendedDurationSec")
            or rules.get("maxDurationSec")
            or 30
        )
        requires_hook = rules.get("requiresHook", False)
        tone = style_tags[0] if style_tags else "energetic"

        hook_line = hook or f"You need to see this — {topic}"
        body_line = ""
        cta_line = ""
        source = "template"

        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                res = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=topic,
                    platform=normalize_platform(platform),
                    goal="engagement",
                    tone=tone,
                    awareness=effective_awareness,
                )))
                hook_line = res.hook or hook_line
                body_line = getattr(res, "body", "") or ""
                cta_line = getattr(res, "cta", "") or ""
                source = getattr(res, "source", "template")
            except Exception:
                pass

        render_url = f"asset://{slot_id}/{aspect_ratio.replace(':', 'x')}.mp4"
        render_meta: dict = {}

        script_full = f"{hook_line}\n{body_line}\n{cta_line}".strip()
        outputs.append({
            "url": render_url,
            "asset_status": "spec_only",
            "platform": platform,
            "slotId": slot_id,
            "meta": {
                "hook": hook_line if requires_hook else None,
                "body": body_line,
                "cta": cta_line,
                "script": script_full,
                "aspect_ratio": aspect_ratio,
                "duration_sec": duration,
                "requires_hook": requires_hook,
                "style_tags": style_tags,
                "source": source,
                "format": "mp4",
                "fps": 30,
                **render_meta,
            },
        })

    return {
        "outputs": outputs,
        "kind": "specification",
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


# ─── AI Ad System & Autopilot ─────────────────────────────────────────────────
#
# Replicates peak performance of paid ads across Meta, TikTok, YouTube, Google.
# Every ad run is stored; peak performers (high ROAS/CTR/low CPC) are extracted
# into pattern signatures the AI uses to generate the next winning creative set.

AD_PLATFORMS = {"meta", "facebook", "instagram", "tiktok", "youtube", "google", "twitter", "snapchat"}
AD_TYPES = {"video", "image", "carousel", "story", "reel", "search", "display", "ugc"}

AD_HOOKS_BY_PLATFORM = {
    "tiktok":    ["Stop scrolling — this drop is finally here! 🔥",
                  "The secret nobody tells you about going viral!",
                  "POV: you discover the best new release of the year",
                  "I tested this for 30 days and the results are insane!",
                  "This is the fire track everyone is talking about!"],
    "meta":      ["Finally — the drop you've been waiting for is live! 🎵",
                  "Stop sleeping on this — the best new music is finally here!",
                  "The #1 secret to finding fire music nobody else knows!",
                  "Never miss a drop like this — stream it now!",
                  "Exclusive first listen — this is insane! 🔥"],
    "youtube":   ["Stop what you're doing — this drop is finally here!",
                  "The secret formula that made this track go viral!",
                  "Why everyone is streaming this exclusive new release!",
                  "Never heard a drop this fire — exclusive now!"],
    "google":    ["Best new music — exclusively available now!",
                  "Top-rated exclusive drop — stream free now!",
                  "Finally — the fire track everyone is talking about!",
                  "Never-before-heard — exclusive first listen now!"],
    "instagram": ["Stop scrolling — this fire drop is finally live! 🔥",
                  "Real music. Real fire. Exclusively now.",
                  "Never-before-heard. First listen exclusively here!",
                  "The drop everyone is talking about — finally here! 🎵"],
}

# ── Per-subtype creative specs ────────────────────────────────────────────────
# Each entry defines format-specific creative_brief fields and the copy
# style the script agent should target.  All four subtypes are always
# generated when vary_subtypes=True so every campaign has maximum format
# coverage across placements.
AD_SPECS_BY_TYPE: dict = {
    "video": {
        "format_label":   "Video Ad",
        "duration_range": "15–60s",
        "copy_tone":      "direct",
        "brief_extras": {
            "opening_3s":        "hook text overlay on first frame",
            "visual_direction":  "Raw, high-energy footage of artist in studio or performance",
            "caption_style":     "auto-captions on for TikTok/Reels placements",
        },
    },
    "audio": {
        "format_label":   "Audio Ad",
        "duration_range": "15–30s",
        "copy_tone":      "conversational",
        "brief_extras": {
            "voiceover_style":   "warm, energetic narrator — first-person artist voice preferred",
            "sound_branding":    "open with 2s of the track hook, close with artist name + CTA",
            "companion_banner":  "static 640×320 banner runs alongside the audio stream",
            "platform_notes":    "Spotify/Pandora/podcast mid-roll; no visual dependency",
        },
    },
    "text": {
        "format_label":   "Text Ad",
        "duration_range": "N/A",
        "copy_tone":      "punchy",
        "brief_extras": {
            "headline_limit":    "30 characters",
            "description_limit": "90 characters",
            "display_url":       "artist.com/new",
            "extension_types":   ["sitelink", "callout", "structured snippet"],
            "platform_notes":    "Google Search / Meta text overlay / Twitter Promoted",
        },
    },
    "image": {
        "format_label":   "Image Ad",
        "duration_range": "N/A",
        "copy_tone":      "emotive",
        "brief_extras": {
            "visual_concept":    "Album / single artwork with bold typography overlay",
            "text_overlay_rule": "≤20% of image area (Meta policy)",
            "color_direction":   "Match primary artwork palette; high-contrast CTA button",
            "tagline_position":  "Bottom third — must be legible at thumbnail size",
            "format_variants":   ["1:1 feed", "9:16 story/reel", "1.91:1 link preview"],
        },
    },
}

# Subtype-specific hook overrides — each type has a distinct opening style
AD_HOOKS_BY_TYPE: dict = {
    "audio": [
        "Close your eyes — you've never heard anything like this 🎧",
        "This sound will stop you mid-scroll. Just listen.",
        "One track. Thirty seconds. Your new favourite artist.",
        "Turn it up — this exclusive drop is only here for now.",
        "Your ears called. They want this track immediately.",
    ],
    "text": [
        "Fire new drop. Stream free now.",
        "Exclusive: best track of the year just dropped.",
        "Finally here — the release everyone is talking about.",
        "New music. Real fire. Available now.",
        "Stop missing out — this drop is live.",
    ],
    "image": [
        "One image. One release. Zero skips. 🎵",
        "This is the cover art for the drop of the year.",
        "The visual drop is finally here — stream now.",
        "Art meets fire. New release out now.",
        "See it. Hear it. Stream it. Now.",
    ],
    # "video" falls through to AD_HOOKS_BY_PLATFORM (platform-specific)
}

AD_CTAS_BY_GOAL = {
    "streams":       ["Stream Now", "Listen Free", "Add to Playlist", "Presave Today"],
    "merch":         ["Shop Now", "Get Yours", "Limited Drop", "Claim 20% Off"],
    "fanbase":       ["Follow for More", "Join the Movement", "Be First", "Subscribe"],
    "tickets":       ["Get Tickets", "Reserve Your Spot", "Doors Open Soon", "Book Now"],
    "downloads":     ["Download Free", "Get the Track", "Free Download Today"],
    "conversions":   ["Start Free Trial", "Book a Session", "Claim Your Spot", "Apply Now"],
}

AUDIENCE_SEGMENTS = {
    "music_fan":     ["music lovers", "playlist listeners", "concert-goers", "spotify users"],
    "hip_hop":       ["hip-hop fans", "trap music", "rap enthusiasts", "urban culture"],
    "rb":            ["R&B fans", "soul music", "neo-soul", "smooth jazz adjacent"],
    "pop":           ["pop music fans", "top 40 listeners", "mainstream music"],
    "producer":      ["music producers", "beatmakers", "DAW users", "FL Studio", "Ableton"],
    "artist":        ["independent artists", "musicians", "singer-songwriters", "bands"],
    "brand_deal":    ["content creators", "influencers", "brand collaboration seekers"],
}


class AdRecordRequest(BaseModel):
    user_id: str
    platform: str
    ad_type: str = "video"
    hook: str = ""
    headline: str = ""
    body: str = ""
    cta: str = ""
    audience_tags: List[str] = []
    ctr: float = Field(0.0, ge=0)
    cpc: float = Field(0.0, ge=0)
    roas: float = Field(0.0, ge=0)
    conversions: int = 0
    impressions: int = 0
    clicks: int = 0
    spend: float = 0.0
    run_id: Optional[str] = None


class AdGenerateRequest(_AwarenessMixin):
    user_id: str
    platform: str = "meta"
    ad_type: str = "video"
    product: str
    goal: str = "streams"
    budget_daily: Optional[float] = None
    num_creatives: int = Field(3, ge=1, le=10)
    replicate_peak: bool = True
    genre: Optional[str] = None
    artist_name: Optional[str] = None
    # When True (default), each creative cycles through all four content-type
    # subtypes (video, audio, text, image) so every campaign has full format
    # coverage.  Set False to keep all creatives as ad_type.
    vary_subtypes: bool = True
    # Explicit subtype selection — takes priority over vary_subtypes when set.
    # Pass a non-empty list of any combination of: "video", "audio", "text", "image".
    # Creatives cycle through exactly these subtypes in order (wrapping on repeat).
    # Unknown values are silently dropped; if all values are invalid the field is
    # ignored and vary_subtypes / ad_type governs instead.
    #
    # Examples:
    #   target_subtypes=["video","audio"]      → slot 0=video, 1=audio, 2=video, ...
    #   target_subtypes=["text"]               → every creative is a text ad
    #   target_subtypes=["image","video"]      → alternates image / video
    #   target_subtypes=None  (default)        → vary_subtypes / ad_type governs
    target_subtypes: Optional[List[str]] = None
    # Awareness-bridge fields — wired into ScriptRequest so the awareness
    # conditioning layer can push creative quality toward the 100/100 standard.
    instruction: Optional[str] = None
    content_themes: Optional[List[str]] = None


def _ad_social_platform(platform: str) -> str:
    """Map an ad-network name to a real social profile for awareness/scripts.

    Keep the original ad-network identifier for ads storage, placements and
    performance queries; only the social conditioning path needs this mapping.
    """
    name = (platform or "").strip().lower()
    return {"meta": "facebook", "google": "general"}.get(name, normalize_platform(name))


class AdAutopilotRequest(_AwarenessMixin):
    user_id: str
    platform: Optional[str] = None
    budget_total: Optional[float] = None
    goal: str = "streams"
    current_campaigns: List[dict] = []


class AdAudienceRequest(_AwarenessMixin):
    user_id: str
    platform: str = "meta"
    product: str
    genre: Optional[str] = None
    goal: str = "streams"


_AD_HOOK_POWER = {
    "secret", "proven", "instantly", "exclusive", "free", "now",
    "never", "stop", "first", "best", "viral", "insane", "real",
    "raw", "unreleased", "finally", "limited", "drop", "fire",
    "everyone", "nobody",
}
import re as _re_hq_mod
_AD_EMOJI_RE = _re_hq_mod.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")

def _ad_hook_score(h: str) -> float:
    """Veo hook quality score used to prefer pool over weak model output."""
    hl = h.lower()
    s = 0.55 if any(p in hl for p in _AD_HOOK_POWER) else 0.0
    if "!" in h or "?" in h: s += 0.30
    if _AD_EMOJI_RE.search(h):  s += 0.15
    return min(1.0, s)


# Platform-specific video specs (used by the "video" subtype)
_PLAT_VIDEO_SPECS: dict = {
    "tiktok":    {"ratio": "9:16",        "duration": "15–60s",           "format": "vertical video"},
    "meta":      {"ratio": "1:1 or 4:5",  "duration": "15–30s",           "format": "feed video"},
    "youtube":   {"ratio": "16:9",        "duration": "6–15s skippable",  "format": "pre-roll"},
    "instagram": {"ratio": "9:16",        "duration": "up to 60s",        "format": "reel"},
    "google":    {"ratio": "N/A",         "duration": "N/A",              "format": "display"},
}


async def _generate_ad_creative(
    platform: str,
    ad_type: str,
    product: str,
    goal: str,
    peak_formula: Optional[dict],
    artist_name: Optional[str],
    genre: Optional[str],
    variant_idx: int,
    awareness: str = "",
    instruction: Optional[str] = None,
    content_themes: Optional[List[str]] = None,
) -> dict:
    """
    Generate an ad-copy creative and placement specification for one subtype.

    ad_type must be one of: video | audio | text | image.
    Each subtype produces a distinct creative_brief shape and agent tone.
    Image/audio/video briefs do not represent rendered media.

    Awareness is fed into ScriptRequest as conditioning, not as substitute copy.
    """
    plat_key   = platform.lower().replace("facebook", "meta").replace("instagram", "meta")
    sub        = ad_type.lower() if ad_type.lower() in AD_SPECS_BY_TYPE else "video"
    type_spec  = AD_SPECS_BY_TYPE[sub]
    artist     = artist_name or "the artist"

    # Run the dedicated script agent, not its awareness-only internal composer.
    # An awareness-composed fallback is not a model-generated ad.
    from ai_model.agents.script_agent import ScriptRequest
    if not (_model_ready and _script_agent):
        raise HTTPException(status_code=503, detail="Ad script model is unavailable")
    _sreq = ScriptRequest(
        idea=f"{product} by {artist}", genre=genre or "",
        platform=_ad_social_platform(platform), goal=goal,
        tone=type_spec["copy_tone"], awareness=awareness,
        variant_idx=variant_idx,
    )
    try:
        script = await _in_thread(lambda: _script_agent.run(_sreq))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Ad script generation failed: {exc}") from exc
    if not script or not all(isinstance(getattr(script, part, None), str) and
                             getattr(script, part).strip() for part in ("hook", "body", "cta")):
        raise HTTPException(status_code=503, detail="Ad script generation returned incomplete copy")
    if str(getattr(script, "source", "")).lower() not in ("model", "ai_model", "model_composed"):
        raise HTTPException(
            status_code=503,
            detail=f"Ad script did not produce model output (source={getattr(script, 'source', 'unknown')})",
        )
    hook, body, base_cta = script.hook, script.body, script.cta
    headline = script.cta[:50]
    source = str(getattr(script, "source", "") or "unknown")

    # ── Subtype-specific copy defaults ───────────────────────────────────────
    # Creative briefs below are specifications, never rendered media.

    # ── Subtype-specific creative_brief ──────────────────────────────────────
    brief_extras = type_spec["brief_extras"].copy()

    if sub == "video":
        plat_vspec = _PLAT_VIDEO_SPECS.get(plat_key, {"ratio": "1:1", "duration": "15–30s", "format": "standard"})
        creative_brief: dict = {
            "format":            plat_vspec["format"],
            "aspect_ratio":      plat_vspec["ratio"],
            "duration":          plat_vspec["duration"],
            "opening_3s":        hook,
            "visual_direction":  f"Show {artist} in action — raw, authentic, high-energy",
            "text_overlay":      headline,
            **brief_extras,
        }
    elif sub == "audio":
        creative_brief = {
            "format":        "audio ad",
            "duration":      type_spec["duration_range"],
            "voiceover_script": f"{hook} {body} {base_cta}.",
            **brief_extras,
        }
    elif sub == "text":
        # Enforce character limits for text ad copy
        hl30  = headline[:30] if headline else (product[:30])
        bd90  = body[:90]     if body     else (f"{product} — stream now")[:90]
        creative_brief = {
            "format":       "text ad",
            "headline":     hl30,
            "description":  bd90,
            "cta_button":   base_cta,
            **brief_extras,
        }
    else:  # image
        creative_brief = {
            "format":           "image ad",
            "tagline":          hook,
            "body_copy":        body,
            "cta_button":       base_cta,
            "visual_concept":   f"{artist} — {product}: album/single artwork with bold '{hook[:40]}' text overlay",
            **brief_extras,
        }

    return {
        "variant":       variant_idx + 1,
        "content_type":  sub,
        "hook":          hook,
        "headline":      headline,
        "body":          body,
        "cta":           base_cta,
        "creative_brief": creative_brief,
        "source":        source,
        "provenance":    _script_provenance(script),
        "hook_assessment": {"metric": "power_punctuation_emoji",
                            "score": _ad_hook_score(hook),
                            "kind": "heuristic_not_engagement_prediction"},
        "asset_status":  "spec_only",
    }


@app.post("/platform/ads/record")
async def ads_record_run(req: AdRecordRequest, _key = Depends(require_scope("write"))):
    """
    Record a completed ad run's performance metrics.
    Peak performers (ROAS ≥ 3, CTR ≥ 2.5%) are automatically extracted
    as patterns the autopilot uses to generate the next winning creative.
    """
    from storage_client import get_ads_client
    ads = get_ads_client()
    record = ads.record_ad_run(req.user_id, req.dict())
    return {
        "status": "recorded",
        "run_id": record["run_id"],
        "is_peak": record["is_peak"],
        "message": (
            "Peak performer flagged — pattern extracted for replication"
            if record["is_peak"] else
            "Run recorded. Build more history to unlock peak replication."
        ),
    }


@app.post("/platform/ads/generate")
@_planned_generation("content", specification=True)
async def ads_generate(req: AdGenerateRequest, _key = Depends(require_scope("generate"))):
    """
    Generate model-written ad copy with subtype-specific placement briefs.

    Account performance history informs targeting, but is not asserted as
    replicated creative. Media briefs are specifications, not rendered assets.
    """
    start = time.time()
    from storage_client import get_ads_client, get_curriculum_client

    ads      = get_ads_client()
    plat     = req.platform.lower()
    ad_type  = req.ad_type.lower()

    # Pull account-specific performance history for targeting.
    peak_formula = None
    if req.replicate_peak:
        peak_formula = ads.get_winning_formula(req.user_id, plat, ad_type)

    # Pull organic engagement signals to cross-enrich targeting
    try:
        curriculum = get_curriculum_client()
        top_organic = curriculum.get_top_performers(req.user_id, platform=plat, top_n=5)
        organic_tags = list({t for p in top_organic for t in p.get("style_tags", [])})
    except Exception:
        organic_tags = []

    # ── Subtype selection & cycling ───────────────────────────────────────────
    # Priority order (highest wins):
    #   1. target_subtypes non-empty + valid  → cycle through exactly those types
    #   2. vary_subtypes=True                 → cycle through all four types
    #   3. vary_subtypes=False                → every creative uses ad_type
    #
    # target_subtypes lets callers request a specific format mix without touching
    # vary_subtypes.  Unknown values are dropped silently; if the entire list is
    # invalid the field is treated as absent.
    _ALL_SUBTYPES = ["video", "audio", "text", "image"]

    _resolved_cycle: list[str]
    _selection_mode: str
    if req.target_subtypes:
        # Validate: keep only known subtypes, preserve caller order
        _valid = [s.lower() for s in req.target_subtypes if s.lower() in _ALL_SUBTYPES]
        if _valid:
            _resolved_cycle = _valid
            _selection_mode = "targeted"
        else:
            # All values invalid — fall back to vary_subtypes logic
            _resolved_cycle = _ALL_SUBTYPES if req.vary_subtypes else [ad_type]
            _selection_mode = "auto_all" if req.vary_subtypes else "fixed"
    elif req.vary_subtypes:
        _resolved_cycle = _ALL_SUBTYPES
        _selection_mode = "auto_all"
    else:
        _resolved_cycle = [ad_type]
        _selection_mode = "fixed"

    # Meta/Google identify ad networks, not social-feed optimization profiles.
    # Retain the network name for ad history/placement while conditioning the
    # dedicated script generator on a supported social profile.
    _social_plat = _ad_social_platform(plat)
    _social_req = req.model_copy(update={"platform": _social_plat})
    _merged_aw = _effective_awareness(_social_plat, _merged_awareness_for(_social_req))

    # Generate N creatives — each slot picks its subtype from the resolved cycle
    creatives = []
    for i in range(req.num_creatives):
        this_type = _resolved_cycle[i % len(_resolved_cycle)]
        creative = await _generate_ad_creative(
            platform=plat,
            ad_type=this_type,
            product=req.product,
            goal=req.goal,
            peak_formula=peak_formula,
            artist_name=req.artist_name,
            genre=req.genre,
            variant_idx=i,
            awareness=_merged_aw,
            instruction=req.instruction,
            content_themes=req.content_themes,
        )
        creatives.append(creative)

    # Audience targeting recommendations
    genre_key = (req.genre or "music_fan").lower().replace("-", "_").replace(" ", "_")
    base_audience = AUDIENCE_SEGMENTS.get(genre_key) or AUDIENCE_SEGMENTS["music_fan"]
    peak_audience = []
    if peak_formula:
        peak_audience = peak_formula.get("top_audience_tags", [])

    targeting = {
        "primary_interests": list(dict.fromkeys(peak_audience + base_audience + organic_tags))[:8],
        "lookalike_source": "existing fans and buyers (1-3%)",
        "retargeting_pool": "website visitors, video viewers (75%+), engagers last 30 days",
        "exclusions": ["existing buyers", "low-quality traffic countries"],
        "age_range": "18-35",
        "placements": {
            "tiktok":    ["TikTok Feed", "TikTok Search"],
            "meta":      ["Instagram Feed", "Instagram Reels", "Facebook Feed", "Meta Audience Network"],
            "youtube":   ["YouTube In-Stream", "YouTube Shorts"],
            "google":    ["Google Search", "Display Network", "Performance Max"],
            "instagram": ["Instagram Feed", "Instagram Reels", "Instagram Stories"],
        }.get(plat, ["Feed", "Stories"]),
    }

    # Budget allocation across creatives (A/B test split)
    budget_split = []
    if req.budget_daily and req.num_creatives > 0:
        test_budget   = round(req.budget_daily * 0.7 / req.num_creatives, 2)
        winner_budget = round(req.budget_daily * 0.3, 2)
        for i in range(req.num_creatives):
            budget_split.append({"variant": i + 1, "daily_budget": test_budget, "phase": "test"})
        budget_split.append({
            "variant": "winner",
            "daily_budget": winner_budget,
            "phase": "scale (set after 3-day test)",
        })

    return {
        "success": True,
        "user_id": req.user_id,
        "platform": plat,
        "ad_type": ad_type,
        "product": req.product,
        "goal": req.goal,
        "peak_replication": {
            "enabled": req.replicate_peak,
            "formula_found": peak_formula is not None,
            "applied": False,  # History is inspected; no unverified replication claim.
            "avg_roas_of_peaks": peak_formula.get("avg_roas") if peak_formula else None,
            "avg_ctr_of_peaks": peak_formula.get("avg_ctr") if peak_formula else None,
        },
        "subtype_selection": {
            "mode": _selection_mode,
            # mode values:
            #   "targeted"  — caller supplied target_subtypes; cycle is that list
            #   "auto_all"  — vary_subtypes=True; cycle is all four types
            #   "fixed"     — vary_subtypes=False; every creative is ad_type
            "cycle": _resolved_cycle,
            "requested": req.target_subtypes or [],
            "applied": list(dict.fromkeys(
                _resolved_cycle[i % len(_resolved_cycle)]
                for i in range(req.num_creatives)
            )),
        },
        "creatives": creatives,
        "targeting": targeting,
        "budget_split": budget_split if budget_split else None,
        "launch_checklist": [
            "Upload creative assets in the correct format for " + plat + " (MP4 for video, PNG/JPG for image)",
            "Set campaign objective to match goal: " + req.goal,
            "Enable auto-bidding (lowest cost) for first 3 days",
            "Set frequency cap: 3 impressions/user/day",
            "Run A/B test for minimum 3 days before scaling winner",
            "Record results in /platform/ads/record to improve future generations",
        ],
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


@app.post("/platform/ads/autopilot")
@_planned_generation("content", specification=True)
async def ads_autopilot(req: AdAutopilotRequest, _key = Depends(require_scope("generate"))):
    """
    Full ad autopilot.
    - Analyses the entire ad portfolio for this user
    - Classifies every ad as: SCALE | MAINTAIN | TEST | KILL
    - Identifies peak performer patterns across all platforms
    - Generates the next campaign recommendations with budget allocation
    - Uses both ad performance data AND organic engagement signals
    """
    start = time.time()
    from storage_client import get_ads_client, get_curriculum_client

    ads = get_ads_client()

    # Portfolio analysis
    portfolio = ads.analyse_portfolio(req.user_id, platform=req.platform)
    peaks     = ads.get_peak_performers(req.user_id, limit=10, platform=req.platform)

    # Cross-enrich with organic engagement signals
    try:
        curriculum   = get_curriculum_client()
        organic_tops = curriculum.get_top_performers(req.user_id, top_n=10)
        organic_tags = list({t for p in organic_tops for t in p.get("style_tags", [])})
    except Exception:
        organic_tops = []
        organic_tags = []

    # Determine what platforms to recommend based on what's working
    active_platforms = list({p.get("platform") for p in peaks if p.get("platform")})
    if not active_platforms:
        active_platforms = ["meta", "tiktok"]

    # Generate next campaign recommendations using the model
    next_campaigns = []
    for plat in (active_platforms or ["meta", "tiktok"])[:3]:
        formula = ads.get_winning_formula(req.user_id, plat, "video")
        ad_idea = f"{req.goal} campaign on {plat}"
        hook = ""
        cta  = AD_CTAS_BY_GOAL.get(req.goal, ["Learn More"])[0]

        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                # No timeout — guaranteed-completion policy.
                script = await _in_thread(lambda p=plat, a=ad_idea: _script_agent.run(ScriptRequest(
                    idea=a, platform=p, goal=req.goal, tone="direct",
                    awareness=_effective_awareness(p, _merged_awareness_for(req)),
                )))
                hook = script.hook
            except Exception:
                pass

        if not hook:
            hook_pool = AD_HOOKS_BY_PLATFORM.get(plat, AD_HOOKS_BY_PLATFORM["meta"])
            hook = hook_pool[0]

        budget_rec = None
        if req.budget_total and len(active_platforms) > 0:
            # Allocate more to platforms with proven peaks
            plat_peaks = [p for p in peaks if p.get("platform") == plat]
            weight     = 1.5 if plat_peaks else 1.0
            total_w    = sum(1.5 if [p for p in peaks if p.get("platform") == ap] else 1.0
                            for ap in active_platforms)
            budget_rec = round(req.budget_total * (weight / total_w), 2)

        next_campaigns.append({
            "platform": plat,
            "recommended_hook": hook,
            "recommended_cta": cta,
            "ad_type": "video",
            "daily_budget": budget_rec,
            "audience": (formula.get("top_audience_tags", [])[:4]
                         if formula else organic_tags[:4]),
            "peak_formula_available": formula is not None,
            "expected_roas": formula.get("avg_roas") if formula else "unknown",
            "expected_ctr": formula.get("avg_ctr") if formula else "unknown",
        })

    # Kill list — what to pause immediately
    kill_recommendations = []
    for run_id in portfolio.get("kill", [])[:5]:
        kill_recommendations.append({
            "run_id": run_id,
            "action": "PAUSE",
            "reason": "Below performance threshold (ROAS < 2.0, CTR < 1.5%)",
        })

    # Scale list — what to double budget on
    scale_recommendations = []
    for run_id in portfolio.get("scale", [])[:5]:
        scale_recommendations.append({
            "run_id": run_id,
            "action": "SCALE",
            "reason": "Peak performer — ROAS ≥ 3.0 AND CTR ≥ 2.5%",
            "budget_multiplier": 2.0,
        })

    return {
        "success": True,
        "user_id": req.user_id,
        "portfolio_summary": {
            "total_ad_runs": portfolio["total_runs"],
            "scale_count":   portfolio["scale_count"],
            "kill_count":    portfolio["kill_count"],
            "avg_roas":      portfolio["avg_roas"],
            "total_spend":   portfolio["total_spend"],
            "total_conversions": portfolio["total_conversions"],
        },
        "autopilot_actions": {
            "scale_immediately":  scale_recommendations,
            "pause_immediately":  kill_recommendations,
            "test_next":         [{"run_id": r, "action": "TEST"} for r in portfolio.get("test", [])[:3]],
        },
        "next_campaigns": next_campaigns,
        "peak_patterns_extracted": len(portfolio.get("peak_patterns", {})),
        "organic_signal_enrichment": {
            "organic_top_tags": organic_tags[:5],
            "cross_platform_signals": len(organic_tops),
        },
        "autopilot_confidence": (
            "high"   if portfolio["total_runs"] >= 10 else
            "medium" if portfolio["total_runs"] >= 3  else
            "low — record more ad runs to improve accuracy"
        ),
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


@app.post("/platform/ads/audience")
@_planned_generation("content", specification=True)
async def ads_audience(req: AdAudienceRequest, _key = Depends(require_scope("generate"))):
    """
    AI-generated audience targeting for paid ads.
    Merges peak performer audience data from storage with organic engagement signals.
    """
    start = time.time()
    from storage_client import get_ads_client, get_curriculum_client

    ads = get_ads_client()
    plat = req.platform.lower()

    # Pull what audiences worked in peak ad runs
    peaks = ads.get_peak_performers(req.user_id, limit=20, platform=plat)
    ad_audiences = list({t for p in peaks for t in p.get("audience_tags", [])})

    # Pull what content resonated organically
    try:
        curriculum   = get_curriculum_client()
        organic_tops = curriculum.get_top_performers(req.user_id, platform=plat, top_n=10)
        organic_tags = list({t for p in organic_tops for t in p.get("style_tags", [])})
    except Exception:
        organic_tags = []

    genre_key = (req.genre or "music_fan").lower().replace("-", "_").replace(" ", "_")
    base_segs = AUDIENCE_SEGMENTS.get(genre_key) or AUDIENCE_SEGMENTS["music_fan"]

    cold_audience = list(dict.fromkeys(ad_audiences + organic_tags + base_segs))[:10]

    lookalikes = []
    if peaks:
        lookalikes = [
            {"source": "peak ad engagers", "percentage": "1%",   "priority": "highest"},
            {"source": "video viewers 75%+", "percentage": "2%", "priority": "high"},
            {"source": "website visitors 30d", "percentage": "3%","priority": "medium"},
        ]
    else:
        lookalikes = [
            {"source": "interest-based cold",  "percentage": "N/A", "priority": "start here"},
            {"source": "video viewers 75%+",   "percentage": "2%",  "priority": "after first campaign"},
        ]

    retargeting_windows = {
        "tiktok":    ["Profile visitors 30d", "Video viewers 50%+ 30d", "Followers"],
        "meta":      ["Page engagers 30d", "Video viewers 75%+ 30d", "Website visitors 30d",
                      "Instagram story openers 7d"],
        "youtube":   ["Channel subscribers", "Video viewers last 30d", "Similar YouTube channels"],
        "google":    ["Website visitors", "Customer list upload", "Similar audiences"],
        "instagram": ["Post engagers 30d", "Story viewers 14d", "Profile visitors 7d"],
    }.get(plat, ["Engagers 30d", "Website visitors"])

    return {
        "success": True,
        "user_id": req.user_id,
        "platform": plat,
        "product": req.product,
        "cold_audience": {
            "interests": cold_audience,
            "age_range": "18-34 primary, 35-44 secondary",
            "gender": "all",
            "source": "peak_ad_data + organic_signals" if peaks else "genre_defaults",
        },
        "lookalike_audiences": lookalikes,
        "retargeting_audiences": retargeting_windows,
        "campaign_funnel": {
            "top_of_funnel":    "Cold interest targeting + lookalikes — awareness",
            "middle_of_funnel": "Video viewers 25%+ + page engagers — consideration",
            "bottom_of_funnel": "Website visitors + past purchasers — conversion",
        },
        "data_quality": {
            "peak_ad_data_points": len(peaks),
            "organic_signal_count": len(organic_tops) if organic_tags else 0,
            "confidence": "high" if len(peaks) >= 5 else "building — record more runs",
        },
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


@app.get("/platform/ads/performance/{user_id}")
async def ads_performance(user_id: str, platform: Optional[str] = None,
                          _key = Depends(verify_api_key)):
    """Full ad performance dashboard for a user."""
    from storage_client import get_ads_client
    ads = get_ads_client()

    runs  = ads.get_ad_runs(user_id, limit=50)
    peaks = ads.get_peak_performers(user_id, limit=10, platform=platform)
    stats = ads.get_stats(user_id)
    portfolio = ads.analyse_portfolio(user_id, platform=platform)

    return {
        "user_id": user_id,
        "stats": stats,
        "portfolio_summary": {
            "total_runs":      portfolio["total_runs"],
            "scale_count":     portfolio["scale_count"],
            "kill_count":      portfolio["kill_count"],
            "avg_roas":        portfolio["avg_roas"],
            "total_spend":     portfolio["total_spend"],
            "total_conversions": portfolio["total_conversions"],
        },
        "peak_performers": peaks[:5],
        "recent_runs": runs[:10],
        "extracted_patterns": portfolio.get("peak_patterns", {}),
    }


@app.post("/platform/ads/optimize")
@_planned_generation("content", specification=True)
async def ads_optimize(
    body: dict,
    _key = Depends(require_scope("generate")),
):
    """
    Given live campaign metrics, tell the platform exactly what to do:
    scale, adjust, pause, or A/B test a new angle.
    Body: {user_id, platform, campaigns: [{run_id, ctr, cpc, roas, spend, conversions}]}
    """
    start = time.time()
    from storage_client import get_ads_client

    user_id   = body.get("user_id", "unknown")
    platform  = body.get("platform", "meta")
    campaigns = body.get("campaigns", [])
    ads       = get_ads_client()
    # This route historically accepted a raw dict.  Normalize its awareness
    # fields into the same cascade used by typed generation requests instead of
    # handing the replacement-hook model an empty context.
    from types import SimpleNamespace
    _awareness_req = SimpleNamespace(
        awareness=body.get("awareness", ""),
        description=body.get("description", ""),
        prompt_url=body.get("prompt_url", ""),
        instruction=body.get("instruction", ""),
        extra_context=body.get("extra_context", ""),
        content_themes=body.get("content_themes"),
    )
    _request_awareness = _merged_awareness_for(_awareness_req)

    actions   = []
    for camp in campaigns:
        roas = float(camp.get("roas", 0))
        ctr  = float(camp.get("ctr", 0))
        _cpc = float(camp.get("cpc", 999))
        run_id = camp.get("run_id", "unknown")

        if roas >= 3.0 and ctr >= 2.5:
            action = "SCALE"
            detail = f"Peak performer. Double budget. ROAS={roas}x CTR={ctr}%"
        elif roas >= 2.0 or ctr >= 1.5:
            action = "MAINTAIN"
            detail = "Solid performance. Hold budget. Consider testing new angle."
        elif roas >= 1.0:
            action = "OPTIMISE"
            detail = f"Borderline. Try new hook/audience. ROAS={roas}x CTR={ctr}%"
        elif ctr < 0.5:
            action = "KILL"
            detail = f"CTR too low ({ctr}%). Pause and replace creative immediately."
        else:
            action = "TEST"
            detail = "Insufficient data. Run for 3 more days before deciding."

        # Generate a replacement hook if killing
        new_hook = None
        if action in ("KILL", "OPTIMISE") and _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                product_hint = camp.get('product', 'music')
                s = await _in_thread(lambda ph=product_hint: _script_agent.run(ScriptRequest(
                    idea=f"new angle for {ph} ad",
                    platform=platform, goal="conversions", tone="direct",
                    awareness=_effective_awareness(platform, _request_awareness),
                )))
                new_hook = s.hook
            except Exception:
                pass

        result = {"run_id": run_id, "action": action, "detail": detail}
        if new_hook:
            result["replacement_hook"] = new_hook
        actions.append(result)

    # Record any peak performers automatically
    for camp in campaigns:
        if float(camp.get("roas", 0)) >= 3.0 or float(camp.get("ctr", 0)) >= 2.5:
            ads.record_ad_run(user_id, {**camp, "platform": platform})

    return {
        "success": True,
        "user_id": user_id,
        "platform": platform,
        "optimizations": actions,
        "summary": {
            "scale":    sum(1 for a in actions if a["action"] == "SCALE"),
            "maintain": sum(1 for a in actions if a["action"] == "MAINTAIN"),
            "kill":     sum(1 for a in actions if a["action"] == "KILL"),
            "test":     sum(1 for a in actions if a["action"] == "TEST"),
        },
        "processing_time_ms": round((time.time() - start) * 1000, 1),
    }


# ─── Storage Pipeline Endpoints ───────────────────────────────────────────────

@app.get("/storage/session")
async def get_storage_session(_key = Depends(verify_api_key)):
    """Read the active training session from the 7TB storage server."""
    from storage_client import get_pipeline, get_storage
    pipeline = get_pipeline()
    session = pipeline.get_session()
    storage_status = pipeline.get_status()
    raw_keys = get_storage().keys("*")
    return {
        "session": session,
        "storage_status": storage_status,
        "available_keys": raw_keys,
        "pipeline": pipeline.pipeline_status(),
    }


@app.get("/storage/pipeline/status")
async def pipeline_status(_key = Depends(verify_api_key)):
    """Return current training pipeline progress."""
    from storage_client import get_pipeline
    return get_pipeline().pipeline_status()


class StorageTrainRequest(BaseModel):
    epochs: int = Field(1, ge=1, le=20)
    batch_size: int = Field(64, ge=8, le=512)
    learning_rate: float = Field(3e-4, gt=0)
    max_batches: Optional[int] = None
    save_checkpoint: bool = True


def _run_storage_training(req: StorageTrainRequest, job_id: str):
    _reject_serving_write()
    """Background task: pull batches from the 7TB storage server and train the model."""
    import math
    from storage_client import get_pipeline, get_checkpoint_client

    pipeline = get_pipeline()
    log_training(f"[StorageTrain] Job {job_id} — pulling from 7TB storage session", job_id=job_id)

    with _training_lock:
        _training_state["state"] = "running"
        _training_state["source"] = "storage"

    try:
        if not _model_ready:
            log_training("Waiting for model to initialize...", job_id=job_id)
            for _ in range(60):
                time.sleep(1)
                if _model_ready:
                    break
            if not _model_ready:
                raise RuntimeError("Model not ready after 60s")

        sys.path.insert(0, str(Path(__file__).parent))
        import torch
        from ai_model.training.trainer import train as run_train
        from ai_model.training.config import TrainConfig

        total_loss = 0.0
        batch_count = 0
        samples_written = []

        log_training("[StorageTrain] Streaming batches from storage...", job_id=job_id)

        for text_batch in pipeline.stream_batches(batch_size=req.batch_size):
            if req.max_batches and batch_count >= req.max_batches:
                break
            samples_written.extend(text_batch)

            # Feed to trainer every 50 samples
            if len(samples_written) >= 50 or (req.max_batches and batch_count == req.max_batches - 1):
                data_path = f"training/storage_batch_{job_id}.json"
                os.makedirs("training", exist_ok=True)
                with open(data_path, "w") as f:
                    json.dump([{"text": t} for t in samples_written], f)

                config = TrainConfig({
                    "train": {
                        "epochs": 1,
                        "batch_size": min(req.batch_size, len(samples_written)),
                        "lr": req.learning_rate,
                    }
                })
                with _model_lock:
                    model = _creative_model.model if _creative_model else None

                if model:
                    result = run_train(model, _tokenizer, data_path, config)
                    loss = result.get("final_loss", result.get("loss", 0.0))
                    if not math.isnan(loss):
                        total_loss += loss
                        batch_count += 1
                        avg_loss = round(total_loss / batch_count, 4)
                        with _training_lock:
                            _training_state["loss"] = avg_loss
                            _training_state["step"] = batch_count
                            _training_state["batches_from_storage"] = batch_count

                        if batch_count % 5 == 0:
                            log_training(
                                f"[StorageTrain] batch={batch_count} loss={avg_loss}",
                                job_id=job_id
                            )

                samples_written = []

        with _training_lock:
            _training_state["state"] = "complete"
            _training_state["completed_at"] = time.time()
            _training_state["final_loss"] = round(total_loss / max(batch_count, 1), 4)
            _training_state["total_storage_batches"] = batch_count

        log_training(
            f"[StorageTrain] Job {job_id} complete — {batch_count} batches, "
            f"loss={_training_state['final_loss']}",
            job_id=job_id
        )

        if req.save_checkpoint and _creative_model:
            try:
                weights_dir = Path(__file__).parent / "ai_model" / "weights"
                weights_dir.mkdir(parents=True, exist_ok=True)
                state_dict = _creative_model.model.state_dict()
                checkpoint = {
                    "model_state_dict": state_dict,
                    "vocab": _tokenizer.vocab,
                    "inv_vocab": _tokenizer.inv_vocab,
                    "merges": _tokenizer.merges,
                    "config": _model_config,
                    "job_id": job_id,
                    "source": "storage",
                    "final_loss": _training_state.get("final_loss"),
                }
                torch.save(checkpoint, str(weights_dir / "model.pt"))
                get_checkpoint_client().save_checkpoint(
                    model_id="maxbooster-v1",
                    state={"job_id": job_id, "batches": batch_count,
                           "final_loss": _training_state.get("final_loss")},
                    metadata={"source": "storage", "session": pipeline._session},
                )
                log_training("[StorageTrain] Checkpoint saved to storage", job_id=job_id)
            except Exception as e:
                log_training(f"[StorageTrain] Checkpoint error: {e}", job_id=job_id, level="error")

    except Exception as e:
        with _training_lock:
            _training_state["state"] = "error"
            _training_state["error"] = str(e)
        log_training(f"[StorageTrain] Job {job_id} failed: {e}", job_id=job_id, level="error")
        import traceback
        traceback.print_exc()
    finally:
        pipeline._active = False


@app.post("/training/start-from-storage")
async def start_training_from_storage(
    req: StorageTrainRequest,
    background_tasks: BackgroundTasks,
    _admin = Depends(verify_admin),
):
    _reject_serving_write()
    """
    Start a training run that pulls data directly from the 7TB storage server.
    Streams batches from the storage session and trains the main MaxBooster model.
    """
    from storage_client import get_pipeline

    with _training_lock:
        if _training_state.get("state") == "running":
            return {"status": "already_running", "training_state": dict(_training_state)}

    pipeline = get_pipeline()
    session = pipeline.get_session()
    if not session:
        raise HTTPException(status_code=404, detail="No training session found in storage server. "
                            "Check /storage/session for details.")

    job_id = str(uuid.uuid4())[:8]
    with _training_lock:
        _training_state["state"] = "starting"
        _training_state["job_id"] = job_id
        _training_state["source"] = "storage"
        _training_state["session_id"] = session.get("id")
        _training_state["total_bytes"] = session.get("bytes", 0)
        _training_state["started_at"] = time.time()
        _training_state["step"] = 0
        _training_state["batches_from_storage"] = 0

    background_tasks.add_task(_run_storage_training, req, job_id)
    return {
        "status": "started",
        "job_id": job_id,
        "session": session,
        "epochs": req.epochs,
        "max_batches": req.max_batches,
        "message": f"Training job {job_id} started — pulling from 7TB storage session",
    }


# ─── New API Endpoints (pipeline-spec, 18 total) ─────────────────────────────

# -- Job stores ----------------------------------------------------------------
# Jobs are stored as atomic JSON files under _JOBS_DIR so every uvicorn
# worker process can read and write the same job state.  Each worker has its
# own in-process threading.Lock for the brief read-modify-write window; POSIX
# os.replace() gives us atomic final writes, so cross-worker reads are safe.

_PRIVATE_STATE_DIR = Path(os.environ.get(
    "MAXCORE_PRIVATE_STATE_DIR", str(Path.home() / ".local" / "state" / "maxcore")))
_PRIVATE_STATE_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
os.chmod(_PRIVATE_STATE_DIR, 0o700)
_JOBS_DIR = str(_PRIVATE_STATE_DIR / "jobs")
os.makedirs(_JOBS_DIR, exist_ok=True, mode=0o700)
os.chmod(_JOBS_DIR, 0o700)
_api_jobs_lock = threading.Lock()   # kept for legacy; file ops are the real store

# ── File-based job lifecycle: coalescing + TTL eviction ──────────────────────
# At 90M concurrent submissions, identical requests must collapse to one job
# rather than flooding _JOBS_DIR with 90M JSON files.  Completed jobs are
# evicted after _JOB_TTL_S seconds by a background GC thread so /tmp stays
# bounded regardless of burst volume.

_JOB_TTL_S        = 600   # evict done/error/cancelled jobs after 10 min
_active_jobs: dict[str, str] = {}   # digest → job_id (in-flight only)
_active_jobs_lock = threading.Lock()


def _job_digest(fields: dict) -> str:
    """Deterministic dedup key for identical concurrent job submissions."""
    from ai_model.generation.plan import active_plan
    plan = active_plan.get()
    fields = {**fields, "plan_hash": plan.plan_hash if plan else None}
    payload = json.dumps(fields, sort_keys=True, default=str).encode()
    return hashlib.blake2b(payload, digest_size=16).hexdigest()


def _job_gc() -> int:
    """Delete expired completed/errored job files; purge stale _active_jobs.
    Returns number of files evicted.  Never raises."""
    threshold = time.time() - _JOB_TTL_S
    evicted   = 0
    try:
        for fname in os.listdir(_JOBS_DIR):
            if not fname.endswith(".json") or fname.endswith(".tmp"):
                continue
            fpath = os.path.join(_JOBS_DIR, fname)
            try:
                _journal_job_id(Path(fpath))
                if os.path.getmtime(fpath) >= threshold:
                    continue
                with open(fpath) as _f:
                    record = json.load(_f)
                status = record.get("status", "")
                # RenderManager's delivery failures are retryable even though
                # its historical journal status is "error". Keep the journal
                # and artifact available for delivery-only restart recovery.
                if (record.get("render_manager") and status == "error"
                        and record.get("scratch_path")):
                    continue
                if status in ("done", "error", "failed", "cancelled"):
                    if record.get("dedicated"):
                        # Keep the durable retry handle if owned scratch cannot
                        # be removed. The helper never deletes unowned paths or
                        # symlinks; an unlink failure leaves this journal intact.
                        from ai_model.generation.dedicated import cleanup_owned_scratch
                        if status == "done" and record.get("result", {}).get("durable") is not True:
                            continue
                        if cleanup_owned_scratch(record) is False:
                            continue
                    os.unlink(fpath)
                    evicted += 1
            except Exception:
                pass
    except Exception:
        pass
    # Purge _active_jobs entries whose file is gone or whose status is terminal.
    stale: list[str] = []
    with _active_jobs_lock:
        for digest, jid in list(_active_jobs.items()):
            j = _job_read(jid)
            if j is None or j.get("status") in ("done", "error", "failed", "cancelled"):
                stale.append(digest)
        for k in stale:
            _active_jobs.pop(k, None)
    return evicted


def _job_gc_loop() -> None:
    while True:
        time.sleep(60)
        try:
            _job_gc()
        except Exception:
            pass


# Start GC daemon immediately — runs for the lifetime of the process.
threading.Thread(target=_job_gc_loop, daemon=True, name="job-file-gc").start()


def _job_path(job_id: str) -> str:
    return os.path.join(_JOBS_DIR, f"{job_id}.json")


def _job_write(job_id: str, data: dict) -> None:
    """Write job data atomically (create or overwrite)."""
    from ai_model.generation.plan import active_plan
    plan = active_plan.get()
    if plan:
        data = {**data, "generation_plan": plan.to_dict(),
                "snapshot_expiry_policy": "optional_context_only"}
        if plan.snapshot_hash is not None:
            data["snapshot_id"] = plan.snapshot_hash
        else:
            data.pop("snapshot_id", None)
    owner = _request_job_owner.get()
    if owner and not data.get("owner_ids"):
        data = {**data, "owner_ids": [owner]}
    tmp = _job_path(job_id) + ".tmp"
    with os.fdopen(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        json.dump(data, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, _job_path(job_id))
    directory_fd = os.open(_JOBS_DIR, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _run_gpu_job(job_id: str, worker) -> None:
    """Own a render GPU in the worker, never in the submitting HTTP lifetime."""
    try:
        from contextlib import ExitStack
        from dataclasses import replace
        from ai_model.awareness import Snapshot, bind, AwarenessUnavailable
        from ai_model.generation.plan import active_plan, GenerationPlan
        saved = (_job_read(job_id) or {}).get("generation_plan")
        if not saved:
            raise RuntimeError("Job has no generation plan")
        scope = ExitStack()
        if isinstance(saved.get("snapshot"), dict):
            try:
                scope.enter_context(bind(Snapshot.parse(saved["snapshot"])))
            except AwarenessUnavailable:
                pass
        with scope, _get_gpu_pool().spawn_sync(f"render:{job_id}"):
            if globals().get("_live_serving_model") is not None:
                scope.enter_context(_live_serving_model.pin(saved.get("checkpoint")))
            plan = GenerationPlan.from_request(saved["request"], saved["modality"], saved["checkpoint"])
            saved_seed = saved.get("seed")
            if isinstance(saved_seed, int) and not isinstance(saved_seed, bool) and 0 <= saved_seed < 2**32:
                plan = replace(plan, seed=saved_seed)
            token = active_plan.set(plan)
            try:
                worker()
            finally:
                active_plan.reset(token)
    except Exception as exc:
        _job_update(job_id, {"status": "error", "error": str(exc)})


def _job_read(job_id: str) -> dict | None:
    """Read job data; returns None if not found."""
    path = _job_path(job_id)
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return None


def _job_update(job_id: str, updates: dict) -> None:
    """Merge updates into an existing job file atomically."""
    import fcntl
    with _api_jobs_lock, open(os.path.join(_JOBS_DIR, ".updates.lock"), "a") as lockfile:
        fcntl.flock(lockfile, fcntl.LOCK_EX)
        data = _job_read(job_id)
        if data is None:
            return
        terminal = data.get("status")
        if terminal in ("done", "error", "failed", "cancelled") and updates.get("status", terminal) != terminal:
            return
        data.update(updates)
        _job_write(job_id, data)


def _job_add_request_owner(job_id: str) -> None:
    """Bind a coalesced job to every authenticated submitting owner."""
    owner = _request_job_owner.get()
    if not owner:
        return
    import fcntl
    with _api_jobs_lock, open(os.path.join(_JOBS_DIR, ".updates.lock"), "a") as lockfile:
        fcntl.flock(lockfile, fcntl.LOCK_EX)
        data = _job_read(job_id)
        if data is None:
            return
        owners = list(data.get("owner_ids") or [])
        if owner not in owners:
            owners.append(owner)
            data["owner_ids"] = owners
            _job_write(job_id, data)


def _require_job_owner(job: dict, request: Request) -> None:
    """Enforce durable ownership while retaining access to legacy ownerless jobs."""
    owners = list(job.get("owner_ids") or [])
    if not owners:
        return
    requester = _request_job_owner.get()
    if not requester or requester not in owners:
        raise HTTPException(status_code=403, detail="Cannot access another user's MaxCore job")


def _journal_job_id(path):
    job_id = path.stem
    if (job_id in ("", ".", "..") or Path(_job_path(job_id)) != path
            or path.is_symlink()):
        raise ValueError(f"Invalid generation journal filename: {path.name}")
    return job_id


def _journal_records():
    paths = list(Path(_JOBS_DIR).glob("*.json"))
    # Validate the complete filename set before any record can be reconciled.
    identities = [(path, _journal_job_id(path)) for path in paths]
    for path, job_id in identities:
        # Corrupt journals are explicit errors, not invitations to re-render.
        with path.open() as handle:
            record = json.load(handle)
        # Legacy producers use the filename as identity and omit job_id.
        yield {**record, "job_id": job_id}


def _persist_generation_job(job_id, record):
    import fcntl
    from ai_model.media_contract import RenderCancelled
    with _api_jobs_lock, open(os.path.join(_JOBS_DIR, ".updates.lock"), "a") as lockfile:
        fcntl.flock(lockfile, fcntl.LOCK_EX)
        current = _job_read(job_id)
        if current and current.get("status") == "cancelled" and record.get("status") != "cancelled":
            raise RenderCancelled("Job cancelled before publication")
        _job_write(job_id, record)


def _create_durable_render_manager(manager_class):
    class OwnedRenderManager(manager_class):
        def render_thumbnail(self, sheet, image_engine=None, owner_id=None):
            owner = _request_job_owner.get()
            if not owner or (owner_id is not None and owner_id != owner):
                raise HTTPException(status_code=403, detail="Authenticated private owner required")
            return super().render_thumbnail(sheet, image_engine=image_engine, owner_id=owner)

        def render_video(self, sheet, video_agent=None, video_agent_request=None, owner_id=None):
            owner = _request_job_owner.get()
            if not owner or (owner_id is not None and owner_id != owner):
                raise HTTPException(status_code=403, detail="Authenticated private owner required")
            return super().render_video(sheet, video_agent=video_agent,
                                        video_agent_request=video_agent_request, owner_id=owner)
    def persist(record):
        _job_write(record["job_id"], {**record, "render_manager": True,
                                     "owner_ids": [record["owner_id"]] if record.get("owner_id") else []})
    manager = OwnedRenderManager(persist_job=persist)
    manager.recover_jobs([r for r in _journal_records() if r.get("render_manager")])
    return manager


@app.on_event("startup")
async def recover_dedicated_delivery():
    global _render_manager
    # Durable delivery recovery does not depend on a trained inference model.
    if _render_manager is None:
        from ai_model.render_manager import RenderManager
        _render_manager = _create_durable_render_manager(RenderManager)
    from ai_model.generation.dedicated import deliver, interrupt_render, cleanup_owned_scratch
    for record in _journal_records():
        if record.get("render_manager"):
            continue  # Reconciled by RenderManager, never re-render here.
        if not record.get("dedicated"):
            if record.get("status") in ("pending", "queued", "running", "rendering"):
                _job_update(record["job_id"], {
                    "status": "error", "failure_stage": "restart",
                    "error": "Generation interrupted by restart; resubmit explicitly",
                })
            continue
        if record.get("status") == "committing":
            try:
                await asyncio.to_thread(deliver, record, persist_job=_persist_generation_job, read_job=_job_read)
            except Exception as exc:
                # Retain committing state and original bytes for delivery-only retry.
                if (_job_read(record["job_id"]) or {}).get("status") != "cancelled":
                    _persist_generation_job(record["job_id"], {**record, "delivery_error": str(exc)})
        elif record.get("status") in ("pending", "queued", "running"):
            interrupt_render(record, persist_job=_persist_generation_job)
        elif record.get("status") == "done" and record.get("result", {}).get("durable") is True:
            cleanup_owned_scratch(record)

# -- Request models ------------------------------------------------------------

class ApiGenerateContentRequest(_AwarenessMixin):
    platform: str
    topic: str
    tone: str
    genre: Optional[str] = None
    artist_name: Optional[str] = None
    artist_bio: Optional[str] = None
    brand_voice: Optional[str] = None
    target_audience: Optional[str] = None
    content_themes: Optional[List[str]] = None
    avoid_topics: Optional[List[str]] = None
    preferred_hashtags: Optional[List[str]] = None
    recent_post_snippets: Optional[List[str]] = None
    # MaxBooster client aliases
    artist: Optional[str] = None
    goal: Optional[str] = None
    title: Optional[str] = None
    # Persistent Brand Voice profile (see storage_client.ArtistProfileClient) —
    # when set, its saved tone/genre/vocabulary/disclosure preferences are
    # pulled in as fallbacks so repeat generations sound consistently on-brand.
    artistProfileId: Optional[str] = None
    # Freeform creative directive for THIS post (the narrative brief). Declared
    # so it is captured instead of silently dropped, then woven into copy.
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    # ── Creator controls (research-driven, additive) ───────────────────────────
    # variants: return N ranked caption alternatives (A/B/C) instead of just the
    #   winner. The composer already scores many candidates internally; this
    #   surfaces the top distinct ones. Deterministic (composition has no RNG).
    variants: Optional[int] = None
    # max_chars: hard platform character budget — the caption is trimmed on a
    #   word boundary to fit and char_count is always reported.
    max_chars: Optional[int] = None
    # Toggle the trailing hashtag block / CTA line off for clean-copy platforms.
    include_hashtags: Optional[bool] = True
    include_cta: Optional[bool] = True
    # ── Producer-metadata steering (what producers ask for: real use of
    # genre/mood/BPM/key, not just a label) ────────────────────────────────
    mood: Optional[str] = None
    bpm: Optional[float] = None
    key: Optional[str] = None
    # ── Cross-platform generation: when set, return one adapted variant per
    # platform in a single call instead of requiring N separate requests. ──
    platforms: Optional[List[str]] = None
    # ── Beat-marketplace conditioning (MaxBooster) ─────────────────────────
    # beat_context: structured facts about the beat being promoted (title,
    #   genre, mood, bpm, key, production_details, target_artist, price_usd,
    #   license_slots_remaining, listen_url, and optionally the measured
    #   audio_analysis block returned by the audio job poll). Serialized into
    #   awareness so copy is written ABOUT the beat, and its pricing anchors
    #   drive a concrete purchase CTA when goal is purchase/conversion.
    beat_context: Optional[dict[str, Any]] = None
    # platform_constraints: {"no_link_in_bio": bool, "professional_register":
    #   bool} — enforced on the finished copy (CTA mechanics + register).
    platform_constraints: Optional[dict[str, Any]] = None


class ApiGenerateCampaignRequest(_AwarenessMixin):
    """Turn one release into a full multi-week, multi-platform rollout campaign.

    The most-requested capability for independent artists/producers: a structured
    release rollout (announce → tease → pre-save → release day → sustain) with
    ready-to-post copy per post plus shared visual art direction.
    """
    title: str                                   # the song / release name
    artist_name: Optional[str] = None
    artist: Optional[str] = None                 # MaxBooster client alias
    genre: Optional[str] = None
    tone: Optional[str] = None
    brand_voice: Optional[str] = None
    target_audience: Optional[str] = None
    platforms: Optional[List[str]] = None        # default ["instagram","tiktok"]
    weeks: Optional[int] = None                  # campaign length, default 6 (2–12)
    release_date: Optional[str] = None           # ISO date; posts get absolute dates
    mood: Optional[str] = None
    bpm: Optional[float] = None
    key: Optional[str] = None
    artistProfileId: Optional[str] = None
    # ── Optional auto-generated visuals (opt-in; text-only plan stays fast by
    # default). ``generate_images`` pairs every post with an on-brand image;
    # ``generate_teasers`` additionally queues a short video teaser for
    # reel/video slots. Both are conditioned on the campaign's shared
    # ``art_direction`` so the whole rollout looks like one release. Images
    # render inline; teasers are async render jobs (poll /api/video-job/{id}).
    generate_images: bool = False
    generate_teasers: bool = False
    instruction:    Optional[str]       = None
    extra_context:  Optional[str]       = None
    content_themes: Optional[List[str]] = None


class ApiGenerateTextRequest(_AwarenessMixin):
    mode: str  # "planner" | "content"
    system: Optional[str] = None
    step: Optional[Any] = None
    inputs: Optional[Any] = None
    slots: Optional[Any] = None
    constraints: Optional[Any] = None
    artistProfileId: Optional[str] = None
    intent: Optional[str] = None
    platformRules: Optional[Any] = None
    # MaxBooster client aliases (content mode)
    platform: Optional[str] = None
    topic: Optional[str] = None
    tone: Optional[str] = None
    prompt: Optional[str] = None
    format: Optional[str] = None
    artist_name: Optional[str] = None
    brand_voice: Optional[str] = None
    extra_context: Optional[Any] = None
    # Freeform creative direction for THIS request (parity with content route).
    instruction: Optional[str] = None
    content_themes: Optional[List[str]] = None


class ApiContentScoreRequest(_AwarenessMixin):
    text: str
    platform: str
    cta: Optional[str] = None
    hashtags: List[str] = []
    userId: Optional[str] = None
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None


class ApiAnalyzeRequest(_AwarenessMixin):
    modality: str
    payload: Any
    artistProfileId: Optional[str] = None
    platforms: List[str] = []
    intent: Optional[str] = None
    metadata: Optional[Any] = None
    platformRules: Optional[Any] = None
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None


class ApiSentimentRequest(_AwarenessMixin):
    text: str
    includeEmotions: Optional[bool] = False
    includeToxicity: Optional[bool] = False
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None


class ApiAnalyzeAudioRequest(BaseModel):
    audio_url: str
    artist_id: Optional[str] = None


class ApiOptimizeAdRequest(_AwarenessMixin):
    action: str  # "score"|"optimize_budget"|"predict_creative"|"forecast_roi"
    campaign: Optional[Any] = None
    campaigns: Optional[List[Any]] = None
    totalBudget: Optional[float] = None
    forecastPeriod: Optional[int] = None
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None


class ApiPredictEngagementRequest(_AwarenessMixin):
    platform: str
    action: str
    content: Any
    postsPerWeek: Optional[int] = None
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None


class ApiGenerateImageRequest(_AwarenessMixin):
    step: Optional[Any] = None
    inputs: Optional[Any] = None
    slots: Optional[Any] = None
    constraints: Optional[Any] = None
    artistProfileId: Optional[str] = None
    intent: Optional[str] = None
    platformRules: Optional[Any] = None
    # MaxBooster client aliases (single-image frame requests)
    prompt: Optional[str] = None
    aspect_ratio: Optional[str] = None
    style: Optional[str] = None
    beat_index: Optional[int] = None
    timecode: Optional[float] = None
    video_style: Optional[str] = None
    style_confidence: Optional[float] = None
    # Opt into the RTA-1 IRC path tracer for the hero background: "pathtraced"
    # (aliases "rta"/"raytraced") renders supported real lit geometry via the
    # Digital GPU, then composites optional poster typography. Unsupported
    # subjects fail explicitly; the PIL default is typography, not subject art.
    render_engine: Optional[str] = None
    # When False, no text is composited onto the image (no headline, no intent
    # tag) — pure artwork for cover art. Default True keeps the poster layout.
    render_text: Optional[bool] = None
    # Freeform creative direction for THIS request (parity with content route).
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None
    # ── Producer-metadata steering (genre/mood/BPM/key now shape the visual
    # style, not just video/audio) ──────────────────────────────────────────
    genre: Optional[str] = None
    mood: Optional[str] = None
    bpm: Optional[float] = None
    key: Optional[str] = None


class ApiGenerateAudioRequest(_AwarenessMixin):
    style_fingerprint: Optional[List[float]] = None
    # Select actual dataset bytes only when the caller explicitly requests a
    # reference sample, rather than substituting a genre-nearest pool track for
    # a bespoke instrumental prompt.
    reference_sample_idx: Optional[int] = None
    notes: Optional[List[Any]] = None
    duration: Optional[float] = 30
    instrument: Optional[str] = None
    genre: Optional[str] = None
    step: Optional[Any] = None
    inputs: Optional[Any] = None
    constraints: Optional[Any] = None
    artistProfileId: Optional[str] = None
    intent: Optional[str] = None
    platformRules: Optional[Any] = None
    # Explicit caller mood — leads over the awareness brief's mood when set
    # (caller awareness leads the platform buffer).  Conditions dataset track
    # selection via the mood→genre affinity map.
    mood: Optional[str] = None
    # Freeform creative direction for THIS request (parity with content route).
    # `prompt` is the user-facing alias (matches what the dashboard / API clients
    # send); `instruction` is the legacy internal name — both are accepted.
    prompt: Optional[str] = None
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None
    # ── Producer-grade controls (what real artists/producers ask for) ─────────
    # Exact musical targets: when set, the rendered clip is pitch-shifted /
    # time-stretched to actually HIT these, not just pick the nearest sample.
    # Both forms accepted: target_bpm/target_key (internal) and bpm/key (alias).
    target_bpm: Optional[float] = None
    target_key: Optional[str] = None
    bpm: Optional[float] = None        # alias → target_bpm
    key: Optional[str] = None          # alias → target_key
    # Reproducibility: same seed + same request → same result (fixes the
    # "great result I can't reproduce" complaint).
    seed: Optional[int] = None
    # Studio export: "wav" (lossless) or "mp3"; sample rate / bit depth; and an
    # EBU-R128 loudness target in LUFS (or a preset name: streaming/club/…).
    format: Optional[str] = None
    sample_rate: Optional[int] = None
    bit_depth: Optional[int] = None
    loudness_lufs: Optional[float] = None
    loudness_preset: Optional[str] = None
    # Remix-ready stems (drums / bass / melody), time-aligned WAVs.
    stems: Optional[bool] = False
    # Awareness-driven song arrangement (intro/verse/hook/… via stem
    # automation). Default ON for clips ≥24 s; pass False for a plain loop.
    arrange: Optional[bool] = None


class SceneOverride(BaseModel):
    index: int
    text: str


class ApiGenerateVideoRequest(_AwarenessMixin):
    idea: str
    media_manifest: Optional[dict] = None
    platform: str = "tiktok"
    genre: Optional[str] = None
    tone: str = "energetic"
    goal: str = "growth"
    duration: Optional[int] = None
    artist_name: Optional[str] = None
    quality: str = "cinematic"
    user_audio_path: Optional[str] = None
    voiceover: bool = False
    # Narrator controls — normalized in the voiceover module (invalid values
    # silently fall back to defaults; never break a render).
    voiceover_voice: Optional[str] = None
    voiceover_wpm: Optional[int] = None
    scenes_override: Optional[List[SceneOverride]] = None
    # MaxBooster client aliases (script + music-video context, used as hints)
    hook: Optional[str] = None
    body: Optional[str] = None
    cta: Optional[str] = None
    topic: Optional[str] = None
    aspect_ratio: Optional[str] = None
    template: Optional[str] = None
    is_drop: Optional[bool] = None
    # Freeform creative direction for THIS request (parity with content route).
    instruction: Optional[str] = None
    extra_context: Optional[str] = None
    content_themes: Optional[List[str]] = None
    energy: Optional[float] = None
    bpm: Optional[float] = None
    mood: Optional[str] = None
    key: Optional[str] = None
    # Persistent Brand Voice profile (see storage_client.ArtistProfileClient).
    artistProfileId: Optional[str] = None
    # ── Cross-platform generation: when set, kick off one render job per
    # platform in a single call instead of requiring N separate requests.
    # Each platform reuses the existing PLATFORM_RATIOS / _PLATFORM_SPECS
    # aspect-ratio + duration logic in VideoAgent — identical to calling the
    # endpoint once per platform, just batched.
    platforms: Optional[List[str]] = None
    # ── Veo-parity generation controls ───────────────────────────────────
    # Matches Google Veo's parameter surface for every dimension that isn't
    # topic or purpose, so callers can express full creative intent without
    # wrapping a second API.
    camera_motion: Optional[str] = None      # pan_left/pan_right/zoom_in/zoom_out/
                                             # tilt_up/tilt_down/dolly_in/dolly_out/
                                             # crane_up/crane_down/static/auto
    negative_prompt: Optional[str] = None   # content/style/elements to avoid
    seed: Optional[int] = None              # explicit seed — reproducible output
    fps: Optional[int] = None               # output frame rate (8/16/24/30); default 24
    motion_intensity: Optional[float] = None # 0.0–1.0; overrides genre-derived energy
    enhance_prompt: bool = True             # False = skip AI awareness augmentation
    lighting: Optional[str] = None          # cinematic/dramatic/natural/studio/
                                            # golden_hour/night/neon
    color_temperature: Optional[str] = None # warm/cool/neutral
    style_reference: Optional[str] = None   # URL or asset ID for style conditioning
    output_resolution: Optional[str] = None # 720p/1080p/4k — overrides platform resolution
    composition: Optional[str] = None       # close_up/medium_shot/wide_shot/
                                            # over_the_shoulder/pov/aerial/
                                            # low_angle/high_angle — shot framing
    reference_images: Optional[List[str]] = None  # up to 10 ordered image assets
                                                  # character consistency ("ingredients")
    first_frame_b64: Optional[str] = None   # base64 image the video should START on
    last_frame_b64: Optional[str] = None    # base64 image the video should END on
    sample_count: Optional[int] = None      # 1–4 independent video variants per request
    generate_audio: bool = True             # auto-render a matched soundtrack when no
                                            # user audio is supplied (native-audio parity)


class ApiVideoExtendRequest(_AwarenessMixin):
    """Veo-parity video extension: continue a previously generated video.

    The last frame of the source video is extracted and used as the
    first-frame conditioning image for a continuation clip, which is then
    concatenated onto the source. One continuous soundtrack is re-rendered
    across the full extended duration so audio stays coherent.
    """
    source: str                              # job_id, filename, or /uploads/videos/... URL
    idea: str = ""                           # what the continuation should be about
    extend_duration: float = 8.0             # seconds to ADD (clamped 2–60)
    platform: str = "tiktok"
    goal: str = "growth"
    tone: str = "energetic"
    genre: Optional[str] = None
    artist_name: Optional[str] = None
    # Veo-parity controls for the continuation clip
    camera_motion: Optional[str] = None
    negative_prompt: Optional[str] = None
    seed: Optional[int] = None
    lighting: Optional[str] = None
    color_temperature: Optional[str] = None
    composition: Optional[str] = None
    generate_audio: bool = True


class ApiAudioAnalyzeRequest(BaseModel):
    """MaxBooster /api/audio/analyze contract — beat/structure analysis."""
    audio_path: Optional[str] = None
    audio_url: Optional[str] = None
    context: Optional[Any] = None


class MasteringSpectralFeatures(BaseModel):
    spectralCentroid: float
    spectralSpread: float
    spectralRolloff: float
    spectralFlux: float
    spectralFlatness: float
    brightness: float
    bassPresence: float
    midPresence: float
    highPresence: float


class MasteringDynamicsFeatures(BaseModel):
    rms: float
    peak: float
    dynamicRange: float
    crestFactor: float


class MasteringRhythmFeatures(BaseModel):
    tempo: float
    tempoConfidence: float
    groove: float
    rhythmComplexity: float


class MasteringTimbreFeatures(BaseModel):
    harmonicRatio: float
    attackTime: float
    decayTime: float
    sustain: float
    noisiness: float
    roughness: float


class MasteringFrequencyBalance(BaseModel):
    sub: float
    bass: float
    lowMid: float
    mid: float
    highMid: float
    presence: float
    brilliance: float


class AudioMasteringRecommendationRequest(BaseModel):
    """Compact, measured feature summary produced from real PCM by the Node DSP."""
    spectral: MasteringSpectralFeatures
    dynamics: MasteringDynamicsFeatures
    rhythm: MasteringRhythmFeatures
    timbre: MasteringTimbreFeatures
    currentLUFS: float
    currentPeak: float
    dynamicRange: float
    stereoWidth: float
    frequencyBalance: MasteringFrequencyBalance
    genre: Optional[str] = None
    sampleRate: int = 44100
    # Elite reference anchoring: the Node layer attaches the measured elite
    # reference profile (target LUFS, true-peak ceiling, LRA, stereo width,
    # 7-band shares) on every request. When present it overrides the
    # genre-preset targets below — the benchmark showed the gap is in
    # mastering/finishing, not genre identity.
    referenceProfile: Optional[Dict[str, Any]] = None


class AudioMixingRecommendationRequest(BaseModel):
    """Per-track feature summary for pre-mixdown corrective EQ + compression.

    Same measured-feature contract as mastering, minus whole-mix-only fields
    (stereo width, integrated LUFS) that don't apply to a single unmixed
    track, plus the track's inferred instrumental role: role -- not overall
    genre -- is the dominant signal for how one track should be corrected.
    """
    role: str = "generic"
    spectral: MasteringSpectralFeatures
    dynamics: MasteringDynamicsFeatures
    rhythm: MasteringRhythmFeatures
    timbre: MasteringTimbreFeatures
    currentPeak: float
    dynamicRange: float
    frequencyBalance: MasteringFrequencyBalance
    genre: Optional[str] = None
    sampleRate: int = 44100


class ApiViralScoreRequest(BaseModel):
    """MaxBooster /api/infer/viral-score contract."""
    model: Optional[str] = None
    inputs: Optional[Any] = None


class ApiTrainFeedbackRequest(BaseModel):
    source: str
    trigger: str
    engagement_rate: float
    platform: str
    content_type: str
    hook_type: str
    media_type: str
    curriculum_hint: Optional[str] = None
    dispatched_at: Optional[str] = None
    source_node: str = "maxbooster"
    version: str = "1.0"


# -- Shared helpers ------------------------------------------------------------

def _api_heuristic_score(text: str, platform: str) -> float:
    """Simple word-count + CTA heuristic returning 0-100."""
    words = len(text.split())
    has_cta = any(w in text.lower() for w in
                  ["click", "follow", "link", "save", "share", "buy", "get", "stream", "listen"])
    length_score  = max(0.0, 1.0 - abs(words - 30) / 60)
    cta_bonus     = 0.15 if has_cta else 0.0
    platform_map  = {"instagram": 0.05, "tiktok": 0.08, "twitter": 0.03,
                     "youtube": 0.04, "facebook": 0.03}
    plat_bonus    = platform_map.get(platform.lower(), 0.0)
    return round(min(100.0, (length_score * 0.8 + cta_bonus + plat_bonus) * 110), 1)


_GENERATION_CONTRACT = "documented-stack-v3"


def _require_model_script(script: Any) -> None:
    """Require real checkpoint prose, allowing disclosed caller composition."""
    source = str(getattr(script, "source", "") or "unknown").lower()
    if source not in {"model", "ai_model", "model_composed"} or not all(
        isinstance(getattr(script, field, None), str)
        and getattr(script, field).strip() for field in ("hook", "body", "cta")
    ):
        raise HTTPException(
            status_code=503,
            detail={"error": "MaxCore model generation unavailable",
                    "source": source},
        )


def _script_provenance(script: Any) -> dict:
    """Composition is not raw checkpoint output or a measured quality claim."""
    source = str(getattr(script, "source", "") or "unknown")
    return {
        "source": source,
        "checkpoint_inference": source in {"model", "ai_model", "model_composed"},
        "composition": "caller_direction" if source == "model_composed" else None,
    }


def _planner_inputs(req: Any) -> dict:
    """Accept both the documented topic shorthand and normalized worker input."""
    if req.inputs is not None and not isinstance(req.inputs, dict):
        raise HTTPException(status_code=422, detail="Planner inputs must be an object")
    data = dict(req.inputs or {})
    for field in ("normalized", "request"):
        if data.get(field) is not None and not isinstance(data[field], dict):
            raise HTTPException(status_code=422, detail=f"Planner {field} must be an object")
    normalized = dict(data.get("normalized") or {})
    request_data = dict(data.get("request") or {})
    for key, value in req.model_dump(exclude={"inputs"}).items():
        if value is not None:
            request_data.setdefault(key, value)
    topic = req.topic or req.prompt
    if topic:
        normalized.setdefault("payload_summary", topic)
        if normalized.get("semantic") is not None and not isinstance(normalized["semantic"], dict):
            raise HTTPException(status_code=422, detail="Planner semantic input must be an object")
        semantic = dict(normalized.get("semantic") or {})
        semantic.setdefault("topic", topic)
        normalized["semantic"] = semantic
    if req.intent:
        normalized.setdefault("intent", req.intent)
    if "packSpec" not in data:
        slots = req.slots
        if slots is None:
            modality = req.format if req.format in {"text", "image", "audio", "video"} else "text"
            slots = [{"id": f"{modality}_1", "modality": modality,
                      "platform": req.platform or "general",
                      "purpose": req.intent or "content"}]
        if not isinstance(slots, list):
            raise HTTPException(status_code=422, detail="Planner slots must be a list")
        data["packSpec"] = slots
    return {**data, "normalized": normalized, "request": request_data}


def _api_hashtags(topic: str, genre: Optional[str], platform: str) -> List[str]:
    tags = [f"#{topic.replace(' ', '')}", f"#{platform}"]
    if genre:
        tags.append(f"#{genre.replace(' ', '')}")
    tags += ["#music", "#newrelease", "#artist"]
    return list(dict.fromkeys(tags))[:6]


def _trim_to_chars(text: str, limit: int) -> str:
    """Trim text to at most `limit` chars on a word boundary (keeps whole words).

    Falls back to a hard cut only when the very first word already exceeds the
    budget. Never raises; used to enforce platform character caps on captions.
    """
    if limit <= 0 or len(text) <= limit:
        return text
    cut = text[:limit]
    sp = cut.rfind(" ")
    trimmed = cut[:sp] if sp > 0 else cut
    return trimmed.rstrip()


def _api_model_state(domain: str) -> dict:
    from datetime import datetime as _dt
    return {
        "domain":        domain,
        "version":       "1.0.0",
        "trained_at":    _dt.utcnow().isoformat() + "Z",
        "session_count": _training_state.get("steps_done", 0),
        "loss":          _training_state.get("last_loss"),
        "weights": {
            "embed_dim":  512,
            "n_layers":   8,
            "vocab_size": 172,
            "ready":      _model_ready,
        },
    }


# -- Content Generation --------------------------------------------------------

@app.post("/api/generate/content")
@_planned_generation("content")
async def api_generate_content(req: ApiGenerateContentRequest, _key=Depends(require_scope("generate"))):
    """Captions, hooks, CTAs for social posts with artist context."""
    start    = time.time()

    platform = normalize_platform(req.platform)
    artist   = req.artist_name or req.artist or "the artist"
    topic    = _resolve_topic_from_url(req.topic or req.title or "")
    goal     = req.goal or "engagement"

    # ── Beat-marketplace conditioning: fold structured beat_context into the
    # request's awareness (the canonical conditioning channel — merge_awareness
    # reads req.awareness) so both the model path and the awareness-composed
    # path write about the actual beat. `idea`/topic stays a clean string. ──
    from ai_model import request_intelligence as _ri_bc
    _beat_aw = _ri_bc.beat_context_awareness(req.beat_context)
    if _beat_aw:
        _aw_prev = req.awareness
        if isinstance(_aw_prev, dict):
            _aw_prev = (_aw_prev.get("contextString", "") or "")
        req.awareness = "\n".join(
            p for p in [(_aw_prev or "").strip(), _beat_aw] if p)
    _pc = req.platform_constraints if isinstance(req.platform_constraints, dict) else None
    _listen_url = (_ri_bc.sanitize_listen_url(req.beat_context.get("listen_url"))
                   if isinstance(req.beat_context, dict) else "")
    # Purchase goal → concrete conversion CTA anchored on real price/scarcity/
    # URL instead of the generic engagement library line.
    _purchase_goal = _ri_bc.GOAL_ALIASES.get(
        str(goal).strip().lower(), str(goal).strip().lower()) == "drive_conversion"
    _purchase_cta = (_ri_bc.purchase_cta(req.beat_context, platform, _pc)
                     if _purchase_goal else "")

    def _build(_request=None, _platform=None):
        # ── Request intelligence: analyse intent, audience & strategy up front ──
        from ai_model import request_intelligence as ri
        from ai_model.generation import build_context
        _plat = _platform or platform
        _narrative = " ".join(
            filter(None, [req.instruction, req.extra_context, req.artist_bio])
        )
        # Unified orchestrator: brief + merged awareness in one call. Technique
        # extraction is skipped on the hot text path (no media rendered here).
        _ctx = build_context(
            "content", req, with_technique=False,
            platform=_plat, topic=topic, goal=goal,
            tone=req.tone, genre=req.genre, artist=artist,
            extra=" ".join(filter(None, [req.brand_voice, req.target_audience])),
            narrative=_narrative,
            track=req.title or topic,
            themes=req.content_themes,
            mood=req.mood, bpm=req.bpm, key=req.key,
            artist_profile_id=req.artistProfileId,
        )
        brief = _ctx.brief

        # ── Awareness bridge input ─────────────────────────────────────────
        # Condition real model inference with caller direction and live signals.
        # A deterministic awareness response is not model-generated copy.
        #   1. the caller's creative direction for THIS post (instruction /
        #      extra_context / themes), serialised into signal lines by
        #      `awareness_from_direction` — the narrative is lead-in-stripped
        #      first (the parser strips nothing itself) and themes go in as a
        #      bullet, never as #hashtags (the distribution agent harvests
        #      awareness hashtags into a persistent, platform-shared pool);
        #   2. genuine external awareness (client-supplied live trend data),
        #      which only reaches this handler now that the request model
        #      extends _AwarenessMixin — before that it was silently dropped,
        #      so this path never actually fed the bridge.
        # `brief.directives` are deliberately excluded: they are internal
        # prompt-engineering instructions the parser would quote verbatim.
        _merged_awareness = _effective_awareness(_plat, _ctx.awareness)

        if not (_model_ready and _script_agent):
            raise HTTPException(status_code=503, detail="Content model unavailable")
        from ai_model.agents.script_agent import ScriptRequest
        _variants_want = min(10, max(1, int(req.variants or 1)))
        scripts = []
        for idx in range(_variants_want):
            try:
                sr = _script_agent.run(ScriptRequest(
                    idea=topic, platform=_plat, goal=goal, tone=brief.tone,
                    awareness=_merged_awareness, variant_idx=idx,
                    genre=req.genre or "", target_audience=req.target_audience or "",
                ))
            except Exception as exc:
                raise HTTPException(status_code=503,
                                    detail=f"Content model inference failed: {exc}") from exc
            _require_model_script(sr)
            scripts.append(sr)

        # ── Creator controls: CTA toggle → rebuild caption without the CTA line;
        # char budget → trim on a word boundary. Applied to every variant so the
        # winner and the alternatives stay consistent. ──────────────────────────
        def _apply_controls(v: dict) -> dict:
            hook_v, body_v, cta_v = v["hook"], v["body"], v["cta"]
            # Purchase goal + concrete beat anchors → override the generic
            # library CTA with the real price/scarcity/URL line.
            if _purchase_cta:
                cta_v = _purchase_cta
            # Platform constraints are enforced on every copy part so no
            # variant leaks link-in-bio mechanics or off-register emoji asks.
            if _pc:
                hook_v = ri.apply_platform_constraints(hook_v, _pc, _listen_url)
                body_v = ri.apply_platform_constraints(body_v, _pc, _listen_url)
                cta_v  = ri.apply_platform_constraints(cta_v,  _pc, _listen_url)
            if _purchase_cta or _pc:
                cap = "\n\n".join(p for p in (hook_v, body_v, cta_v) if p).strip()
            else:
                cap = v["caption"]
            if req.include_cta is False:
                cap = f"{hook_v}\n\n{body_v}".strip()
            if req.max_chars and len(cap) > int(req.max_chars):
                cap = _trim_to_chars(cap, int(req.max_chars))
            return {**v, "hook": hook_v, "body": body_v, "cta": cta_v,
                    "caption": cap, "char_count": len(cap)}

        variant_objs = [_apply_controls({
            "caption": "\n\n".join((sr.hook, sr.body, sr.cta)),
            "hook": sr.hook, "body": sr.body, "cta": sr.cta,
            **_script_provenance(sr),
        }) for sr in scripts]
        # Rank actual generated candidates, never manufacture a pool winner.
        # This is an editorial heuristic, not a calibrated quality/confidence
        # or engagement prediction.
        variant_objs.sort(key=lambda v: _ad_hook_score(v["hook"]), reverse=True)
        for variant in variant_objs:
            variant["hook_assessment"] = {
                "metric": "power_punctuation_emoji",
                "score": _ad_hook_score(variant["hook"]),
                "kind": "heuristic_not_engagement_prediction",
            }
        # Disclosure is opt-in (Brand Voice profile). Applied after trimming,
        # then re-checked against max_chars: if appending the label would blow
        # the caller's explicit character budget, the label is dropped rather
        # than silently exceeding a hard platform limit.
        caption = ri.apply_disclosure(variant_objs[0]["caption"], brief)
        if req.max_chars and len(caption) > int(req.max_chars):
            caption = variant_objs[0]["caption"]

        hashtags = (req.preferred_hashtags or []) + _api_hashtags(topic, req.genre, _plat)
        hashtag_cap = min(10, max(brief.hashtags_target, len(req.preferred_hashtags or [])))
        if req.include_hashtags is False:
            hashtags = []
            hashtag_cap = 0
        return {
            "caption":    caption,
            "char_count": len(caption),
            "variants":   variant_objs,
            "hook":       variant_objs[0]["hook"],
            "body":       variant_objs[0]["body"],
            "cta":        variant_objs[0]["cta"] if req.include_cta is not False else "",
            "hashtags":   list(dict.fromkeys(hashtags))[:hashtag_cap] if hashtag_cap else [],
            "source": variant_objs[0]["source"],
            "provenance": {
                "script": {k: variant_objs[0][k] for k in
                           ("source", "checkpoint_inference", "composition")},
                "postprocessing": ["platform_constraints", "caption_budget", "disclosure"],
            },
            "generation_contract": _GENERATION_CONTRACT,
            "ai_disclosure": brief.ai_disclosure,
            "platform": _plat,
            "intelligence": brief.to_dict(),
        }

    # ── Cross-platform generation: one call → one adapted variant per
    # requested platform (aspect ratio / copy length / hook style each follow
    # that platform's profile), instead of forcing N separate requests. ─────
    if req.platforms:
        _plats = [normalize_platform(p) for p in req.platforms if p]
        _by_platform = {p: _build(_platform=p) for p in dict.fromkeys(_plats)}
        if _by_platform:
            first = next(iter(_by_platform.values()))
            _xplat_out: dict = {
                **first,
                "platform_variants": _by_platform,
                "processing_time_ms": round((time.time() - start) * 1000, 1),
            }
            _sm = _get_storage_mode()
            if _sm != "live":
                _xplat_out["storage_warning"] = (
                    "pdim storage is offline — quality awareness and retrieval index are "
                    f"running in {_sm.replace('_', ' ')} mode; output quality may be reduced"
                )
            return _xplat_out
        # `platforms` was present but contained no usable entries (e.g. [""])
        # — fall through to the normal single-platform path below instead of
        # crashing on an empty dict.

    # ── Default content-gen path: dedup + single-flight via PDIM orchestrator ──
    # Concurrent identical requests collapse to ONE compute; the rest share it.
    # Only the model path is cached — heuristic-only output stays uncached, as before.
    # Brand-voice requests bypass the cache entirely: the cache key is derived
    # from the request payload only, but build_brief() also reads the artist's
    # stored profile (tone/genre/vocabulary/ai_disclosure) — an identical
    # request could otherwise replay a stale caption/disclosure after the
    # artist edits their profile.
    if _model_ready and not req.artistProfileId:
        # Async coalescer sits BEFORE the thread pool: identical-digest requests
        # share one asyncio.Future (suspended coroutines, ~2 KB each) rather
        # than each blocking an executor thread (~8 MB).  Only unique digests
        # enter _in_thread → INFERENCE_GATE → GPU.
        # The key MUST cover every request field that changes the output —
        # a coarser key (platform/topic/tone/goal/awareness only) collapsed
        # concurrent calls that differed by instruction/max_chars/variants
        # into one leader's result (identical hooks, untrimmed captions).
        _awareness_key = _effective_awareness(platform, _merged_awareness_for(req))
        _key = {
            "generation_contract": _GENERATION_CONTRACT,
            "plan_hash": _generation_plan_hash(),
            "platform": platform,
            "topic":    topic,
            "tone":     req.tone or "",
            "goal":     goal,
            "awareness": _awareness_key,
            "platform_optimization": _platform_optimization_awareness(req),
            "instruction":   req.instruction or "",
            "extra_context": req.extra_context or "",
            "themes":        req.content_themes or [],
            "brand_voice":   req.brand_voice or "",
            "audience":      req.target_audience or "",
            "genre":         req.genre or "",
            "mood":          req.mood or "",
            "artist":        artist,
            "title":         req.title or "",
            "variants":      req.variants or 0,
            "max_chars":     req.max_chars or 0,
            "include_hashtags": bool(req.include_hashtags),
            "include_cta":      req.include_cta is not False,
            "preferred_hashtags": req.preferred_hashtags or [],
        }
        async def _coalesced_content():
            # Admission/lifecycle belongs to actual model execution (one batch
            # or unbatched forward), not cache reads or waiting submitters.
            _orch = _get_pdim_orchestrator()
            return await _in_thread(
                lambda: _orch.compute(_key, _build, namespace="api_content_stack_v3")
            )
        _out = await _get_async_coalescer().compute(_key, _coalesced_content)
        result = dict(_out["result"])
        if (result.get("source") not in {"ai_model", "model", "model_composed"}
                or result.get("generation_contract") != _GENERATION_CONTRACT
                or "quality_score" in result or "confidence" in result):
            raise HTTPException(status_code=503, detail="Cached content lacks current model provenance")
        if _out.get("source") in ("cache", "coalesced"):
            result["cached"] = True
    else:
        result = _build()
    _sm = _get_storage_mode()
    if _sm != "live":
        result["storage_warning"] = (
            "pdim storage is offline — quality awareness and retrieval index are "
            f"running in {_sm.replace('_', ' ')} mode; output quality may be reduced"
        )
    result["processing_time_ms"] = round((time.time() - start) * 1000, 1)
    return result


# Default still-image layout per (normalized) platform for campaign artwork.
# Reel/story slots override this to vertical regardless of platform.
_CAMPAIGN_LAYOUT_BY_PLATFORM: dict[str, str] = {
    "instagram": "square_1_1",
    "facebook":  "square_1_1",
    "tiktok":    "vertical_9_16",
    "youtube":   "landscape_16_9",
    "twitter":   "landscape_16_9",
    "linkedin":  "landscape_16_9",
}


@app.post("/api/generate/campaign")
@_planned_generation("campaign")
async def api_generate_campaign(req: ApiGenerateCampaignRequest, _key=Depends(require_scope("generate"))):
    """Turn one release into a full rollout campaign.

    The most-requested capability for independent artists/producers (Water & Music
    survey; RouteNote/NotNoise/Chartlex rollout guides): a structured multi-week,
    multi-platform content calendar — announce → tease → pre-save → release day →
    sustain — with ready-to-post copy per post plus shared visual art direction,
    so one song becomes a whole campaign. Composes the same brief + caption
    engine as ``/api/generate/content`` and the unified Visual-DNA technique
    engine. The calendar builder returns planned copy and optional asset jobs;
    a queued teaser is not a completed video.
    """
    start = time.time()
    from ai_model.generation import build_campaign

    artist = req.artist_name or req.artist or "the artist"

    # ── Optional per-post asset generators (opt-in) ───────────────────────────
    # Reuse the existing in-house image engine and video render pipeline, but
    # condition every asset on the campaign's SHARED art_direction (palette +
    # mood) so the whole rollout looks like one release. Both are never-raise:
    # a failed asset just leaves that post text-only.
    def _campaign_image_fn(*, topic, headline, platform, fmt, purpose, art_direction):
        """Render one on-brand still image via the ImageEngine (/api/generate/image
        engine), forced onto the campaign's shared palette/mood. Runs inline."""
        if not _image_engine:
            return None
        try:
            from ai_model.image.image_engine import ImageRequest
            _plat = normalize_platform(platform)
            # Reels/stories are vertical; feed posts follow the platform default.
            layout = "vertical_9_16" if fmt in ("reel", "story") \
                else _CAMPAIGN_LAYOUT_BY_PLATFORM.get(_plat, "square_1_1")
            ad = art_direction or {}
            color_scheme = ad.get("color_scheme") or "dark_neon"
            mood = ad.get("mood")
            style_tags = [t for t in [mood] if t] or ["cinematic"]
            prompt = f"{mood or 'cinematic'} promotional visual for: {topic}"
            # Deterministic seed → cohesive, reproducible campaign artwork.
            seed = abs(hash((artist, topic, _plat, fmt, headline))) % (2 ** 31)
            _req = ImageRequest(
                prompt=prompt, headline=str(headline or topic),
                color_scheme=color_scheme, layout=layout, platform=_plat,
                artist_name=artist, intent=purpose or "promotional",
                style_tags=style_tags, seed=seed,
            )
            res = _image_engine.render(_req)
            if not (res and res.success):
                return None
            # Fold produced image back into the retrieval index (never-raise).
            try:
                from ai_model.retrieval.generated_ingestor import get_generated_ingestor
                from ai_model.image.image_engine import _UPLOADS_DIR as _IMG_DIR
                get_generated_ingestor().enqueue(
                    str(_IMG_DIR / res.filename), brand=artist,
                    endpoint="/api/generate/campaign", platform=_plat,
                )
            except Exception:
                pass
            return {
                "type": "image", "url": res.url, "width": res.width,
                "height": res.height, "format": "png",
                "meta": {
                    "color_scheme": res.color_scheme, "layout": res.layout,
                    "engine": "maxbooster-pil-v1",
                    "conditioned_on": "campaign_art_direction",
                },
            }
        except Exception:
            return None

    def _campaign_teaser_fn(*, topic, hook, body, cta, platform, purpose, art_direction):
        """Queue one short video teaser via the /api/generate-video pipeline,
        conditioned on the campaign's genre/mood so it matches the art direction.
        Async: returns the render job id to poll."""
        if not (_model_ready and _script_agent and _visual_spec_agent and _creative_model):
            return None
        try:
            ad = art_direction or {}
            vreq = ApiGenerateVideoRequest(
                idea=topic, platform=normalize_platform(platform),
                genre=req.genre, tone=req.tone or "energetic",
                goal=purpose or "awareness", artist_name=artist,
                hook=hook, body=body, cta=cta, topic=topic,
                mood=ad.get("mood") or req.mood, bpm=req.bpm, key=req.key,
                # Propagate campaign awareness so teaser video briefs and scene
                # selection carry the same live chart signal as the post copy.
                awareness=_campaign_awareness,
            )
            jid, _brief = _start_video_job(vreq, normalize_platform(platform))
            return {
                "type": "video", "job_id": jid, "status": "processing",
                "poll_url": f"/api/video-job/{jid}",
                "meta": {"conditioned_on": "campaign_art_direction"},
            }
        except Exception:
            return None

    image_fn = _campaign_image_fn if req.generate_images else None
    teaser_fn = _campaign_teaser_fn if req.generate_teasers else None

    # Compute campaign awareness once — shared across all posts for consistency.
    _campaign_awareness = _merged_awareness_for(req)
    _campaign_platform = normalize_platform(
        next((p for p in (req.platforms or []) if p), "instagram"))

    def _build():
        return build_campaign(
            artist=artist,
            title=req.title,
            genre=req.genre,
            tone=req.tone,
            brand_voice=req.brand_voice,
            target_audience=req.target_audience,
            platforms=req.platforms,
            weeks=req.weeks or 6,
            mood=req.mood,
            bpm=req.bpm,
            key=req.key,
            release_date=req.release_date,
            hashtag_fn=_api_hashtags,
            normalize_platform_fn=normalize_platform,
            script_fn=_script_agent.run,
            image_fn=image_fn,
            teaser_fn=teaser_fn,
            seed=abs(hash(f"{artist}|{req.title}")) % 100000,
            awareness=_effective_awareness(
                _campaign_platform, _campaign_awareness),
        )

    # Every slot executes real model inference, including text-only campaigns.
    # Keep those CPU-bound calls off the API event loop as well as asset work.
    plan = await _in_thread(_build)
    plan["source"] = "campaign_composer"
    plan["processing_time_ms"] = round((time.time() - start) * 1000, 1)
    return plan


# ── Campaign scheduling: persist a generated rollout as an editable calendar ───
# The generate endpoint above returns a plan the artist must post manually. These
# endpoints let an artist SAVE that plan per-artist, retrieve it as a by-date
# calendar, edit copy / move dates / mark posts scheduled|posted, and hand posts
# off to the distribution agent to queue on their target dates.

class CampaignSaveRequest(BaseModel):
    profile_id: str                           # per-artist calendar partition
    plan: dict                                # a /api/generate/campaign result
    name: Optional[str] = None


class CampaignPostPatch(BaseModel):
    profile_id: str
    hook: Optional[str] = None
    body: Optional[str] = None
    cta: Optional[str] = None
    caption: Optional[str] = None
    hashtags: Optional[List[str]] = None
    date: Optional[str] = None                 # move the post to a new date
    platform: Optional[str] = None
    format: Optional[str] = None
    brief: Optional[str] = None
    status: Optional[str] = None               # draft | scheduled | posted


class CampaignScheduleRequest(BaseModel):
    profile_id: str
    post_ids: Optional[List[str]] = None       # default: every not-yet-posted post
    handoff: bool = True                       # use the distribution agent


def _campaign_view(doc: dict) -> dict:
    """Attach a by-date calendar view to a stored campaign doc."""
    from storage_client import get_campaign_client
    out = dict(doc)
    out["calendar"] = get_campaign_client().calendar(doc)
    return out


@app.post("/api/campaigns")
async def api_campaign_save(req: CampaignSaveRequest,
                            _key=Depends(require_scope("generate"))):
    """Persist a generated campaign plan as an editable, schedulable calendar."""
    from storage_client import get_campaign_client
    doc = get_campaign_client().save_campaign(
        req.profile_id, req.plan, name=req.name,
    )
    return {"status": "saved", "campaign": _campaign_view(doc)}


@app.get("/api/campaigns")
async def api_campaign_list(profile_id: str,
                            _key=Depends(require_scope("read"))):
    """List an artist's saved campaigns (summaries with per-status counts)."""
    from storage_client import get_campaign_client
    return {"campaigns": get_campaign_client().list_campaigns(profile_id)}


@app.get("/api/campaigns/{campaign_id}")
async def api_campaign_get(campaign_id: str, profile_id: str,
                           _key=Depends(require_scope("read"))):
    """Retrieve one saved campaign with its by-date calendar."""
    from storage_client import get_campaign_client
    doc = get_campaign_client().get_campaign(profile_id, campaign_id)
    if not doc:
        raise HTTPException(status_code=404, detail="campaign not found")
    return {"campaign": _campaign_view(doc)}


@app.delete("/api/campaigns/{campaign_id}")
async def api_campaign_delete(campaign_id: str, profile_id: str,
                              _key=Depends(require_scope("generate"))):
    """Delete a saved campaign."""
    from storage_client import get_campaign_client
    ok = get_campaign_client().delete_campaign(profile_id, campaign_id)
    if not ok:
        raise HTTPException(status_code=404, detail="campaign not found")
    return {"status": "deleted", "campaign_id": campaign_id}


@app.patch("/api/campaigns/{campaign_id}/posts/{post_id}")
async def api_campaign_edit_post(campaign_id: str, post_id: str,
                                 patch: CampaignPostPatch,
                                 _key=Depends(require_scope("generate"))):
    """Edit a single post — swap copy, move its date, retarget the platform, or
    mark it scheduled/posted."""
    from storage_client import get_campaign_client
    updated = get_campaign_client().update_post(
        patch.profile_id, campaign_id, post_id,
        patch.model_dump(exclude={"profile_id"}, exclude_none=True),
    )
    if updated is None:
        raise HTTPException(status_code=404, detail="campaign or post not found")
    return {"status": "updated", "post": updated}


@app.post("/api/campaigns/{campaign_id}/schedule")
async def api_campaign_schedule(campaign_id: str, req: CampaignScheduleRequest,
                                _key=Depends(require_scope("generate"))):
    """Hand posts off to the distribution layer to queue on their target dates.

    Marks the targeted posts ``scheduled`` and — when ``handoff`` is set and the
    distribution agent is available — attaches the agent's recommended posting
    time + pitch per post so the calendar carries a real distribution plan, not
    just a flag. Never fails on a single post's hand-off."""
    from storage_client import get_campaign_client

    dist_fn = None
    if req.handoff and _model_ready and _distribution_agent is not None:
        from ai_model.agents.distribution_agent import DistributionRequest

        def dist_fn(post: dict) -> Optional[dict]:
            plat = normalize_platform(post.get("platform", "instagram"))
            script = post.get("hook") or post.get("caption") or plat
            d = _distribution_agent.run(DistributionRequest(
                script=script, platform=plat, goal=post.get("goal", "awareness"),
            ))
            return {
                "queued": True,
                "platform": plat,
                "target_date": post.get("date"),
                "posting_time": getattr(d, "posting_time", None),
                "pitch": getattr(d, "caption", None),
                "source": getattr(d, "source", "model"),
                "queued_at": time.time(),
            }

    doc = await _in_thread(lambda: get_campaign_client().mark_scheduled(
        req.profile_id, campaign_id, post_ids=req.post_ids, distribution_fn=dist_fn,
    ))
    if doc is None:
        raise HTTPException(status_code=404, detail="campaign not found")
    return {
        "status": "scheduled",
        "scheduled_count": doc.get("last_scheduled_count", 0),
        "handoff": bool(dist_fn),
        "campaign": _campaign_view(doc),
    }


@app.post("/api/generate/text")
@_planned_generation("text", deterministic_planner=True)
async def api_generate_text(req: ApiGenerateTextRequest, _key=Depends(require_scope("generate"))):
    """Two-mode text generation — planner or content."""
    start = time.time()

    if req.mode == "planner":
        # The documented planner is a modality router, not a learned planning
        # model. Expose that actual implementation with explicit provenance.
        return await maxcore_generate_text(
            MaxcoreTextRequest(mode="planner", input=_planner_inputs(req),
                               awareness=_merged_awareness_for(req)),
            _key=_key,
        )
    if req.mode != "content":
        raise HTTPException(status_code=422, detail="mode must be planner or content")

    # mode == "content"
    intent   = req.intent or "create content"
    inputs   = req.inputs or {}
    # MaxBooster sends topic/prompt directly; resolve URLs via the Universal URL Parser
    idea     = _resolve_topic_from_url(req.topic or req.prompt or (str(inputs) if inputs else intent))
    platform = normalize_platform(req.platform) if req.platform else "general"
    tone     = req.tone or "authentic"
    if not _model_ready or not _script_agent:
        raise HTTPException(
            status_code=503,
            detail={
                "error": "MaxCore text generation inference unavailable",
                "required_capability": "loaded ScriptAgent model",
            },
        )

    def _build(_request=None):
        # ── Request intelligence: analyse intent, audience & strategy up front ──
        from ai_model import request_intelligence as ri
        from ai_model.generation import build_context
        # Unified orchestrator: brief + merged awareness in one call.
        _ctx = build_context(
            "text", req, with_technique=False,
            platform=platform, topic=idea, goal=intent, tone=tone,
            extra=getattr(req, "brand_voice", None),
        )
        brief = _ctx.brief

        candidates: List[str] = []

        from ai_model.agents.script_agent import ScriptRequest

        # Keep `idea` clean: internal directives are not real-world awareness.
        sr = _script_agent.run(ScriptRequest(
            idea=idea, platform=platform, goal=intent, tone=brief.tone,
            awareness=_effective_awareness(platform, _ctx.awareness),
        ))
        _require_model_script(sr)
        model_text = "\n".join(
            part for part in (sr.hook, sr.body, sr.cta) if isinstance(part, str) and part.strip()
        ).strip()
        if not model_text:
            raise RuntimeError("ScriptAgent returned empty model output")
        candidates.append(model_text)
        # Do not replace checkpoint text with an unlabelled hook-pool template.
        # Editorial ranking is distinct from a model/engagement quality score.

        ranked  = ri.rank_candidates(candidates, brief)
        if not ranked:
            raise RuntimeError("Model output could not be ranked")
        content = ranked[0][0]
        outputs = [{
            "type":    "text",
            "content": content,
            "text":    content,
            "slot":    req.slots,
        }]
        # Top-level aliases the MaxBooster client reads (text/content/script/caption)
        return {
            "outputs":            outputs,
            "text":               content,
            "content":            content,
            "script":             content,
            "caption":            content,
            **_script_provenance(sr),
            "hook_assessment": {
                "metric": "power_punctuation_emoji",
                "score": _ad_hook_score(sr.hook),
                "kind": "heuristic_not_engagement_prediction",
            },
            "generation_contract": _GENERATION_CONTRACT,
            "intelligence": {
                **brief.to_dict(),
                "candidates_considered": len(ranked),
            },
        }

    # ── Default content-gen path: dedup + single-flight via PDIM orchestrator ──
    # Async coalescer first (coroutine-level), then pdim orchestrator (thread-level).
    try:
        _key = {
            "generation_contract": _GENERATION_CONTRACT,
            "plan_hash": _generation_plan_hash(),
            "platform": getattr(req, "platform", ""),
            "topic":    getattr(req, "topic", "") or getattr(req, "idea", ""),
            "tone":     getattr(req, "tone", "") or "",
            "goal":     getattr(req, "goal", "") or "",
            "awareness": _effective_awareness(
                platform, _merged_awareness_for(req)),
            "platform_optimization": _platform_optimization_awareness(req),
        }
        async def _coalesced_social():
            # Actual batch/unbatched execution owns its admission and GPU.
            _orch = _get_pdim_orchestrator()
            return await _in_thread(
                lambda: _orch.compute(_key, _build, namespace="api_text_stack_v3")
            )
        _out = await _get_async_coalescer().compute(_key, _coalesced_social)
        result = dict(_out["result"])
        if (result.get("source") not in {"ai_model", "model", "model_composed"}
                or result.get("generation_contract") != _GENERATION_CONTRACT
                or "quality_score" in result):
            raise RuntimeError("Cached text result lacks genuine model provenance")
        if _out.get("source") in ("cache", "coalesced"):
            result["cached"] = True
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail={
                "error": "MaxCore text generation model failed",
                "reason": f"{type(exc).__name__}: {exc}",
            },
        )
    _sm = _get_storage_mode()
    if _sm != "live":
        result["storage_warning"] = (
            "pdim storage is offline — quality awareness and retrieval index are "
            f"running in {_sm.replace('_', ' ')} mode; output quality may be reduced"
        )
    result["processing_time_ms"] = round((time.time() - start) * 1000, 1)
    return result


@app.post("/api/content/score")
@_planned_generation("content", specification=True)
async def api_content_score(req: ApiContentScoreRequest, _key=Depends(require_scope("generate"))):
    """Score a piece of content 0–100 using the AI model + heuristic blend."""
    local   = _api_heuristic_score(req.text, req.platform)
    augment = _api_heuristic_score(req.text + " " + " ".join(req.hashtags), req.platform)
    blended = round(local * 0.35 + augment * 0.65, 1)
    feedback = None
    model_insight = None
    source = "heuristic"
    _request_awareness = _merged_awareness_for(req)

    if _model_ready and _script_agent:
        try:
            from ai_model.agents.script_agent import ScriptRequest
            sr = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                idea=req.text[:200], platform=normalize_platform(req.platform),
                goal="engagement", tone="authentic",
                awareness=_effective_awareness(
                    normalize_platform(req.platform), _request_awareness),
            )))
            if sr:
                hook_len    = len(sr.hook or "")
                body_len    = len(sr.body or "")
                model_score = min(100.0, 40.0 + hook_len * 0.3 + body_len * 0.2)
                blended     = round(blended * 0.45 + model_score * 0.55, 1)
                model_insight = sr.hook or None
                source = getattr(sr, "source", "model")
        except Exception:
            pass

    if blended < 40:
        feedback = "Content may be too short or lacks a clear CTA."
    elif blended > 80:
        feedback = "Strong content — good hook and engagement signals."
    else:
        feedback = "Solid content — consider sharpening the opening hook."

    return {
        "score":         blended,
        "feedback":      feedback,
        "model_insight": model_insight,
        "source":        source,
    }


# -- Analysis ------------------------------------------------------------------

@app.post("/api/analyze")
@_planned_generation("content", specification=True)
async def api_analyze(req: ApiAnalyzeRequest, _key=Depends(require_scope("generate"))):
    """Classify and normalise multimodal input before generation."""
    start = time.time()
    first_platform = req.platforms[0] if req.platforms else "general"

    content_hint = (
        f"Content from URL: {req.payload}" if req.modality == "url"
        else f"{req.modality.capitalize()} asset: {req.payload}" if req.modality in ("image", "audio", "video")
        else str(req.payload)
    )
    intent_hint = req.intent or "general content promotion"
    _request_awareness = _merged_awareness_for(req)

    normalised: dict = {
        "modality":         req.modality,
        "payload_summary":  content_hint,
        "intent":           intent_hint,
        "platforms":        req.platforms,
        "artistProfileId":  req.artistProfileId,
        "metadata":         req.metadata or {},
        "platform_rules":   req.platformRules or {},
        "semantic":         {"topic": content_hint, "intent": intent_hint, "platforms": req.platforms, "style_tags": []},
        "source":           "template",
        "processing_time_ms": 0,
    }

    if _model_ready and _script_agent:
        try:
            from ai_model.agents.script_agent import ScriptRequest
            result = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                idea=content_hint, platform=normalize_platform(first_platform),
                goal=intent_hint, tone="authentic",
                awareness=_effective_awareness(
                    normalize_platform(first_platform), _request_awareness),
            )))
            normalised["semantic"]["hook"]         = result.hook
            normalised["semantic"]["core_message"] = result.body
            normalised["source"] = getattr(result, "source", "model")
        except Exception:
            pass

    normalised["processing_time_ms"] = round((time.time() - start) * 1000, 1)
    return normalised


@app.post("/api/analyze/sentiment")
@_planned_generation("content", specification=True)
async def api_analyze_sentiment(req: ApiSentimentRequest, _key=Depends(require_scope("generate"))):
    """Sentiment, emotions, and toxicity on any text — AI model augmented."""
    text      = req.text.lower()
    pos_words = {"love", "great", "amazing", "fire", "lit", "yes", "good", "best", "happy", "excited",
                 "banger", "heat", "fresh", "iconic", "vibe", "waves", "blessed", "winning"}
    neg_words = {"hate", "bad", "awful", "terrible", "sad", "angry", "worst", "no", "fail",
                 "trash", "weak", "broke", "flop", "dead", "cancel", "boring"}
    words     = set(text.split())
    pos, neg  = len(words & pos_words), len(words & neg_words)

    if pos > neg:
        sentiment, label, confidence = 0.6 + pos * 0.05, "positive", min(0.95, 0.65 + pos * 0.05)
    elif neg > pos:
        sentiment, label, confidence = -(0.6 + neg * 0.05), "negative", min(0.95, 0.65 + neg * 0.05)
    else:
        sentiment, label, confidence = 0.0, "neutral", 0.55

    model_summary = None
    source = "heuristic"
    _request_awareness = _merged_awareness_for(req)

    if _model_ready and _script_agent:
        try:
            from ai_model.agents.script_agent import ScriptRequest
            sr = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                idea=req.text[:180], platform="general",
                goal="sentiment_analysis", tone="authentic",
                awareness=_effective_awareness("general", _request_awareness),
            )))
            if sr:
                model_summary = sr.hook
                generated = ((sr.hook or "") + " " + (sr.body or "")).lower()
                model_pos = sum(1 for w in pos_words if w in generated)
                model_neg = sum(1 for w in neg_words if w in generated)
                if model_pos > model_neg:
                    sentiment  = min(1.0,  sentiment + 0.15)
                    confidence = min(0.97, confidence + 0.08)
                    label = "positive" if sentiment >= 0 else label
                elif model_neg > model_pos:
                    sentiment  = max(-1.0, sentiment - 0.15)
                    confidence = min(0.97, confidence + 0.08)
                    label = "negative" if sentiment < 0 else label
                source = getattr(sr, "source", "model")
        except Exception:
            pass

    result: dict = {
        "sentiment":     round(sentiment, 3),
        "label":         label,
        "confidence":    round(confidence, 3),
        "model_summary": model_summary,
        "source":        source,
    }
    if req.includeEmotions:
        result["emotions"] = {
            "joy":      round(max(0.0, sentiment) * 0.8,  3),
            "sadness":  round(max(0.0, -sentiment) * 0.7, 3),
            "anger":    round(max(0.0, -sentiment) * 0.3, 3),
            "surprise": round(abs(sentiment) * 0.2 + 0.05, 3),
        }
    if req.includeToxicity:
        toxic = {"hate", "kill", "stupid", "idiot", "trash", "slur", "violent"}
        result["toxicity"] = round(min(1.0, len(words & toxic) * 0.3), 3)
    return result


@app.post("/api/audio/upload")
async def api_audio_upload(request: Request, _key=Depends(require_scope("generate"))):
    """Store one authenticated raw audio body for owner-scoped MaxCore use."""
    owner_id = (request.headers.get("x-maxcore-user-id") or "").strip()
    if not owner_id:
        raise HTTPException(status_code=401, detail="Authenticated MaxCore user identity is required")
    content_type = (request.headers.get("content-type") or "").split(";", 1)[0].lower()
    extension = _AUDIO_UPLOAD_TYPES.get(content_type)
    if not extension:
        raise HTTPException(status_code=415, detail="Content-Type must be a supported audio type")
    declared = request.headers.get("content-length")
    if declared:
        try:
            if int(declared) > _AUDIO_UPLOAD_MAX_BYTES:
                raise HTTPException(status_code=413, detail="Audio upload exceeds size limit")
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid Content-Length")

    owner_dir = _audio_upload_owner_dir(owner_id)
    owner_dir.mkdir(parents=True, exist_ok=True)
    asset_id = uuid.uuid4().hex
    final_path = owner_dir / f"{asset_id}{extension}"
    temp_path = owner_dir / f".{asset_id}.part"
    received = 0
    try:
        with temp_path.open("xb") as output:
            async for chunk in request.stream():
                received += len(chunk)
                if received > _AUDIO_UPLOAD_MAX_BYTES:
                    raise HTTPException(status_code=413, detail="Audio upload exceeds size limit")
                output.write(chunk)
        if received == 0:
            raise HTTPException(status_code=422, detail="Audio upload is empty")
        try:
            import librosa
            waveform, sample_rate = await _in_thread(
                lambda: librosa.load(str(temp_path), sr=None, mono=True, duration=1.0)
            )
            if sample_rate <= 0 or getattr(waveform, "size", 0) == 0:
                raise ValueError("decoder returned no audio samples")
        except Exception as exc:
            raise HTTPException(
                status_code=422,
                detail=f"Uploaded body is not decodable audio: {type(exc).__name__}",
            )
        temp_path.replace(final_path)
    except Exception:
        temp_path.unlink(missing_ok=True)
        final_path.unlink(missing_ok=True)
        raise
    relative = final_path.relative_to(_UPLOADS_PATH).as_posix()
    return {"url": f"/uploads/{relative}"}


async def _analyze_audio_reference(reference: Optional[str], request: Request) -> dict:
    """Decode a contained MaxCore media file and run the real conductor."""
    if not reference:
        raise HTTPException(status_code=422, detail="audio_url or audio_path is required")
    parsed = urlparse(str(reference))
    if parsed.scheme or parsed.netloc:
        raise HTTPException(status_code=422, detail="Remote and file URLs are not accepted; upload audio first")
    raw_path = parsed.path if parsed.scheme else str(reference)
    marker = "/uploads/"
    if marker in raw_path:
        relative = raw_path.split(marker, 1)[1]
    elif raw_path.startswith("uploads/"):
        relative = raw_path[len("uploads/"):]
    else:
        raise HTTPException(
            status_code=422,
            detail="Audio reference must identify a MaxCore /uploads/ asset",
        )
    root = _UPLOADS_PATH.resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise HTTPException(status_code=404, detail="Audio asset not found")
    owner_id = (request.headers.get("x-maxcore-user-id") or "").strip()
    expected_owner_dir = _audio_upload_owner_dir(owner_id).resolve() if owner_id else None
    audio_inputs = (root / "audio-inputs").resolve()
    if path.is_relative_to(audio_inputs):
        if expected_owner_dir is None or not path.is_relative_to(expected_owner_dir):
            raise HTTPException(status_code=403, detail="Cannot access another user's audio upload")
    try:
        import librosa
        from ai_model.audio.audio_analysis import analyze_audio
        waveform, sample_rate = await _in_thread(
            lambda: librosa.load(str(path), sr=None, mono=False, duration=300.0)
        )
        timeline = await _in_thread(
            lambda: analyze_audio(waveform, sample_rate, max_seconds=300.0)
        )
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"MaxCore audio analysis failed: {type(exc).__name__}: {exc}",
        )
    if not timeline.analysis_ok:
        raise HTTPException(
            status_code=503,
            detail=f"MaxCore audio analysis unavailable: {timeline.notes}",
        )
    result = timeline.to_dict()
    result.update({
        "duration": result["duration_sec"],
        "tempo": result["bpm"],
        "musical_key": f"{result['key']} {result['mode']}",
        "energy_curve": result["energy_envelope"],
        "source": "maxcore_audio_conductor",
    })
    return result


def _resolve_owner_audio_upload(reference: str, request: Request) -> str:
    """Resolve only this caller's opaque audio-input URL to a contained file."""
    parsed = urlparse(str(reference))
    if parsed.scheme or parsed.netloc:
        raise HTTPException(status_code=422, detail="Remote and file URLs are not accepted; upload audio first")
    raw_path = parsed.path if parsed.scheme else str(reference)
    if not raw_path.startswith("/uploads/audio-inputs/"):
        raise HTTPException(status_code=422, detail="user_audio_path must be returned by /api/audio/upload")
    relative = raw_path[len("/uploads/"):]
    root = _UPLOADS_PATH.resolve()
    path = (root / relative).resolve()
    owner_id = (request.headers.get("x-maxcore-user-id") or "").strip()
    if not owner_id or not path.is_relative_to(_audio_upload_owner_dir(owner_id).resolve()):
        raise HTTPException(status_code=403, detail="Cannot access another user's audio upload")
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Audio upload not found")
    return str(path)


@app.post("/api/analyze/audio")
async def api_analyze_audio(req: ApiAnalyzeAudioRequest, request: Request, _key=Depends(require_scope("generate"))):
    """Run MaxCore's real waveform conductor over a MaxCore-hosted audio file."""
    return await _analyze_audio_reference(req.audio_url, request)


# -- Advertising & Engagement --------------------------------------------------

@app.post("/api/optimize/ad")
@_planned_generation("content", specification=True)
async def api_optimize_ad(req: ApiOptimizeAdRequest, _key=Depends(require_scope("generate"))):
    """Campaign scoring, budget allocation, creative prediction, ROI forecasting — AI model powered."""
    import numpy as _np
    result: dict = {"action": req.action, "confidence": 0.78, "source": "heuristic"}
    _request_awareness = _merged_awareness_for(req)

    if req.action == "score":
        c     = req.campaign or {}
        score = _api_heuristic_score(str(c.get("name", "campaign")), c.get("platform", "instagram"))
        model_hook = None
        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                plat = normalize_platform(c.get("platform", "instagram"))
                sr   = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=str(c.get("name", "ad campaign")),
                    platform=plat, goal=c.get("objective", "conversions"), tone="direct",
                    awareness=_effective_awareness(plat, _request_awareness),
                )))
                if sr:
                    model_score = min(100.0, 40.0 + len(sr.hook or "") * 0.35 + len(sr.body or "") * 0.2)
                    score       = round(score * 0.40 + model_score * 0.60, 1)
                    model_hook  = sr.hook
                    result["source"] = getattr(sr, "source", "model")
            except Exception:
                pass
        result["score"]      = score
        result["model_hook"] = model_hook

    elif req.action == "optimize_budget":
        campaigns = req.campaigns or []
        total     = req.totalBudget or 1000.0
        _n        = max(1, len(campaigns))
        # Score each campaign via model, allocate proportionally
        scores: list[float] = []
        for c in campaigns:
            s = _api_heuristic_score(str(c.get("name", "campaign")), c.get("platform", "instagram"))
            if _model_ready and _script_agent:
                try:
                    from ai_model.agents.script_agent import ScriptRequest
                    sr = await _in_thread(lambda _c=c: _script_agent.run(ScriptRequest(
                        idea=str(_c.get("name", "campaign")),
                        platform=normalize_platform(_c.get("platform", "instagram")),
                        goal=_c.get("objective", "conversions"), tone="direct",
                        awareness=_effective_awareness(
                            normalize_platform(_c.get("platform", "instagram")),
                            _request_awareness),
                    )))
                    if sr:
                        s = round(s * 0.4 + min(100.0, 40 + len(sr.hook or "") * 0.35) * 0.6, 1)
                        result["source"] = getattr(sr, "source", "model")
                except Exception:
                    pass
            scores.append(max(1.0, s))
        total_score = sum(scores)
        result["allocations"] = [
            {"campaign": c.get("name", f"campaign_{i}"), "budget": round(total * (scores[i] / total_score), 2), "model_score": round(scores[i], 1)}
            for i, c in enumerate(campaigns)
        ]

    elif req.action == "predict_creative":
        content = str(req.campaign or req.campaigns or "")
        base_ctr = round(float(_np.random.uniform(0.02, 0.12)), 4)
        model_suggestion = None
        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                sr = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=content[:150] or "ad creative",
                    platform="instagram", goal="conversions", tone="direct",
                    awareness=_effective_awareness("instagram", _request_awareness),
                )))
                if sr:
                    hook_quality     = min(1.0, len(sr.hook or "") / 80)
                    base_ctr         = round(0.02 + hook_quality * 0.10, 4)
                    model_suggestion = sr.hook
                    result["source"] = getattr(sr, "source", "model")
            except Exception:
                pass
        result["predictedCTR"]       = base_ctr
        result["model_hook_preview"] = model_suggestion

    elif req.action == "forecast_roi":
        base_roi = round(float(_np.random.uniform(1.2, 4.5)), 3)
        model_rationale = None
        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                context = str(req.campaign or "campaign")
                sr = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=f"ROI forecast for: {context[:100]}",
                    platform="general", goal="revenue", tone="professional",
                    awareness=_effective_awareness("general", _request_awareness),
                )))
                if sr:
                    hook_quality    = min(1.0, len(sr.hook or "") / 80)
                    base_roi        = round(1.2 + hook_quality * 3.3, 3)
                    model_rationale = sr.body
                    result["source"] = getattr(sr, "source", "model")
            except Exception:
                pass
        result["expectedROI"]    = base_roi
        result["forecastDays"]   = req.forecastPeriod or 30
        result["model_rationale"] = model_rationale

    return result


@app.post("/api/predict/engagement")
@_planned_generation("content", specification=True)
async def api_predict_engagement(req: ApiPredictEngagementRequest, _key=Depends(require_scope("generate"))):
    """Best post times, viral scoring, schedule optimisation — AI model powered."""
    raise HTTPException(
        status_code=503,
        detail={
            "error": "MaxCore engagement reasoning unavailable",
            "required_capability": "trained engagement prediction model",
            "action": req.action,
        },
    )

    # Historical implementation retained below for compatibility archaeology;
    # it is intentionally unreachable because it mixes templates, fixed times,
    # text-length scoring, and random rates rather than engagement inference.
    import numpy as _np
    platform   = req.platform.lower()
    _request_awareness = _merged_awareness_for(req)
    best_times = {"instagram": "18:00", "tiktok": "19:00", "twitter": "12:00", "youtube": "15:00", "facebook": "13:00", "spotify": "10:00"}
    result: dict = {"action": req.action, "platform": platform, "confidence": 0.72, "source": "heuristic"}

    if req.action == "best_time":
        best_time = best_times.get(platform, "17:00")
        model_rationale = None
        if _model_ready and _distribution_agent:
            try:
                from ai_model.agents.distribution_agent import DistributionRequest
                dr = await _in_thread(lambda: _distribution_agent.run(DistributionRequest(
                    script=str(req.content or f"content on {platform}"),
                    platform=normalize_platform(platform), goal="engagement",
                    awareness=_effective_awareness(
                        normalize_platform(platform), _request_awareness),
                )))
                raw_time = getattr(dr, "posting_time", "") or ""
                # posting_time is like "T18:00:00Z" — extract HH:MM
                if "T" in raw_time and ":" in raw_time:
                    best_time = raw_time.split("T")[-1][:5]
                result["source"] = "ai_model"
                model_rationale  = f"Model-optimised posting window for {platform}"
            except Exception:
                pass
        result["bestTime"]       = best_time
        result["model_rationale"] = model_rationale

    elif req.action == "recommend_type":
        content_type = "short_video" if platform in ("tiktok", "instagram") else "image_post"
        model_reasoning = None
        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                sr = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=str(req.content or f"best content format for {platform}"),
                    platform=normalize_platform(platform), goal="engagement", tone="authentic",
                    awareness=_effective_awareness(
                        normalize_platform(platform), _request_awareness),
                )))
                if sr:
                    model_reasoning  = sr.hook
                    result["source"] = getattr(sr, "source", "model")
            except Exception:
                pass
        result["contentType"]    = content_type
        result["model_reasoning"] = model_reasoning

    elif req.action == "viral_potential":
        base_score  = _api_heuristic_score(str(req.content), platform) / 100 * 0.9
        viral_score = round(base_score, 3)
        model_analysis = None
        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                content_text = str(req.content or "")[:200]
                sr = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=content_text, platform=normalize_platform(platform),
                    goal="viral", tone="energetic",
                    awareness=_effective_awareness(
                        normalize_platform(platform), _request_awareness),
                )))
                if sr:
                    hook_power      = min(1.0, len(sr.hook or "") / 80)
                    viral_score     = round(base_score * 0.40 + hook_power * 0.60, 3)
                    model_analysis  = sr.hook
                    result["source"] = getattr(sr, "source", "model")
            except Exception:
                pass
        result["viralScore"]    = viral_score
        result["model_analysis"] = model_analysis

    elif req.action == "optimize_schedule":
        days   = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        ppw    = req.postsPerWeek or 4
        chosen = days[:ppw]
        base_time = best_times.get(platform, "17:00")
        if _model_ready and _distribution_agent:
            try:
                from ai_model.agents.distribution_agent import DistributionRequest
                dr = await _in_thread(lambda: _distribution_agent.run(DistributionRequest(
                    script=str(req.content or f"{platform} posting schedule"),
                    platform=normalize_platform(platform), goal="engagement",
                    awareness=_effective_awareness(
                        normalize_platform(platform), _request_awareness),
                )))
                raw_time = getattr(dr, "posting_time", "") or ""
                if "T" in raw_time and ":" in raw_time:
                    base_time = raw_time.split("T")[-1][:5]
                result["source"] = "ai_model"
            except Exception:
                pass
        result["schedule"] = [{"day": d, "time": base_time} for d in chosen]

    elif req.action == "predict_engagement":
        base_rate = round(float(_np.random.uniform(0.02, 0.18)), 4)
        model_projection = None
        if _model_ready and _script_agent:
            try:
                from ai_model.agents.script_agent import ScriptRequest
                sr = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                    idea=str(req.content or "post")[:150],
                    platform=normalize_platform(platform), goal="engagement", tone="authentic",
                    awareness=_effective_awareness(
                        normalize_platform(platform), _request_awareness),
                )))
                if sr:
                    hook_quality     = min(1.0, len(sr.hook or "") / 80)
                    base_rate        = round(0.02 + hook_quality * 0.16, 4)
                    model_projection = sr.hook
                    result["source"] = getattr(sr, "source", "model")
            except Exception:
                pass
        result["engagementRate"]   = base_rate
        result["model_projection"] = model_projection

    return result


# -- Media Generation ----------------------------------------------------------

@app.post("/api/generate/image")
@_planned_generation("image", dedicated_media=True)
async def api_generate_image(req: ApiGenerateImageRequest, _key=Depends(require_scope("generate"))):
    """
    Generate platform-sized images rendered in-house via PIL.
    Uses VisualSpecAgent (custom transformer) for concept + style,
    then renders gradient + typography PNGs per slot.
    """
    import time as _t
    start = _t.time()

    step        = req.step or {}
    intent      = req.intent or "promotional"
    constraints = req.constraints or {}
    style_tags  = constraints.get("styleTags") or step.get("params", {}).get("styleTags", ["cinematic"])
    if isinstance(style_tags, str):
        style_tags = [style_tags]
    # Explicit caller intent (constraints/step params, or style/video_style
    # below) must always win over the awareness buffer's own style-tag
    # suggestion further down — never silently override what was actually
    # requested.
    _explicit_style_tags = bool(
        constraints.get("styleTags") or step.get("params", {}).get("styleTags")
        or req.style or req.video_style
    )
    # MaxBooster single-frame requests pass style/video_style directly
    for _extra_style in (req.style, req.video_style):
        if _extra_style and _extra_style not in style_tags:
            style_tags = [_extra_style] + list(style_tags)

    # Resolve slots — accept as top-level field or nested inside step
    raw_slots = req.slots
    if not raw_slots and step:
        raw_slots = step.get("params", {}).get("slots", [])
    if not raw_slots:
        # Build a single default slot from whatever we have
        raw_slots = [{"id": "default", "platform": "instagram", "purpose": intent}]
    if isinstance(raw_slots, dict):
        raw_slots = [raw_slots]

    # Extract topic from inputs (same pattern as /generate/content)
    # Universal URL Parser: resolve any URL/platform link to a readable topic
    inputs   = req.inputs or {}
    normalized = inputs.get("normalized", {}) if isinstance(inputs, dict) else {}
    topic = _resolve_topic_from_url(
        req.prompt
        or (normalized.get("semantic") or {}).get("topic")
        or normalized.get("payload_summary")
        or step.get("params", {}).get("topic")
        or intent
    )
    artist_name = req.artistProfileId or "MaxBooster"

    # ── Request intelligence: analyse intent/audience & visual strategy ────
    # A brief is built PER SLOT (not once globally) so that when a caller
    # requests multiple slots on different platforms, each gets its own
    # platform-adapted aspect ratio / hook style / tempo in one call — the
    # cross-platform generation producers ask for, mirroring what video
    # already does per-platform via PLATFORM_RATIOS.
    from ai_model import request_intelligence as ri
    # Awareness bridge (identical to content route, personalised by this
    # request's own direction fields) → drives the VisualSpecAgent's layout /
    # colour / prompt, which the PIL render then consumes.
    _img_awareness = _merged_awareness_for(req)

    outputs = []
    brief = None  # last-built brief, surfaced at top level for back-compat
    for slot in raw_slots:
        if isinstance(slot, str):
            slot = {"id": slot, "platform": slot}
        platform  = slot.get("platform", "instagram")
        _slot_awareness = _effective_awareness(
            normalize_platform(platform), _img_awareness)
        slot_id   = slot.get("id", "default")
        purpose   = slot.get("purpose", intent)

        brief = ri.build_brief(
            modality="image", platform=normalize_platform(platform or "instagram"),
            topic=str(topic), goal=intent,
            tone=style_tags[0] if style_tags else None,
            genre=req.genre,
            extra=" ".join(str(s) for s in style_tags),
            mood=req.mood, bpm=req.bpm, key=req.key,
            artist_profile_id=req.artistProfileId,
        )

        # Unified conditioning bus: real-asset-grounded visual technique drives
        # the default colour scheme + RTA mood (VisualSpecAgent may still
        # override). Never-raise.
        try:
            from ai_model.generation import extract_technique as _extract_tech
            _tech = _extract_tech(
                idea=str(topic), genre=req.genre,
                tone=(style_tags[0] if style_tags else None),
                mood=req.mood, bpm=req.bpm, key=req.key, brand=artist_name,
                seed=abs(hash((slot_id, str(topic)))) % (2**31),
            )
        except Exception:
            _tech = None

        # ── Determine layout and color scheme via VisualSpecAgent ─────────────
        layout       = brief.layout
        color_scheme = _tech.color_scheme() if _tech else "dark_neon"
        # Slot-local copy — each slot/platform gets its own derived tags, so
        # one slot's producer-metadata tags never bleed into the next slot's
        # render (the shared `style_tags` list from constraints/step is the
        # base; only this slot's working copy is extended below).
        slot_style_tags = list(style_tags)
        prompt       = f"Eye-catching {slot_style_tags[0] if slot_style_tags else 'cinematic'} visual for: {topic}"
        # Producer-metadata steering: genre/mood/BPM shift the style tags used
        # to render, so the same topic looks different for a 90-BPM ballad
        # vs. a 140-BPM drop instead of always defaulting to "cinematic".
        for _mtag in ri.visual_style_from_brief(brief):
            if _mtag not in slot_style_tags:
                slot_style_tags.append(_mtag)

        # Bridge the same industry-peak signal that already reaches video's
        # transition/camera-motion choices into the image renderer's own
        # style tags — self-retiring as the video/image corpus grows (see
        # quality_awareness.editing_pattern). Never-raise.
        if not _explicit_style_tags:
            try:
                from ai_model.quality_awareness import editing_pattern as _editing_pattern
                _img_pattern = _editing_pattern(
                    f"{topic}|{req.genre}|{slot_id}", modality="image",
                )
                if _img_pattern and _img_pattern.get("style_tag") \
                        and _img_pattern["style_tag"] not in slot_style_tags:
                    slot_style_tags.append(_img_pattern["style_tag"])
                    _srv_logger.info(
                        "[Awareness] image slot=%s applied buffer style_tag=%s "
                        "(genre=%s weight=%.2f)", slot_id,
                        _img_pattern["style_tag"], _img_pattern.get("source_genre"),
                        _img_pattern.get("weight", 0.0),
                    )
            except Exception:  # noqa: BLE001 - awareness buffer must never break image generation
                pass

        if _visual_spec_agent:
            try:
                from ai_model.agents.visual_spec_agent import VisualSpecRequest
                # `idea` is templated raw into the thumbnail prompt and drawn
                # on-canvas as the headline — it must stay a clean topic
                # string. The richer intent/audience/theme context from
                # `brief.augmented_idea` is routed through `awareness`
                # instead, not concatenated into `idea` where it would
                # corrupt the visible headline text (mirrors the video path).
                vis = await _in_thread(lambda: _visual_spec_agent.run(VisualSpecRequest(
                    idea=str(topic),
                    platform=normalize_platform(platform),
                    tone=slot_style_tags[0] if slot_style_tags else brief.tone,
                    awareness=_slot_awareness,
                )))
                layout       = vis.layout or layout
                color_scheme = vis.color_scheme or color_scheme
                if vis.thumbnail_prompt and len(vis.thumbnail_prompt) > 8:
                    prompt = vis.thumbnail_prompt
            except Exception:
                pass

        # Enrich the render prompt with intent-derived focus keywords.
        if brief.keywords:
            prompt = f"{prompt}. Focus: {', '.join(brief.keywords[:4])}"

        # ── Quality-buffer headline ranking (mirrors best_hook for text and
        # the scene sampler's tier-1 blend for video) — the agent's own topic
        # string competes against borrowed-knowledge candidates; a winning
        # buffer pick graduates into image generation's own corpus. ─────────
        headline_text = str(topic)
        try:
            headline_text, _hl_score, _hl_n = ri.best_image_headline(
                str(topic), artist_name, str(topic), brief,
            )
        except Exception:
            pass

        # ── RTA-1 IRC path-traced background (opt-in, fail explicitly) ───────
        _rta_bg = None
        _engine_choice = (req.render_engine or os.environ.get("RTA_IMAGE_ENGINE") or "").lower()
        if _engine_choice in ("pathtraced", "rta", "raytraced", "path-traced"):
            try:
                from ai_model import rta as _rta
                from ai_model.image.image_engine import PLATFORM_DIMS
                _pw, _ph = PLATFORM_DIMS.get(layout, (1080, 1080))
                _base = 384
                if _pw >= _ph:
                    _bw, _bh = _base, max(64, int(round(_base * _ph / _pw)))
                else:
                    _bh, _bw = _base, max(64, int(round(_base * _pw / _ph)))
                _seed = _rta.image.scene_builder.stable_seed(str(topic), platform, color_scheme)
                _mood = _tech.mood() if _tech else (slot_style_tags[0] if slot_style_tags else "cinematic")
                # NEE (direct light sampling) in the path tracer cuts variance
                # hard, so 6 spp now reads cleaner than the old 20-spp brute force
                # at a fraction of the render time.
                _rta_bg = await _in_thread(lambda: _rta.api.render_image(
                    color_scheme=color_scheme, mood=_mood,
                    width=_bw, height=_bh, samples=6, max_bounces=3, seed=_seed,
                    prompt=str(topic),
                ))
            except Exception as _rta_err:
                raise HTTPException(
                    status_code=422 if isinstance(_rta_err, ValueError) else 503,
                    detail=f"Pathtraced image could not represent/render requested subject: {_rta_err}",
                ) from _rta_err

        # ── Render via PIL ImageEngine ─────────────────────────────────────────
        result = None
        if _image_engine:
            try:
                from ai_model.image.image_engine import ImageRequest
                _req = ImageRequest(
                    prompt=prompt,
                    headline=headline_text,
                    color_scheme=color_scheme,
                    layout=layout,
                    platform=platform,
                    artist_name=artist_name,
                    intent=purpose,
                    style_tags=slot_style_tags,
                    background=_rta_bg,
                    suppress_text=(req.render_text is False),
                )
                result = await _in_thread(lambda r=_req: _image_engine.render(r))
            except Exception as _img_err:
                if _engine_choice in ("pathtraced", "rta", "raytraced", "path-traced"):
                    raise HTTPException(status_code=503,
                                        detail=f"Pathtraced image composition failed: {_img_err}") from _img_err
                print(f"[ImageEngine] render error: {_img_err}")

        if _engine_choice in ("pathtraced", "rta", "raytraced", "path-traced") and not (result and result.success):
            raise HTTPException(status_code=503, detail="Pathtraced image produced no rendered file")

        if result and result.success:
            # Fold this produced image back into the retrieval index (non-blocking,
            # deduped, bounded; TOTAL — never raises into the generation path).
            try:
                from ai_model.retrieval.generated_ingestor import get_generated_ingestor
                from ai_model.image.image_engine import _UPLOADS_DIR as _IMG_DIR
                get_generated_ingestor().enqueue(
                    str(_IMG_DIR / result.filename),
                    brand=artist_name,
                    endpoint="/api/generate/image",
                    platform=platform,
                )
            except Exception:
                pass
            outputs.append({
                "type":    "image",
                "url":     result.url,
                "width":   result.width,
                "height":  result.height,
                "format":  "png",
                "slot":    slot_id,
                "platform": platform,
                "intent":  purpose,
                "meta": {
                    "color_scheme": result.color_scheme,
                    "layout":       result.layout,
                    "prompt_used":  result.prompt_used,
                    "style_tags":   slot_style_tags,
                    "engine":       ("rta-irc-pathtraced-v1" if _rta_bg is not None
                                     else "maxbooster-pil-v1"),
                    "render_scope": ("pathtraced_supported_geometry" if _rta_bg is not None
                                     else "procedural_typography_poster"),
                    "ai_disclosure": brief.ai_disclosure,
                    "technique":    _tech.to_dict() if _tech else None,
                },
            })
        else:
            # Fallback: return spec without a rendered file so callers can
            # still use the layout/color_scheme guidance even if PIL fails
            from ai_model.image.image_engine import PLATFORM_DIMS
            w, h = PLATFORM_DIMS.get(layout, (1080, 1080))
            outputs.append({
                "type":    "image",
                "url":     None,
                "width":   w,
                "height":  h,
                "format":  "png",
                "slot":    slot_id,
                "platform": platform,
                "intent":  purpose,
                "meta": {
                    "color_scheme": color_scheme,
                    "layout":       layout,
                    "prompt_used":  prompt,
                    "style_tags":   slot_style_tags,
                    "engine":       "maxbooster-pil-v1",
                    "status":       "engine_not_ready",
                    "ai_disclosure": brief.ai_disclosure,
                    "technique":    _tech.to_dict() if _tech else None,
                },
            })

    # Top-level aliases the MaxBooster client reads (url / image_url / path)
    first_url = next((o.get("url") for o in outputs if o.get("url")), None)
    return {
        "outputs": outputs,
        "url":       first_url,
        "image_url": first_url,
        "path":      first_url,
        "intelligence": brief.to_dict(),
        "ai_disclosure": brief.ai_disclosure if brief else False,
        "processing_time_ms": round((_t.time() - start) * 1000, 1),
    }


def _render_audio_clip(job_id: str, bpm: float, key: str,
                       duration_sec: float, sample_rate: int = 44100,
                       genre: str = "", mood: str = "",
                       prompt: str = "", instrument: str = "") -> str:
    _generation_plan_hash()
    """Synthesize a musical audio clip — 100% on the Digital GPU stack.

    All waveform math routes through the self-contained Digital GPU engine
    (NativeKernels compiled SIMD C + HyperGPU GEMM).  Zero calls to scipy,
    librosa, or soundfile — the system is fully independent of Replit's base
    environment for synthesis.

    Caller genre, mood, instrument and prompt take precedence over optional
    live-awareness genres/moods; the latter are only defaults.

    Returns the served relative URL.  Raises on encode failure so the job
    reports an explicit error instead of claiming success with a missing file.
    """
    from ai_model.audio.digital_gpu_synth import render_audio_clip as _dg_render
    from ai_model.audio.digital_gpu_synth import write_wav as _dg_write_wav
    from ai_model.video.ffmpeg_util import run_ffmpeg

    # The Digital GPU synth accepts genre/mood conditioning, not a separate
    # prompt kwarg. Include the actual instrument and creative brief in its
    # mood channel so piano/soft-drum routing sees the request, not a label
    # inferred solely from genre or a trending signal.
    synth_direction = " ".join(
        part for part in (mood, instrument, prompt) if part
    ).strip()
    stereo_f32 = _dg_render(
        job_id=job_id,
        bpm=float(bpm),
        key=(key or "C major"),
        duration_sec=float(duration_sec),
        genre=(genre or ""),
        mood=synth_direction,
        sample_rate=int(sample_rate),
    )

    n_total  = int(duration_sec * sample_rate)
    wav_path = _UPLOADS_PATH / f"audio_{job_id}.wav"
    mp3_path = _UPLOADS_PATH / f"audio_{job_id}.mp3"
    _dg_write_wav(wav_path, stereo_f32, sample_rate=int(sample_rate))

    try:
        result = run_ffmpeg(
            ["ffmpeg", "-y", "-i", str(wav_path),
             "-codec:a", "libmp3lame", "-b:a", "320k", str(mp3_path)],
            # 120s: encode takes <1s warm but CPU contention from concurrent
            # video renders can stretch it; keep fail-explicit, never silent.
            timeout=120,
        )
        if result.returncode != 0 or not mp3_path.exists():
            raise RuntimeError(
                f"ffmpeg mp3 encode failed (rc={result.returncode}): {result.stderr[-300:]}"
            )
    finally:
        try:
            wav_path.unlink(missing_ok=True)
        except OSError:
            pass
    return f"/uploads/audio_{job_id}.mp3"


def _extract_awareness_genres(awareness: str) -> list:
    """Parse trending genre names out of the awareness context string.

    ContentAwarenessService (music mode) writes lines of the form:
        Trending genres: trap, phonk, afrobeats
    This extracts them as a lowercase list so audio track selection can prefer
    samples whose genre metadata overlaps with live chart signals.
    Never raises — returns an empty list on any parse failure.
    """
    import re as _re
    try:
        m = _re.search(r"[Tt]rending genres?:\s*([^\n]+)", awareness or "")
        if not m:
            return []
        return [g.strip().lower() for g in m.group(1).split(",") if g.strip()]
    except Exception:
        return []


def _extract_awareness_moods(awareness: str) -> list:
    """Parse trending mood tokens out of the awareness context string.

    ContentAwarenessService (music mode) writes:
        Trending moods: melancholic, euphoric, nostalgic
    Returns lowercase list. Never raises.
    """
    import re as _re
    try:
        m = _re.search(r"[Tt]rending moods?:\s*([^\n]+)", awareness or "")
        if not m:
            return []
        return [g.strip().lower() for g in m.group(1).split(",") if g.strip()]
    except Exception:
        return []


def _render_audio_from_dataset(job_id: str, bpm: float, key: str,
                               duration_sec: float,
                               opts: Optional[dict] = None) -> dict:
    _generation_plan_hash()
    """Render selected dataset audio bytes or synthesize when bytes are absent.

    Awareness conditions track selection and synthesis; it is not the waveform
    source when dataset bytes are selected. Dataset BPM/key are source metadata,
    not measurements of the finished audio.

    Producer controls applied to every render regardless of dataset state:

    * **Loop / trim** to the requested duration with musical fades.
    * **Arrangement** — structured intro/verse/hook/outro conditioned by the
      caller's genre/mood before live-awareness defaults; plain loop otherwise.
    * **ARC spectral cleanup** (opt-in via env).
    * **Master & export** — optional EBU-R128 loudness target, WAV/MP3 at a
      chosen sample-rate / bit-depth.
    * **Stems** — optional drums/bass/melody split for remixing.

    Returns source metadata, requested targets and completed assets separately.
    """
    from storage_client import get_storage
    from ai_model.video.ffmpeg_util import run_ffmpeg
    from ai_model.audio import producer_tools as _pt

    opts = opts or {}

    # ── Producer targets ───────────────────────────────────────────────────────
    _explicit_bpm = float(opts.get("target_bpm") or bpm or 0.0)
    target_key = str(opts.get("target_key") or key or "C major")

    # ── Awareness signals (primary generation inputs) ──────────────────────────
    _preferred_genres = [
        g.lower().strip()
        for g in (opts.get("preferred_genres") or [])
        if g and str(g).strip()
    ]
    _preferred_mood = str(opts.get("preferred_mood") or "").strip()
    if not _preferred_mood:
        _intent_text = str(opts.get("intent") or "").lower()
        _preferred_mood = next(
            (word for word in ("calm", "mellow", "quiet", "dark",
                               "energetic", "cinematic", "chill", "uplifting")
             if word in _intent_text), "")
    _synth_genre = _preferred_genres[0] if _preferred_genres else (
        str(opts.get("genre") or "").lower().strip()
    )
    # A genre-matched pool file has no guarantee of the requested instrument,
    # mood, tempo or key. Never serve unrelated bytes as a custom composition.
    _requires_custom_render = bool(
        opts.get("prompt") or opts.get("instrument") or opts.get("explicit_mood")
        or opts.get("explicit_targets")
    ) and opts.get("reference_sample_idx") is None

    # No explicit BPM → take the MEASURED chart target for this genre from the
    # live industry beacon (Deezer per-genre charts, previews analyzed with the
    # in-house beat tracker). 120 stays only as the final fallback when the
    # beacon has no measured features yet. Never raises.
    target_bpm = _explicit_bpm
    if not target_bpm:
        try:
            from ai_model.quality_awareness import music_targets as _mt
            _chart = _mt(_synth_genre)
            if _chart.get("bpm"):
                target_bpm = float(_chart["bpm"])
                print(
                    f"[audio_chart] chart BPM target {target_bpm} "
                    f"(genre={_chart.get('source_genre')!r}, "
                    f"{_chart.get('measured_previews')} previews measured) "
                    f"job={job_id[:8]}",
                    flush=True,
                )
        except Exception:  # noqa: BLE001
            pass
    if not target_bpm:
        target_bpm = 120.0

    # ── Layer 2: Dataset pool lookup (ms — SQLite GET + selector) ────────────
    # The L1 cache key is derived from the CHUNK actually selected, not from
    # the requested BPM/key (which varies per-request even for the same genre).
    # This means the pre-warmer's cached files are reused by all real requests
    # that select the same chunk, regardless of their requested key/tempo.
    _dur_bucket = round(float(duration_sec or 30.0) / 5) * 5
    _ref_sample: "dict | None" = None
    _src_from_pool = False
    _l1_key: "tuple | None" = None
    src_path = _UPLOADS_PATH / f"audio_src_{job_id}.mp3"
    applied_bpm = float(target_bpm)
    applied_key = str(target_key or "C major")
    try:
        storage = get_storage()
        meta = storage.get("mb:dataset:audio:meta")

        # Brief seeder wait only when dataset is empty and seeder just started.
        if not _requires_custom_render and not (meta and int(meta.get("num_chunks", 0)) > 0):
            from workers.seed_audio_dataset import is_seeding as _is_seeding_render
            _wait_deadline = time.time() + 2.0
            while _is_seeding_render() and time.time() < _wait_deadline:
                time.sleep(0.5)
                meta = storage.get("mb:dataset:audio:meta")
                if meta and int(meta.get("num_chunks", 0)) > 0:
                    break

        if not _requires_custom_render and meta and int(meta.get("num_chunks", 0)) > 0:
            index = meta.get("index") or [
                {"idx": i} for i in range(int(meta["num_chunks"]))
            ]
            from ai_model.audio.track_selector import select_audio_sample as _select
            if opts.get("reference_sample_idx") is not None:
                _best = next(
                    (entry for entry in index
                     if int(entry["idx"]) == int(opts["reference_sample_idx"])),
                    None,
                )
                if _best is None:
                    raise ValueError("Requested dataset reference sample not found")
            else:
                _best, _key_matched = _select(
                    index,
                    str(target_key or "").strip().lower(),
                    float(target_bpm or 0.0),
                    _preferred_genres,
                    _preferred_mood,
                )
            _ref_sample = _best

            # ── Layer 1: In-process file cache (0 ms) ─────────────────────
            # Never reuse a cached response with different requested targets.
            _fmt_l1  = str(opts.get("format") or "mp3").lower()
            _l1_key  = (
                _generation_plan_hash(),
                int(_best["idx"]), float(duration_sec), _fmt_l1,
                float(target_bpm), str(target_key).lower(),
                tuple(_preferred_genres), _preferred_mood,
                opts.get("loudness_lufs"), bool(opts.get("stems")),
            )
            with _AUDIO_RENDER_CACHE_LOCK:
                _l1_hit = _AUDIO_RENDER_CACHE.get(_l1_key)
            if _l1_hit is not None:
                _cached_name = str(_l1_hit.get("url") or "").rsplit("/", 1)[-1]
                if _cached_name and (_UPLOADS_PATH / _cached_name).exists():
                    print(
                        f"[audio_pool] L1 cache hit chunk={_best['idx']} "
                        f"dur={_dur_bucket}s job={job_id[:8]}",
                        flush=True,
                    )
                    return _l1_hit

            # Fetch actual audio bytes — this is the L2 pool serve path.
            chunk = storage.get(f"mb:dataset:audio:chunk:{_best['idx']}")
            if chunk and chunk.get("b64"):
                import base64 as _b64_pool
                _raw = _b64_pool.b64decode(chunk["b64"])
                if _raw:
                    _pool_genres = chunk.get("genres") or []
                    _pool_bpm    = float(chunk.get("bpm") or target_bpm)
                    _pool_key    = str(chunk.get("key") or target_key or "C major")
                    _pool_source = str(chunk.get("source") or "")

                    # Flywheel assets also go through the duration/format/master
                    # pipeline; direct reuse can return the wrong requested clip.
                    src_path.write_bytes(_raw)
                    _src_from_pool = True
                    if not _synth_genre and _pool_genres:
                        _synth_genre = str(_pool_genres[0]).lower()
                    applied_bpm = _pool_bpm
                    applied_key = _pool_key
                    print(
                        f"[audio_pool] L2 pool serve: idx={_best['idx']} "
                        f"bpm={applied_bpm} key={applied_key!r} "
                        f"genres={_pool_genres} job={job_id[:8]}",
                        flush=True,
                    )
            else:
                if opts.get("reference_sample_idx") is not None:
                    raise ValueError("Requested dataset reference has no audio bytes")
                # Chunk index entry exists but bytes missing — use metadata only.
                _ref_genres = _best.get("genres") or []
                if not _synth_genre and _ref_genres:
                    _synth_genre = str(_ref_genres[0]).lower()
                if not target_bpm and float(_best.get("bpm") or 0.0) > 0:
                    target_bpm = float(_best.get("bpm"))
                    applied_bpm = target_bpm
    except Exception as _pool_err:
        if opts.get("reference_sample_idx") is not None:
            raise RuntimeError(f"Dataset reference unavailable: {_pool_err}") from _pool_err
        print(f"[audio_pool] pool serve skipped: {_pool_err}", flush=True)

    # ── Layer 3: Synthesis fallback (only when pool empty / bytes missing) ─────
    if not _src_from_pool:
        print(
            f"[audio_awareness_synth] synthesizing from live awareness signals: "
            f"genre={_synth_genre!r} mood={_preferred_mood!r} "
            f"bpm={target_bpm} key={target_key!r} job={job_id[:8]}",
            flush=True,
        )
        _synth_duration = max(4.0, min(float(duration_sec or 30.0), 180.0))
        _render_audio_clip(
            f"src_{job_id}", target_bpm, target_key,
            duration_sec=_synth_duration,
            genre=_synth_genre,
            mood=_preferred_mood,
            prompt=str(opts.get("prompt") or ""),
            instrument=str(opts.get("instrument") or ""),
        )
    src_wav = _UPLOADS_PATH / f"audio_srcwav_{job_id}.wav"
    looped_wav = _UPLOADS_PATH / f"audio_loop_{job_id}.wav"

    # Export target format (default MP3 for quick sharing; WAV for the studio).
    fmt = (opts.get("format") or "mp3").lower()
    if fmt not in ("mp3", "wav"):
        fmt = "mp3"
    sample_rate = int(opts.get("sample_rate") or 44100)
    bit_depth = int(opts.get("bit_depth") or 24)
    loudness_lufs = opts.get("loudness_lufs")
    if loudness_lufs is not None:
        loudness_lufs = float(loudness_lufs)
    out_ext = "wav" if fmt == "wav" else "mp3"
    out_path = _UPLOADS_PATH / f"audio_{job_id}.{out_ext}"

    # applied_bpm / applied_key already set by the pool or synthesis block above.
    _tmp = [src_path, src_wav, looped_wav]
    try:
        # 1) Decode synthesized source → stereo WAV.
        r0 = run_ffmpeg(["ffmpeg", "-y", "-i", str(src_path), "-ac", "2",
                         "-ar", str(sample_rate), str(src_wav)], timeout=60)
        if r0.returncode != 0 or not src_wav.exists():
            raise RuntimeError(
                f"source decode failed rc={r0.returncode}: "
                f"{(r0.stderr or '')[-300:]}"
            )

        stage_in = src_wav

        # 2) Assemble to the requested duration. Awareness-driven ARRANGEMENT
        #    first (structured intro/verse/hook/outro conditioned by live-
        #    industry trending genres); plain loop as the never-raise fallback.
        arrangement_plan = None
        arranged_wav = _UPLOADS_PATH / f"audio_arr_{job_id}.wav"
        _tmp.append(arranged_wav)
        _want_arrange = (opts.get("arrange") is not False
                         and float(duration_sec) >= 24.0)
        if _want_arrange:
            try:
                from ai_model.audio import arrangement as _arr
                _plan = _arr.build_plan(
                    float(duration_sec), float(applied_bpm or 120),
                    genre=(opts.get("genre") or _synth_genre or None),
                    mood=(_preferred_mood or None),
                    trending_genres=_preferred_genres or [],
                    seed=opts.get("seed"),
                )
                if _arr.realize(stage_in, arranged_wav, _plan,
                                sample_rate=sample_rate,
                                run_ffmpeg=run_ffmpeg,
                                uploads_dir=_UPLOADS_PATH,
                                job_tag=job_id[:8]):
                    arrangement_plan = _arr.plan_summary(_plan)
                    print(f"[Arrange] audio_{job_id}: "
                          f"{'→'.join(s['section'] for s in arrangement_plan)}",
                          flush=True)
            except Exception as _arr_err:
                print(f"[Arrange] skipped (plain loop): {_arr_err}", flush=True)

        fade_len = min(1.5, max(0.3, float(duration_sec) * 0.05))
        fade_out_start = max(0.0, float(duration_sec) - fade_len)
        _fade_af = (f"afade=t=in:st=0:d=0.05,"
                    f"afade=t=out:st={fade_out_start:.2f}:d={fade_len:.2f}")
        if arrangement_plan:
            r1 = run_ffmpeg(
                ["ffmpeg", "-y", "-i", str(arranged_wav),
                 "-t", f"{float(duration_sec):.2f}", "-af", _fade_af,
                 str(looped_wav)],
                timeout=max(90, int(float(duration_sec) * 1.2) + 30),
            )
            if r1.returncode != 0 or not looped_wav.exists():
                arrangement_plan = None
        if not arrangement_plan:
            r1 = run_ffmpeg(
                ["ffmpeg", "-y", "-stream_loop", "-1", "-i", str(stage_in),
                 "-t", f"{float(duration_sec):.2f}", "-af", _fade_af,
                 str(looped_wav)],
                timeout=max(90, int(float(duration_sec) * 1.2) + 30),
            )
            if r1.returncode != 0 or not looped_wav.exists():
                raise RuntimeError(
                    f"ffmpeg assemble failed (rc={r1.returncode}): "
                    f"{r1.stderr[-300:]}"
                )

        # 3) RTA-1 ARC spectral restoration (opt-in, env-gated) ───────────────
        if os.environ.get("RTA_AUDIO_SPECTRAL") == "1":
            try:
                _arc_spectral_clean_file(looped_wav)
                print(f"[RTA] ARC spectral clean applied to audio_{job_id}",
                      flush=True)
            except Exception as _arc_err:
                print(f"[RTA] ARC spectral clean skipped: {_arc_err}",
                      flush=True)

        # 4) Optional stems (drums / bass / melody) BEFORE mastering.
        stem_urls: dict = {}
        if opts.get("stems"):
            try:
                stems = _pt.separate_stems(
                    looped_wav, _UPLOADS_PATH, f"audio_{job_id}",
                    bit_depth=bit_depth)
                stem_urls = {name: f"/uploads/{p.name}"
                             for name, p in stems.items()}
                print(f"[Producer] stems for audio_{job_id}: "
                      f"{', '.join(stem_urls)}", flush=True)
            except Exception as _st_err:
                print(f"[Producer] stems skipped: {_st_err}", flush=True)

        # 5) Master (optional LUFS) + export to the requested format.
        try:
            _pt.master_export(looped_wav, out_path, fmt=fmt,
                              sample_rate=sample_rate, bit_depth=bit_depth,
                              loudness_lufs=loudness_lufs)
        except Exception as _mx_err:
            print(f"[Producer] master_export failed — plain encode fallback: "
                  f"{_mx_err}", flush=True)
            loudness_lufs = None
            codec = (["-codec:a", "pcm_s24le"] if fmt == "wav"
                     else ["-codec:a", "libmp3lame", "-b:a", "320k"])
            r2 = run_ffmpeg(["ffmpeg", "-y", "-i", str(looped_wav),
                             "-ac", "2", "-ar", str(sample_rate), *codec,
                             str(out_path)],
                            timeout=90)
            if r2.returncode != 0 or not out_path.exists():
                raise RuntimeError(
                    f"final encode failed rc={r2.returncode}: "
                    f"{(r2.stderr or '')[-300:]}"
                )
    finally:
        for _p in _tmp:
            try:
                _p.unlink(missing_ok=True)
            except OSError:
                pass

    _result = {
        "url": f"/uploads/{out_path.name}",
        "bpm": applied_bpm,
        "key": applied_key,
        "format": fmt,
        "sample_rate": sample_rate,
        "bit_depth": bit_depth if fmt == "wav" else None,
        # A mastering target is not a measured integrated loudness value.
        "loudness_lufs": None,
        "requested_bpm": float(target_bpm),
        "requested_key": target_key,
        "requested_loudness_lufs": opts.get("loudness_lufs"),
        "loudness_target_applied": loudness_lufs is not None,
        "measured_bpm": None,
        "measured_key": None,
        "measured_loudness_lufs": None,
        "waveform_source": "dataset_chunk_bytes" if _src_from_pool else "digital_gpu_synthesis",
        "stems": stem_urls,
        "arrangement": arrangement_plan,
        # Provenance: pool serve (bytes from dataset) or synthesis.
        "source_sample": (
            {"idx": _ref_sample.get("idx"), "bpm": _ref_sample.get("bpm"),
             "key": _ref_sample.get("key"),
             "dataset_source": _pool_source if _src_from_pool else None,
             "role": "pool" if _src_from_pool else "metadata_reference"}
            if _ref_sample else None
        ),
        "selection_warning": (
            f"Selected dataset audio metadata ({applied_bpm} BPM, {applied_key}) "
            f"differs from requested ({target_bpm} BPM, {target_key}); "
            "tempo/key were not transformed or measured"
            if _src_from_pool and (
                abs(applied_bpm - float(target_bpm)) > 0.5
                or applied_key.lower() != target_key.lower())
            else None
        ),
    }
    # ── Write to L1 in-process cache ─────────────────────────────────────────
    # For synthesis fallback (no pool chunk selected), key by genre+params so
    # the rendered file is reused for subsequent identical synthesis requests.
    if _l1_key is None:
        _bpm_bucket_fb = round(float(applied_bpm) / 5) * 5
        _l1_key = (
            _generation_plan_hash(),
            "synth", str(_synth_genre or ""), _bpm_bucket_fb,
            str(applied_key or "").lower(), float(duration_sec),
            str(fmt).lower(), loudness_lufs, bool(opts.get("stems")),
            str(opts.get("prompt") or ""), str(opts.get("instrument") or ""),
            _preferred_mood, float(applied_bpm),
        )
    with _AUDIO_RENDER_CACHE_LOCK:
        _AUDIO_RENDER_CACHE[_l1_key] = _result
        if len(_AUDIO_RENDER_CACHE) > 256:
            _AUDIO_RENDER_CACHE.pop(next(iter(_AUDIO_RENDER_CACHE)))
    return _result


def _summarize_audio_analysis(render: dict) -> Optional[dict]:
    """Compact, MEASURED sonic facts for a finished audio render. Never raises.

    Surfaced on the audio-job poll response so downstream content generation
    (``beat_context.audio_analysis``) can write from real sonics instead of
    inventing descriptors. All values are measured from the rendered file —
    no invented instruments: ``detected_instruments`` only appears when stems
    were actually separated.
    """
    try:
        import numpy as _np
        name = str(render.get("url") or "").rsplit("/", 1)[-1]
        if not name:
            return None
        path = _UPLOADS_PATH / name
        if not path.exists():
            return None
        import librosa
        y, sr = librosa.load(str(path), sr=22050, mono=True, duration=60.0)
        if y is None or y.size == 0:
            return None
        rms = float(_np.sqrt(_np.mean(y ** 2)) + 1e-12)
        rms_dbfs = round(20.0 * float(_np.log10(rms)), 1)
        centroid = float(_np.mean(librosa.feature.spectral_centroid(y=y, sr=sr)))
        S = _np.abs(librosa.stft(y, n_fft=2048))
        freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
        low_ratio = float(S[freqs < 150.0].sum() / (S.sum() + 1e-9))
        out: dict = {
            "loudness_db": rms_dbfs,  # compatibility: RMS dBFS, never LUFS
            "rms_dbfs": rms_dbfs,
            # RMS mapped to 0–1; 0.35 RMS ≈ a loud, dense master.
            "energy": round(max(0.0, min(1.0, rms / 0.35)), 2),
            "spectral_brightness": ("dark" if centroid < 1500.0 else
                                    "balanced" if centroid < 3000.0 else
                                    "bright"),
            "bass_weight": ("heavy" if low_ratio > 0.25 else
                            "moderate" if low_ratio > 0.12 else "light"),
        }
        stems = render.get("stems") or {}
        if isinstance(stems, dict) and stems:
            out["detected_instruments"] = sorted(stems.keys())
        return out
    except Exception:
        return None


def _arc_spectral_clean_file(audio_path) -> None:
    """Decode → RTA ARC spectral denoise → re-encode the file in place.

    Format-preserving: a ``.wav`` input is written back as PCM WAV, anything
    else (``.mp3``) is re-encoded with libmp3lame.
    """
    import wave
    import numpy as _np
    from ai_model.video.ffmpeg_util import run_ffmpeg
    from ai_model import rta as _rta

    mp3_path = audio_path
    is_wav = str(audio_path).lower().endswith(".wav")
    wav_in = mp3_path.with_suffix(".arc_in.wav")
    wav_out = mp3_path.with_suffix(".arc_out.wav")
    try:
        # Stereo-preserving: decode to 2ch and denoise each channel
        # independently, so ARC never collapses a stereo master to mono.
        r = run_ffmpeg(["ffmpeg", "-y", "-i", str(mp3_path), "-ac", "2",
                        "-ar", "44100", "-f", "wav", str(wav_in)], timeout=120)
        if r.returncode != 0 or not wav_in.exists():
            raise RuntimeError(f"decode failed rc={r.returncode}")
        with wave.open(str(wav_in), "rb") as wf:
            sr = wf.getframerate()
            n_ch = wf.getnchannels()
            raw = wf.readframes(wf.getnframes())
        samples = _np.frombuffer(raw, dtype="<i2").astype(_np.float32) / 32768.0
        if n_ch > 1:
            interleaved = samples.reshape(-1, n_ch)
            cleaned_ch = [
                _rta.api.spectral_clean_audio(
                    _np.ascontiguousarray(interleaved[:, c]), sr)
                for c in range(n_ch)
            ]
            cleaned = _np.stack(cleaned_ch, axis=1).reshape(-1)
        else:
            cleaned = _rta.api.spectral_clean_audio(samples, sr)
        out16 = _np.clip(cleaned, -1.0, 1.0)
        out16 = (out16 * 32767.0).astype("<i2")
        with wave.open(str(wav_out), "wb") as wf:
            wf.setnchannels(n_ch)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            wf.writeframes(out16.tobytes())
        if is_wav:
            r2 = run_ffmpeg(["ffmpeg", "-y", "-i", str(wav_out), "-codec:a",
                             "pcm_s16le", str(mp3_path)], timeout=120)
        else:
            r2 = run_ffmpeg(["ffmpeg", "-y", "-i", str(wav_out), "-codec:a",
                             "libmp3lame", "-b:a", "320k", str(mp3_path)],
                            timeout=120)
        if r2.returncode != 0:
            raise RuntimeError(f"re-encode failed rc={r2.returncode}")
    finally:
        for _p in (wav_in, wav_out):
            try:
                _p.unlink(missing_ok=True)
            except OSError:
                pass


_GENRE_DEFAULT_BPM: dict[str, float] = {
    "trap": 140.0, "drill": 144.0, "hip_hop": 92.0, "hip-hop": 92.0, "rap": 95.0,
    "rnb": 90.0, "r&b": 90.0, "lofi": 75.0, "lo-fi": 75.0, "pop": 112.0,
    "afrobeats": 105.0, "afrobeat": 105.0, "house": 124.0, "edm": 128.0,
    "techno": 130.0, "indie": 108.0, "rock": 120.0, "jazz": 100.0,
}


def _soundtrack_timeout(duration_sec: float) -> float:
    """Bound a native soundtrack render relative to its requested duration.

    The isolated renderer includes admission to a single shared audio slot,
    worker startup, dataset rendering and artifact promotion. The former 20s
    deadline timed out even a six-second Studio soundtrack under load.
    """
    return max(90.0, min(300.0, float(duration_sec or 10.0) * 10.0))


def _voiceover_track_path(job_id: str, narration_text: str,
                          duration_sec: float,
                          music_path: Optional[str] = None,
                          voice: Optional[str] = None,
                          wpm: Optional[int] = None) -> Optional[str]:
    """Synthesize a spoken narration track (in-house eSpeak NG) and duck any
    music soundtrack under it. Requested narration failure is terminal.
    ``voice``/``wpm`` are normalized downstream."""
    try:
        from ai_model.audio.voiceover import (
            voiceover_track, normalize_voice, normalize_wpm,
        )
        path = voiceover_track(
            text=narration_text,
            out_dir=str(_UPLOADS_PATH),
            job_id=job_id,
            duration_sec=duration_sec,
            music_path=music_path,
            voice=normalize_voice(voice),
            wpm=normalize_wpm(wpm),
        )
        if path and Path(path).is_file():
            print(f"[VideoJob] voiceover narration rendered for {job_id[:12]}", flush=True)
        else:
            raise RuntimeError("Required narration could not be synthesized")
        return path
    except Exception as exc:
        raise RuntimeError(f"Required narration failed: {exc}") from exc


def _narration_script(production, hook: str = "", body: str = "", cta: str = "") -> str:
    """Build the narration text: caller-supplied script parts win, otherwise
    the planned scene texts (in order) form the spoken script."""
    parts = [p.strip() for p in (hook, body, cta) if p and p.strip()]
    if parts:
        return ". ".join(parts)
    try:
        return ". ".join(
            s.text.strip() for s in production.scenes if getattr(s, "text", "").strip()
        )
    except Exception:  # noqa: BLE001
        return ""


def _auto_soundtrack_path(job_id: str, duration_sec: float,
                          bpm: Optional[float] = None,
                          key: Optional[str] = None,
                          genre: str = "", mood: str = "",
                          intent: str = "") -> Optional[str]:
    """Render a genre/BPM-matched soundtrack for a video (native-audio parity).

    Uses the real-audio dataset renderer. Returns a local file path or raises
    when the requested soundtrack cannot be delivered.
    """
    try:
        _bpm = float(bpm or 0.0)
        if _bpm <= 0:
            _bpm = _GENRE_DEFAULT_BPM.get((genre or "").strip().lower(), 120.0)
        from ai_model.isolated_audio import render_isolated
        result = render_isolated(
            {
                "_render_audio_clip": _render_audio_clip,
                "_render_audio_from_dataset": _render_audio_from_dataset,
                "_arc_spectral_clean_file": _arc_spectral_clean_file,
                "_summarize_audio_analysis": _summarize_audio_analysis,
            },
            {"job_id": f"vsnd_{job_id[:12]}", "bpm": _bpm, "key": str(key or ""),
             "duration": max(2.0, float(duration_sec or 10.0)),
             "opts": {"genre": genre, "preferred_genres": [genre] if genre else [],
                      "preferred_mood": mood, "intent": intent}},
            _UPLOADS_PATH,
            deadline=time.monotonic() + _soundtrack_timeout(duration_sec),
            cancelled=lambda: (_job_read(job_id) or {}).get("status") == "cancelled",
        )
        url = str(result.get("url") or "")
        name = url.rsplit("/", 1)[-1]
        path = (_UPLOADS_PATH / name).resolve()
        if name and path.is_relative_to(_UPLOADS_PATH.resolve()) and path.exists():
            return str(path)
    except Exception as exc:
        raise RuntimeError(f"Required soundtrack failed: {exc}") from exc
    raise RuntimeError("Required soundtrack renderer produced no audio file")


@app.post("/api/generate/audio")
@_planned_generation("audio", dedicated_media=True)
async def api_generate_audio(req: ApiGenerateAudioRequest, _key=Depends(require_scope("generate"))):
    """Async audio generation — style-conditioned via AI model for concept, BPM/key, creative direction."""
    _creative_prompt = (req.prompt or req.instruction or "").strip()
    _prompt_raw = _creative_prompt.lower()
    _PROMPT_MOOD_KEYWORDS = (
        "calm", "mellow", "soft", "quiet", "gentle", "relaxed", "laid-back",
        "dark", "cinematic", "drill", "heavy", "aggressive", "hard",
        "melancholic", "sad", "hype", "energetic", "euphoric", "chill",
        "lo-fi", "lofí", "vibrant", "moody", "atmospheric", "epic",
        "intense", "raw", "gritty", "smooth", "emotional", "ethereal",
    )
    _prompt_moods = [
        word for word in _PROMPT_MOOD_KEYWORDS
        if re.search(r"(?<!\w)" + re.escape(word) + r"(?!\w)", _prompt_raw)
    ]
    _caller_mood = (req.mood or "").strip() or (
        _prompt_moods[0] if _prompt_moods else "")
    _soft_direction = _caller_mood.lower() in {
        "calm", "mellow", "soft", "quiet", "gentle", "relaxed", "laid-back",
    }
    _has_explicit_targets = any(
        value is not None for value in (req.target_bpm, req.bpm, req.target_key, req.key)
    )
    if req.reference_sample_idx is not None and (
            _creative_prompt or req.instrument or _caller_mood or _has_explicit_targets):
        raise HTTPException(status_code=422, detail=(
            "A dataset reference cannot guarantee a custom instrument, mood, BPM or key; "
            "omit reference_sample_idx to synthesize the requested audio"))
    # Coalesce: identical concurrent submissions (same genre/intent/bpm/key/duration)
    # share one job rather than spawning 90M separate audio renders.
    _effective_audio_awareness = _effective_awareness(
        "general", _merged_awareness_for(req))
    _adigest = _job_digest({
        "type":       "audio",
        "genre":      req.genre or "",
        "intent":     req.intent or "",
        "prompt":     _creative_prompt,
        "instrument": req.instrument or "",
        "mood":       req.mood or "",
        "bpm":        req.bpm,
        "key":        req.key or "",
        "target_bpm": req.target_bpm,
        "target_key": req.target_key or "",
        "format":     req.format or "mp3",
        "seed":       req.seed,
        "sample_rate": req.sample_rate,
        "bit_depth": req.bit_depth,
        "stems":      req.stems,
        "loudness_lufs": req.loudness_lufs,
        "loudness_preset": req.loudness_preset or "",
        "arrange":    req.arrange,
        "style_fingerprint": req.style_fingerprint,
        "reference_sample_idx": req.reference_sample_idx,
        "duration":   req.duration,
        "awareness":  _effective_audio_awareness,
    })
    with _active_jobs_lock:
        _existing_id = _active_jobs.get(_adigest)
    if _existing_id:
        _ejob = _job_read(_existing_id)
        if _ejob and _ejob.get("status") in ("pending", "running"):
            _job_add_request_owner(_existing_id)
            return {
                "job_id":   _existing_id,
                "status":   "coalesced",
                "poll_url": f"/api/video-job/{_existing_id}",
                "duration": req.duration,
            }

    # ── Early-exit: dataset empty while seeding is in progress ────────────────
    # The startup auto-seed runs in a background thread and takes 30–90 s.
    # If the dataset is still empty AND seeding is in progress, spawning a job
    # that would immediately fail is unhelpful.  Return 503 + Retry-After so
    # clients can display a "warming up" state and retry automatically.
    # (If the dataset is empty and NOT seeding, fall through to normal job
    # creation so the existing explicit error message is preserved for the
    # truly-unseeded case.)
    try:
        from storage_client import get_storage as _gs_early
        from workers.seed_audio_dataset import is_seeding as _is_seeding_early
        _early_meta = _gs_early().get("mb:dataset:audio:meta")
        _dataset_ready_early = _early_meta and int(_early_meta.get("num_chunks", 0)) > 0
        if not _dataset_ready_early and _is_seeding_early():
            from fastapi.responses import JSONResponse as _JR
            return _JR(
                status_code=202,
                headers={"Retry-After": "30"},
                content={
                    "error":              "seeding_in_progress",
                    "seeding_now":        True,
                    "message": (
                        "The audio library is still being built in the background "
                        "(typically 30–90 s on first start). "
                        "Please retry in about 30 seconds."
                    ),
                    "retry_after_seconds": 30,
                },
            )
    except Exception:
        pass  # storage probe failed — proceed to normal job creation

    job_id = str(uuid.uuid4())
    with _active_jobs_lock:
        _active_jobs[_adigest] = job_id
    _job_write(job_id, {
        "status":     "pending",
        "job_type":   "audio",
        "created_at": datetime.utcnow().isoformat() + "Z",
        "url":        None,
        "duration":   req.duration,
        "bpm":        None,
        "key":        None,
        "error":      None,
        "seeding_now": False,
    })

    # ── Request intelligence: analyse intent & sonic strategy up front ─────
    from ai_model import request_intelligence as ri
    genre_hint = req.genre or "music"
    # Compute the FULL merged awareness once (caller-supplied + platform buffer +
    # intent layer) and reuse it everywhere below.  This ensures genre/mood/BPM
    # conditioning draws from the live Deezer chart signals and quality-awareness
    # buffer, not just from the raw caller-supplied field (which is often empty).
    _merged_aw_handler = _effective_audio_awareness
    brief = ri.build_brief(
        modality="audio", platform="general",
        topic=f"{genre_hint} {_creative_prompt or req.intent or req.instrument or 'music clip'}",
        goal=req.intent, tone=_caller_mood or None, genre=req.genre,
        mood=_caller_mood or None,
        bpm=req.target_bpm if req.target_bpm is not None else req.bpm,
        key=req.target_key or req.key,
        awareness=_merged_aw_handler,
    )

    # ── Awareness genre/mood conditioning (computed in handler scope) ──────
    # Parse live trending genres from the same awareness string that was fed to
    # build_brief() above. ContentAwarenessService (music mode) writes lines of
    # the form "Trending genres: trap, phonk, afrobeats". We combine those with
    # req.genre (explicit user intent) so _render_audio_from_dataset prefers
    # tracks that match current chart signals.
    # NOTE: these are captured as closure variables for _process() — do NOT
    # call _merged_awareness_for() again inside the background thread.
    # Use the full merged awareness (not just raw req.awareness) so the platform
    # buffer and live chart signals are always reflected in genre/mood extraction.
    _aw_str_handler = _merged_aw_handler
    _aw_genres_handler = _extract_awareness_genres(_aw_str_handler)
    _aw_moods_handler  = _extract_awareness_moods(_aw_str_handler)
    _req_genre_handler = (req.genre or "").lower().strip()
    _preferred_genres_handler: list = list(dict.fromkeys(
        filter(None,
               ([_req_genre_handler] if _req_genre_handler else [])
               + _aw_genres_handler
        )
    ))

    # Prompt-derived mood: extract creative-brief mood keywords from the raw
    # prompt text so requests like "dark phonk, cinematic, drill energy" surface
    # the right mood even when the live awareness buffer has no mood signals and
    # the caller didn't set req.mood explicitly.  These slot in between the live
    # buffer and brief.tone in the precedence chain so they don't override an
    # intentional caller mood but always win over the generic brief fallback.
    # Mood precedence: explicit req.mood → prompt creative brief keywords →
    # live awareness buffer → brief.mood (generic last resort).
    # Prompt keywords rank above the live buffer because they represent the
    # caller's explicit creative direction ("dark", "cinematic", "drill energy")
    # which must not be overridden by a generic trending mood ("chill", "playful")
    # that reflects broad industry trends rather than this specific brief.
    _preferred_mood_handler = (
        _caller_mood
        or (_aw_moods_handler[0].strip() if _aw_moods_handler else "")
        or (brief.mood or "").strip()
    )
    if _preferred_genres_handler or _preferred_mood_handler:
        print(
            f"[audio_awareness] job={job_id[:8]} "
            f"genres={_preferred_genres_handler} mood={_preferred_mood_handler!r} "
            f"(req_genre={_req_genre_handler!r} trending={_aw_genres_handler})",
            flush=True,
        )

    # Unified conditioning bus: sonic technique (tempo/key/spectral tilt). When
    # TECHNIQUE_REAL_AUDIO=1 these can come from a real held audio sample;
    # otherwise they stay None and the brief-derived tempo band drives BPM.
    try:
        from ai_model.generation import extract_technique as _extract_tech
        _audio_tech = _extract_tech(
            idea=_creative_prompt or genre_hint, genre=req.genre,
            tone=_caller_mood or brief.tone,
            mood=_caller_mood or req.intent, seed=(req.seed or 0), with_audio=True,
        )
    except Exception:
        _audio_tech = None

    # Pre-generate AI concept synchronously before spawning the thread
    audio_concept  = None
    style_hook     = None
    model_source   = "heuristic"

    if _model_ready and _script_agent:
        try:
            from ai_model.agents.script_agent import ScriptRequest

            # ── Concept awareness string — built from audio-specific signals ──
            # _merged_awareness_for() may return thin results for audio requests
            # (no `description` field → intent layer finds nothing).  Instead
            # build the awareness string directly from what we already have:
            # the live awareness buffer, plus the request's genre/mood/key/BPM
            # so _awareness_compose() has real industry signals to work with.
            _concept_aw_parts: list[str] = []
            if _aw_str_handler:
                _concept_aw_parts.append(_aw_str_handler)
            if _preferred_genres_handler:
                _concept_aw_parts.append(
                    f"Trending genres: {', '.join(_preferred_genres_handler)}"
                )
            # Moods: prefer resolved _preferred_mood_handler (which already
            # folds prompt keywords), then extend with all prompt moods for
            # richer _build_awareness_body signal variety.
            _all_concept_moods = list(dict.fromkeys(filter(None, [
                _preferred_mood_handler,
                *_prompt_moods,
            ])))
            if _all_concept_moods:
                _concept_aw_parts.append(
                    f"Trending moods: {', '.join(_all_concept_moods)}"
                )
            _prompt_text = (getattr(req, "prompt", None) or "").strip()
            if _prompt_text:
                # Surface the raw prompt as a HIGH-priority signal so the hook
                # and body reflect the actual creative brief (dark, cinematic…)
                _concept_aw_parts.append(f"[HIGH] {_prompt_text}")
            _concept_awareness = "\n".join(_concept_aw_parts).strip()

            # ── Idea text: include mood, key, BPM so hooks carry energy context ─
            # Use _preferred_mood_handler which now resolves prompt keywords
            # before brief.tone, so "dark" beats "playful" on a dark phonk brief.
            _explicit_mood = (getattr(req, "mood", None) or "").strip()
            _mood_label = (
                _explicit_mood or _preferred_mood_handler or brief.mood or "energetic"
            )
            _key_label  = (getattr(req, "key", None) or getattr(req, "target_key", None) or "").strip()
            _bpm_label  = (getattr(req, "bpm", None) or getattr(req, "target_bpm", None))
            idea_text   = genre_hint
            if _mood_label:
                idea_text = f"{_mood_label} {idea_text}"
            if _key_label and _bpm_label:
                idea_text = f"{idea_text} ({brief.tempo} tempo, {_bpm_label} BPM, {_key_label})"
            elif _bpm_label:
                idea_text = f"{idea_text} ({brief.tempo} tempo, {_bpm_label} BPM)"
            else:
                idea_text = f"{idea_text} ({brief.tempo} tempo)"

            sr = await _in_thread(lambda: _script_agent.run(ScriptRequest(
                idea=idea_text, platform="general",
                goal="creative production", tone=brief.tone,
                awareness=_concept_awareness,
            )))
            if sr:
                audio_concept = sr.body
                style_hook    = sr.hook
                model_source  = getattr(sr, "source", "model")
        except Exception:
            pass

    def _process():
        import time as _t
        import numpy as _np2

        # ── Job-level render deadline ──────────────────────────────────────
        # Guaranteed-completion policy: NO render deadline.  The job is never
        # marked "error" by a timer — the render thread is the sole writer of
        # terminal state, and it retries until it succeeds.  Internal ffmpeg
        # hang-detection (subprocess-level, feeding never-raise retry paths)
        # remains: it is what makes indefinite waiting safe, because a frozen
        # subprocess is detected and re-attempted instead of blocking forever.
        # A heartbeat keeps the job visibly alive for pollers on long renders.
        _req_dur = max(4.0, min(float(req.duration or 30), 180.0))
        _render_started = time.time()
        _hb_stop = threading.Event()

        def _heartbeat() -> None:
            while not _hb_stop.wait(30.0):
                if _hb_stop.is_set():
                    return  # terminal write in progress — never overwrite it
                if (_job_read(job_id) or {}).get("status") in ("cancelled", "error", "done"):
                    return
                _elapsed = time.time() - _render_started
                try:
                    _job_update(job_id, {"status": "rendering",
                                         "elapsed_seconds": round(_elapsed, 1)})
                except Exception:
                    pass  # never raise from heartbeat thread
                print(f"[audio_render] job={job_id[:8]} still rendering "
                      f"({_elapsed:.0f}s)", flush=True)

        _hb_thread = threading.Thread(target=_heartbeat, daemon=True)
        _hb_thread.start()

        fp  = req.style_fingerprint
        # Reproducibility: an explicit seed makes BPM/key derivation (and thus
        # the whole render) deterministic, fixing the classic "great result I
        # can't reproduce" complaint.
        _seed_base = req.seed if req.seed is not None else abs(hash(audio_concept or job_id)) % (2**31)
        # BPM derived from style fingerprint (deterministic if provided, else seeded)
        if fp and len(fp) >= 4:
            bpm = round(float(_np2.mean(fp[:4]) * 100 + 80), 1)
        else:
            # No client style fingerprint → let the awareness/intent-derived
            # tempo band (via brief.tempo) shape the BPM, so the live signal
            # actually influences the rendered sound (the dataset render then
            # selects the sample whose tempo best matches). Seeded jitter keeps
            # per-request variety within the band.
            _bands = {"fast": (126.0, 140.0), "punchy": (118.0, 130.0),
                      "medium": (100.0, 116.0), "steady": (84.0, 98.0),
                      "slow": (76.0, 90.0)}
            _tempo_band = "slow" if _soft_direction else (brief.tempo or "").lower()
            _lo, _hi = _bands.get(_tempo_band, (96.0, 120.0))
            # Live chart beacon: when the market's MEASURED tempo for this
            # genre is known, center the seeded jitter on it (±6 BPM) instead
            # of the generic band, clamped inside the intent band so tempo
            # intent ("slow"/"fast") still leads. Never-raise.
            try:
                from ai_model.quality_awareness import music_targets as _mt_h
                _chart_h = _mt_h(
                    (_preferred_genres_handler[0] if _preferred_genres_handler
                     else (req.genre or ""))
                )
                if _chart_h.get("bpm"):
                    _cb = float(_chart_h["bpm"])
                    _lo = max(_lo, min(_hi - 1.0, _cb - 6.0))
                    _hi = min(_hi, max(_lo + 1.0, _cb + 6.0))
                    print(f"[audio_chart] chart BPM anchor {_cb} → band "
                          f"[{_lo:.1f},{_hi:.1f}] "
                          f"(genre={_chart_h.get('source_genre')!r}) "
                          f"job={job_id[:8]}", flush=True)
            except Exception:  # noqa: BLE001
                pass
            rng = _np2.random.default_rng(_seed_base)
            bpm = round(float(rng.uniform(_lo, _hi)), 1)
        # Key derived from fingerprint tail
        keys_list = ["C major", "A minor", "G major", "E minor", "D major",
                     "F major", "B minor", "D minor", "E major", "G minor"]
        if fp and len(fp) >= 8:
            key = keys_list[int(fp[7] * 10) % len(keys_list)]
        else:
            rng2 = _np2.random.default_rng((_seed_base + 7919) % (2**31))
            key  = keys_list[int(rng2.integers(0, len(keys_list)))]
        # Real-asset sonic technique (opt-in) grounds tempo/key when the caller
        # gave neither a style fingerprint nor an explicit target.
        if _audio_tech is not None and not _soft_direction:
            if not (fp and len(fp) >= 4) and (req.target_bpm is None and req.bpm is None) and _audio_tech.tempo:
                bpm = round(float(_audio_tech.tempo), 1)
            if not (fp and len(fp) >= 8) and (req.target_key is None and req.key is None) and _audio_tech.key:
                key = _audio_tech.key
        # Producer targets override the derived values (exact key/BPM the output
        # must LAND on, via pitch-shift + time-stretch in the render).
        # Accept both target_bpm/target_key (internal) and bpm/key (alias).
        _req_bpm = req.target_bpm or req.bpm
        _req_key = req.target_key or req.key
        target_bpm = float(_req_bpm) if _req_bpm else bpm
        # Clamp to a musically sane range so bad input can't produce misleading
        # metadata or an avoidable ffmpeg failure (retune ratio is clamped too).
        target_bpm = max(40.0, min(300.0, float(target_bpm)))
        target_key = _req_key or key
        # Validate export params against what ffmpeg/PCM actually support; fall
        # back to safe studio defaults rather than failing the whole render.
        _fmt = (req.format or "mp3").lower()
        _fmt = _fmt if _fmt in ("mp3", "wav") else "mp3"
        _srate = int(req.sample_rate) if req.sample_rate else 44100
        if _srate not in (22050, 32000, 44100, 48000, 88200, 96000):
            _srate = 44100
        _bits = int(req.bit_depth) if req.bit_depth else 24
        if _bits not in (16, 24, 32):
            _bits = 24
        # Resolve a LUFS loudness preset name into a numeric target if given.
        from ai_model.audio import producer_tools as _pt_presets
        _lufs = req.loudness_lufs
        if _lufs is None and req.loudness_preset:
            _lufs = _pt_presets.LUFS_PRESETS.get(str(req.loudness_preset).lower())
        if _lufs is not None:
            _lufs = max(-40.0, min(0.0, float(_lufs)))
        # ── Awareness conditioning: use pre-computed closure vars ─────────
        # These were computed in the async handler scope (above _process) from
        # req.awareness + req.genre so that _merged_awareness_for() is never
        # called from inside a background thread (which can hang the event loop).
        _preferred_genres = _preferred_genres_handler
        _preferred_mood   = _preferred_mood_handler
        opts = {
            "target_bpm":       target_bpm,
            "target_key":       target_key,
            "format":           _fmt,
            "sample_rate":      _srate,
            "bit_depth":        _bits,
            "loudness_lufs":    _lufs,
            "stems":            bool(req.stems),
            # Awareness conditioning — passed through to _render_audio_from_dataset
            # so the sample selector can prefer genre-aligned tracks.
            "preferred_genres": _preferred_genres,
            "preferred_mood":   _preferred_mood,
            "explicit_mood":    bool(_caller_mood),
            "explicit_targets": _has_explicit_targets,
            "prompt":           _creative_prompt,
            "instrument":       req.instrument or "",
            "reference_sample_idx": req.reference_sample_idx,
            # Arrangement controls: genre + seed condition the section plan;
            # arrange=False opts out (plain loop).
            "genre":            req.genre,
            "intent":           _creative_prompt or req.intent or "",
            "seed":             req.seed,
            "arrange":          req.arrange,
        }
        # Render an actual in-house clip (key/tempo-conditioned) and serve it;
        # only mark "done" once the file exists on disk.
        # Honor long-form requests: leaseable beats run 2–3 minutes (180 s cap
        # per the delivery contract — a content limit, not a timeout).
        #
        # Retry only transient I/O failures, with a finite total budget.
        duration_sec = max(4.0, min(float(req.duration or 30), 180.0))
        render = None
        from ai_model.media_contract import render_with_budget, RenderCancelled
        from ai_model.isolated_audio import render_isolated
        _render_deadline = time.monotonic() + 120.0
        _render_cancelled = lambda: (_job_read(job_id) or {}).get("status") == "cancelled"
        try:
            render = render_with_budget(
                lambda: render_isolated(
                    {
                        "_render_audio_clip": _render_audio_clip,
                        "_render_audio_from_dataset": _render_audio_from_dataset,
                        "_arc_spectral_clean_file": _arc_spectral_clean_file,
                        "_summarize_audio_analysis": _summarize_audio_analysis,
                    },
                    {"job_id": job_id, "bpm": target_bpm, "key": target_key,
                     "duration": duration_sec, "opts": opts},
                    _UPLOADS_PATH, deadline=_render_deadline,
                    cancelled=_render_cancelled,
                ),
                on_retry=lambda attempt, error: _job_update(job_id, {
                    "status": "rendering", "retry_attempt": attempt,
                    "last_error": error[:200]}),
                cancelled=_render_cancelled,
            )
        except Exception as exc:
            _hb_stop.set()
            _hb_thread.join(timeout=5.0)
            _job_update(job_id, {
                "status": "cancelled" if isinstance(exc, RenderCancelled) else "error",
                "error": f"Audio render failed: {exc}",
            })
            return
        # Terminal-state handoff: stop the heartbeat and JOIN it before the
        # final write so "done" can never be overwritten by a late heartbeat.
        _hb_stop.set()
        _hb_thread.join(timeout=5.0)
        _job_update(job_id, {
            "status":           "done",
            "url":              render["url"],
            # Measured sonic summary for downstream content generation
            # (never-raise; None when analysis was not possible).
            "audio_analysis":   render.get("audio_analysis"),
            "duration":         int(duration_sec),
            "bpm":              render.get("bpm", target_bpm),
            "key":              render.get("key", target_key),
            "format":           render.get("format"),
            "sample_rate":      render.get("sample_rate"),
            "bit_depth":        render.get("bit_depth"),
            "loudness_lufs":    render.get("loudness_lufs"),
            "requested_bpm":    render.get("requested_bpm"),
            "requested_key":    render.get("requested_key"),
            "requested_loudness_lufs": render.get("requested_loudness_lufs"),
            "loudness_target_applied": render.get("loudness_target_applied"),
            "measured_bpm":     render.get("measured_bpm"),
            "measured_key":     render.get("measured_key"),
            "measured_loudness_lufs": render.get("measured_loudness_lufs"),
            "waveform_source":  render.get("waveform_source"),
            "stems":            render.get("stems") or {},
            # Section plan actually rendered (None = plain loop) — the
            # awareness-driven arrangement provenance producers see in poll.
            "arrangement":      render.get("arrangement"),
            "seed":             _seed_base,
            "concept":          audio_concept,
            "style_hook":       style_hook,
            "source":           model_source,
            # Awareness provenance — which live signals shaped track selection
            "awareness_genres": _preferred_genres,
            "awareness_mood":   _preferred_mood or None,
            "awareness_source": "trending+intent" if _aw_genres_handler else (
                                "intent" if _req_genre_handler else "none"),
            # Non-None when no dataset track matched the requested key and the
            # selector fell back to nearest-BPM.  Surfaced to producers via poll.
            "selection_warning": render.get("selection_warning"),
            # Which dataset sample was selected — lets producers audit the pick.
            "source_sample":     render.get("source_sample"),
        })
        # ── Admin content flywheel (audio arm) ─────────────────────────────
        # B-Lawz admin renders are auto-pushed back into the audio dataset
        # pool as additional dataset sources (parity with text/video/image
        # flywheel ingestion).  Never raises; gated + deduped inside.
        _fw_ingest_audio_render(_key, job_id, render, _preferred_genres)

        # ── Persist stems to uploads/stems/{job_id}/ for per-stem downloads ──
        # Copies each stem WAV from the uploads root into a structured directory
        # so /api/audio/{job_id}/stems can serve them by name (drums.wav, etc.)
        _stem_src_urls: dict = render.get("stems") or {}
        if _stem_src_urls:
            try:
                import shutil as _shutil
                _stems_dir = _UPLOADS_PATH / "stems" / job_id
                _stems_dir.mkdir(parents=True, exist_ok=True)
                for _sname, _surl in _stem_src_urls.items():
                    _src_fname = str(_surl).lstrip("/").removeprefix("uploads/")
                    _src_p = _UPLOADS_PATH / _src_fname
                    _dst_p = _stems_dir / f"{_sname}.wav"
                    if _src_p.exists() and not _dst_p.exists():
                        _shutil.copy2(str(_src_p), str(_dst_p))
                print(f"[stems] saved {len(_stem_src_urls)} stems for job={job_id[:8]}", flush=True)
            except Exception as _stem_save_err:
                print(f"[stems] save failed (non-fatal): {_stem_save_err}", flush=True)

    _audio_intelligence = brief.to_dict()
    if _caller_mood:
        _audio_intelligence["producer_metadata"]["mood"] = _caller_mood
    if _soft_direction:
        # Prior-derived energy is not a measurement of the synthesized file.
        _audio_intelligence["producer_metadata"]["energy"] = None
    _job_update(job_id, {"intelligence": _audio_intelligence})
    if _audio_tech is not None and not _soft_direction:
        _job_update(job_id, {"technique": _audio_tech.to_dict()})

    # ── Fast-path: genre-key L1 cache probe (zero I/O, pure dict lookup) ─────
    # Every completed render writes a ("genre", genre, dur_bucket, fmt, lufs, stems)
    # key into _AUDIO_RENDER_CACHE alongside the chunk-indexed key. The pre-warmer
    # populates these during startup. If any matching genre key is in the cache and
    # the file still exists, mark the job done immediately — no thread needed.
    # The first SSE poll (fired at 0 ms by the client) then resolves in < 50 ms.
    try:
        _dur_probe   = round(max(4.0, min(float(req.duration or 30), 180.0)) / 5) * 5
        _fmt_probe   = (req.format or "mp3").lower()
        _lufs_probe  = None   # fast-path only for default loudness
        _stems_probe = bool(req.stems)
        if (_lufs_probe is None and not (
                _creative_prompt or req.instrument or _caller_mood or _has_explicit_targets
                or req.reference_sample_idx is not None)):
            with _AUDIO_RENDER_CACHE_LOCK:
                _fp_hit: "dict | None" = None
                for _fp_g in _preferred_genres_handler:
                    _fp_key = (_generation_plan_hash(), "genre", str(_fp_g).lower(), _dur_probe,
                               _fmt_probe, _lufs_probe, _stems_probe)
                    _fp_candidate = _AUDIO_RENDER_CACHE.get(_fp_key)
                    if _fp_candidate is not None:
                        _fp_hit = _fp_candidate
                        break
            if _fp_hit is not None:
                _fp_name = str(_fp_hit.get("url") or "").rsplit("/", 1)[-1]
                # Stems requests only qualify when the cached entry carries a
                # complete set of stem files that still exist on disk — the
                # genre key already encodes the stems flag, so a stems=True
                # probe can only match a stems=True render.
                _fp_stems_ok = True
                if _stems_probe:
                    _fp_stem_urls = _fp_hit.get("stems") or {}
                    _fp_stems_ok = bool(_fp_stem_urls) and all(
                        (_UPLOADS_PATH / str(_u).rsplit("/", 1)[-1]).exists()
                        for _u in _fp_stem_urls.values()
                    )
                if _fp_name and _fp_stems_ok and (_UPLOADS_PATH / _fp_name).exists():
                    _job_update(job_id, {
                        "status":        "done",
                        "url":           _fp_hit.get("url"),
                        "audio_url":     _fp_hit.get("url"),
                        "bpm":           _fp_hit.get("bpm"),
                        "key":           _fp_hit.get("key"),
                        "format":        _fp_hit.get("format"),
                        "sample_rate":   _fp_hit.get("sample_rate"),
                        "bit_depth":     _fp_hit.get("bit_depth"),
                        "loudness_lufs": _fp_hit.get("loudness_lufs"),
                        "stems":         _fp_hit.get("stems") or {},
                        "arrangement":   _fp_hit.get("arrangement"),
                        "source_sample": _fp_hit.get("source_sample"),
                    })
                    print(
                        f"[audio_pool] fast-path hit genre={_preferred_genres_handler[:1]} "
                        f"dur={_dur_probe}s job={job_id[:8]}",
                        flush=True,
                    )
                    return {
                        "job_id":       job_id,
                        "status":       "done",
                        "intelligence": _audio_intelligence,
                        # Full audio result included inline — callers can use
                        # the URL directly without a follow-up poll.
                        "url":          _fp_hit.get("url"),
                        "audio_url":    _fp_hit.get("url"),
                        "bpm":          _fp_hit.get("bpm"),
                        "key":          _fp_hit.get("key"),
                        "format":       _fp_hit.get("format"),
                        "sample_rate":  _fp_hit.get("sample_rate"),
                        "bit_depth":    _fp_hit.get("bit_depth"),
                        "loudness_lufs": _fp_hit.get("loudness_lufs"),
                        "stems":        _fp_hit.get("stems") or {},
                        "arrangement":  _fp_hit.get("arrangement"),
                        "source_sample": _fp_hit.get("source_sample"),
                    }
    except Exception:
        pass  # never block on fast-path failure

    threading.Thread(target=lambda: _run_gpu_job(job_id, _process),
                     daemon=True, name=f"ApiAudioJob-{job_id}").start()
    return {"job_id": job_id, "status": "processing", "intelligence": _audio_intelligence}


def _start_video_job(req: ApiGenerateVideoRequest, platform: str) -> tuple[str, Any]:
    """
    Kick off a single fully AI-driven async video render job for ``platform``.
    Returns (job_id, intelligence_brief). Planning + rendering happen in a
    background thread. Shared by the single-platform and cross-platform
    (``platforms`` list) paths of /api/generate-video.
    """
    # ── Request intelligence: analyse intent & cinematic strategy up front ─
    from ai_model import request_intelligence as ri
    effective_awareness = _effective_awareness(
        normalize_platform(platform), _merged_awareness_for(req))
    brief = ri.build_brief(
        modality="video", platform=normalize_platform(platform),
        topic=_resolve_topic_from_url(req.topic or req.idea), goal=req.goal, tone=req.tone, genre=req.genre,
        artist=req.artist_name,
        extra=" ".join(filter(None, [req.hook, req.body, req.cta])),
        mood=req.mood, bpm=req.bpm, key=req.key,
        artist_profile_id=req.artistProfileId,
        awareness=effective_awareness,
        # ── Veo-parity controls into the intelligence brief ──────────────
        negative_prompt=req.negative_prompt or "",
        enhance_prompt=req.enhance_prompt if req.enhance_prompt is not None else True,
        lighting=req.lighting or "",
        camera_motion=req.camera_motion or "",
        color_temperature=req.color_temperature or "",
    )

    job_id = str(uuid.uuid4())
    _job_write(job_id, {
        "status":          "pending",
        "created_at":      datetime.utcnow().isoformat() + "Z",
        "platform":        platform,
        "genre_detected":  req.genre or "",
        "tone_used":       req.tone,
        "duration":        req.duration or 0,
        "url":             None,
        "filename":        None,
        "width":           None,
        "height":          None,
        "scenes":          [],
        "scenes_rendered": 0,
        "render_ms":       None,
        "error":           None,
        "intelligence":    brief.to_dict(),
        "ai_disclosure":   brief.ai_disclosure,
    })

    def _plan_and_render():
        import traceback as _tb
        try:
            from ai_model.video.video_agent import VideoAgent, VideoAgentRequest
            from ai_model.video.cinematic_engine import render_cinematic_open
            from ai_model.video.renderer import ASPECT_RATIOS, PLATFORM_RATIOS
            from ai_model.video import ai_scene_builder

            agent     = VideoAgent(_creative_model, _script_agent, _visual_spec_agent)
            # `idea` is templated raw into scene phrases (e.g. "Stream {idea}
            # now") — it must stay a clean topic string. The richer
            # intent/audience/theme context from `brief.augmented_idea` is
            # routed through `awareness` instead (bullet-formatted so the
            # scene sampler's awareness parser picks it up per scene type),
            # not concatenated into `idea` where it would corrupt templates.
            agent_req = VideoAgentRequest(
                idea=req.idea or brief.augmented_idea,
                platform=platform,
                goal=req.goal,
                tone=req.tone or brief.tone,
                genre=req.genre or "",
                artist_name=req.artist_name or "",
                duration=float(req.duration or 0),
                artist_context={"audio_path": req.user_audio_path} if req.user_audio_path else {},
                awareness=effective_awareness,
                # ── Veo-parity controls forwarded into the render pipeline ─
                camera_motion=req.camera_motion or "",
                negative_prompt=req.negative_prompt or "",
                seed=req.seed,
                fps=req.fps or 24,
                motion_intensity=req.motion_intensity,
                enhance_prompt=req.enhance_prompt if req.enhance_prompt is not None else True,
                lighting=req.lighting or "",
                color_temperature=req.color_temperature or "",
                style_reference=req.style_reference or "",
                output_resolution=req.output_resolution or "",
                composition=req.composition or "",
                reference_images=req.reference_images or [],
                first_frame_b64=req.first_frame_b64 or "",
                last_frame_b64=req.last_frame_b64 or "",
            )

            production = agent.plan(agent_req, brief=brief)

            # Apply caller-supplied text overrides before rendering
            if req.scenes_override:
                _override_map = {o.index: o.text for o in req.scenes_override}
                for i, scene in enumerate(production.scenes):
                    if i in _override_map:
                        scene.text = _override_map[i]

            _job_update(job_id, {
                "genre_detected": production.genre_detected,
                "tone_used":      production.tone_used,
                "source":         production.source,
                "duration":       production.total_duration,
                "aspect_ratio":   production.aspect_ratio,
                "scenes":         [{"type": s.scene_type, "text": s.text} for s in production.scenes],
            })

            # Bail if the client cancelled the job while planning was running
            _current = _job_read(job_id)
            if _current and _current.get("status") == "cancelled":
                return

            ratio  = production.aspect_ratio or PLATFORM_RATIOS.get(production.platform, "9:16")
            width, height = ASPECT_RATIOS.get(ratio, (1080, 1920))

            # output_resolution: explicit caller override (720p/1080p/4k).
            # Applied after the platform-derived aspect-ratio dimensions so
            # the caller always gets the resolution they asked for regardless
            # of platform defaults.  Never-raise.
            if req.output_resolution:
                _RES_MAP = {
                    "720p":  (1280, 720),  "720":   (1280, 720),
                    "1080p": (1920, 1080), "1080":  (1920, 1080), "fhd": (1920, 1080),
                    "4k":    (3840, 2160), "2160p": (3840, 2160), "uhd": (3840, 2160),
                }
                _res = _RES_MAP.get(req.output_resolution.lower())
                if _res:
                    width, height = _res

            # Unified conditioning bus: extract real-asset-grounded Visual DNA
            # so the diffusion background pipeline conditions on the technique of
            # peak reference media, not just a genre lookup. Never-raise.
            try:
                from ai_model.generation import extract_technique
                # style_reference (Veo parity): pass as the brand hint so
                # extract_technique can condition the DNA on an explicit reference
                # asset when the caller supplies one.
                _eff_brand = req.style_reference or req.artist_name or None
                _tech = extract_technique(
                    idea=agent_req.idea, genre=production.genre_detected,
                    tone=production.tone_used, energy=getattr(brief, "energy", None),
                    mood=getattr(brief, "mood", None), bpm=getattr(brief, "bpm", None),
                    key=getattr(brief, "key", None), brand=_eff_brand,
                    seed=abs(hash(job_id)) % (2**31),
                )
                _tech_dna = _tech.dna_dict()
            except Exception:
                _tech, _tech_dna = None, None

            # ── Soundtrack: start in background immediately — it only needs
            # `production` (already known) and is independent of scene building.
            # This overlaps soundtrack I/O with extract_technique + build_open_scenes,
            # saving 3–8 s of sequential wait before render can start.
            import concurrent.futures as _cf
            _audio_path = req.user_audio_path
            _soundtrack_future = None
            _snd_pool = None
            if not _audio_path and getattr(req, "generate_audio", True):
                _snd_pool = _cf.ThreadPoolExecutor(max_workers=1,
                                                   thread_name_prefix="Soundtrack")
                from contextvars import copy_context
                _soundtrack_future = _snd_pool.submit(
                    copy_context().run, _auto_soundtrack_path,
                    job_id, production.total_duration,
                    bpm=req.bpm, key=req.key,
                    genre=production.genre_detected or (req.genre or ""),
                    mood=req.mood or production.tone_used or "",
                    intent=req.goal or "",
                )

            scene_configs = agent.build_open_scenes(
                agent_req, production, width, height, technique_dna=_tech_dna)
            if _tech is not None:
                _job_update(job_id, {"technique": _tech.to_dict()})
            dna        = ai_scene_builder.build_dna(agent_req.idea, production.genre_detected, production.tone_used)
            transition = "fadeblack" if dna.darkness > 0.70 else "dissolve" if dna.energy < 0.50 else "fade"

            # Collect soundtrack result (thread was running during scene build).
            if _soundtrack_future is not None:
                try:
                    _audio_path = _soundtrack_future.result(
                        timeout=_soundtrack_timeout(production.total_duration) + 5.0)
                except Exception as _snd_exc:
                    raise RuntimeError(f"Required soundtrack failed: {_snd_exc}") from _snd_exc
                finally:
                    if _snd_pool is not None:
                        # The soundtrack worker shares this render's GPU.
                        # Even on timeout, do not retire it under a live worker.
                        _snd_pool.shutdown(wait=True)

            # Voice-over: synthesize REAL spoken narration (eSpeak NG) from the
            # script and duck the soundtrack under it. Previously this flag was
            # a silent no-op — users got the arpeggio synth ("birdcalls").
            if getattr(req, "voiceover", False):
                _vo_text = _narration_script(
                    production,
                    hook=req.hook or "", body=req.body or "", cta=req.cta or "",
                )
                _vo_path = _voiceover_track_path(
                    job_id, _vo_text, production.total_duration,
                    music_path=_audio_path,
                    voice=getattr(req, "voiceover_voice", None),
                    wpm=getattr(req, "voiceover_wpm", None),
                )
                if _vo_path:
                    _audio_path = _vo_path
                    _job_update(job_id, {"voiceover": True})

            _transition_duration = 0.5 if dna.energy > 0.70 else 0.8
            if req.media_manifest is not None:
                from ai_model.video.media_manifest import apply_manifest
                _audio_path, _receipt = apply_manifest(
                    req.media_manifest, scene_configs, _audio_path,
                    production.total_duration, _UPLOADS_PATH, job_id,
                )
                transition = _receipt["transition"]
                _transition_duration = _receipt["transition_duration"]
                _receipt["image_count"] = len(req.reference_images or [])
                _job_update(job_id, {"resolved_media_manifest": _receipt})

            result = render_cinematic_open(
                scenes=scene_configs,
                width=width,
                height=height,
                total_duration=production.total_duration,
                audio_path=_audio_path,
                transition=transition,
                transition_dur=_transition_duration,
                label=f"ai:{production.genre_detected}:{production.tone_used}",
                genre=production.genre_detected or getattr(req, "genre", "") or "",
            )
            if result.success:
                _job_update(job_id, {
                    "status":          "done",
                    "url":             f"/uploads/videos/{result.filename}",
                    "filename":        result.filename,
                    "width":           result.width,
                    "height":          result.height,
                    "scenes_rendered": result.scenes_rendered,
                    "render_ms":       result.render_time_ms,
                })
            else:
                _job_update(job_id, {
                    "status": "error",
                    "error":  result.error or "Render failed",
                })
        except Exception as exc:
            print(f"[VideoJob] Error for job {job_id}: {_tb.format_exc()}")
            _job_update(job_id, {
                "status": "error",
                "error":  f"{type(exc).__name__}: {exc}",
            })

    threading.Thread(target=lambda: _run_gpu_job(job_id, _plan_and_render),
                     daemon=True, name=f"ApiVideoJob-{job_id}").start()
    return job_id, brief


@app.post("/api/generate/video")
@app.post("/api/generate-video")
@_planned_generation("video", dedicated_media=True)
async def api_generate_video(req: ApiGenerateVideoRequest, request: Request, _key=Depends(require_scope("generate"))):
    """
    Kick off a fully AI-driven async video render job.

    Single-platform (default): returns job_id immediately; unchanged behavior
    when ``platforms`` is omitted.

    Cross-platform: when ``platforms`` is set, kicks off one independent
    render job per platform (each with its own aspect ratio / duration via
    the existing PLATFORM_RATIOS / _PLATFORM_SPECS logic in VideoAgent) and
    returns all job_ids in a single response instead of requiring N calls.
    """
    if len(req.reference_images or []) > 10:
        raise HTTPException(status_code=422, detail="At most ten reference images are supported")
    if req.media_manifest is not None:
        from ai_model.video.media_manifest import validate_manifest
        try:
            validate_manifest(req.media_manifest)
        except (ValueError, TypeError) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
    await _wait_for_model_ready()
    if req.user_audio_path:
        req.user_audio_path = _resolve_owner_audio_upload(req.user_audio_path, request)

    if req.platforms:
        _plats = [normalize_platform(p) for p in req.platforms if p]
        _plats = list(dict.fromkeys(_plats))
        if _plats:
            jobs: dict[str, Any] = {}
            for _plat in _plats:
                _jid, _brief = _start_video_job(req, _plat)
                jobs[_plat] = {"job_id": _jid, "intelligence": _brief.to_dict()}
            first = next(iter(jobs.values()))
            return {
                "job_id": first["job_id"],
                "status": "processing",
                "intelligence": first["intelligence"],
                "platform_jobs": jobs,
            }
        # `platforms` present but contained no usable entries (e.g. [""]) —
        # fall through to the normal single-platform path below.

    # ── Multi-sample generation (Veo parity: up to 4 variants/prompt) ────
    # Each variant is an independent render job with a derived seed so the
    # variants genuinely differ (seed=None would resolve to the same
    # deterministic idea-hash seed for every copy).
    _n_samples = max(1, min(4, int(req.sample_count or 1)))
    if _n_samples > 1:
        _base_seed = req.seed if req.seed is not None else abs(hash(req.idea)) % (2**31)
        _sample_jobs: list[dict[str, Any]] = []
        _first_brief = None
        for _i in range(_n_samples):
            _vreq = req.model_copy(update={
                "seed": (_base_seed + _i * 1013) % (2**31),
                "sample_count": 1,
            })
            _jid, _sbrief = _start_video_job(_vreq, req.platform)
            if _first_brief is None:
                _first_brief = _sbrief
            _sample_jobs.append({
                "job_id": _jid,
                "sample_index": _i,
                "seed": (_base_seed + _i * 1013) % (2**31),
                "poll_url": f"/api/video-job/{_jid}",
            })
        return {
            "job_id": _sample_jobs[0]["job_id"],
            "status": "processing",
            "intelligence": _first_brief.to_dict() if _first_brief else {},
            "sample_jobs": _sample_jobs,
        }

    job_id, brief = _start_video_job(req, req.platform)
    return {"job_id": job_id, "status": "processing", "intelligence": brief.to_dict()}


# ── Veo-parity video extension ─────────────────────────────────────────────────

def _ffmpeg_media_duration(path: str) -> float:
    """Read a media file's duration by parsing ffmpeg's stderr banner.

    Uses run_ffmpeg (posix_spawn-safe) instead of ffprobe+PIPE so it works
    under model memory pressure. Returns 0.0 when unparseable (never-raise).
    """
    try:
        import re as _re
        from ai_model.video.ffmpeg_util import run_ffmpeg
        r = run_ffmpeg(["ffmpeg", "-hide_banner", "-i", str(path)], timeout=30.0)
        m = _re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr or "")
        if m:
            return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    except Exception:
        pass
    return 0.0


@app.post("/api/video/extend")
@_planned_generation("video")
async def api_video_extend(req: ApiVideoExtendRequest, request: Request, _key=Depends(require_scope("generate"))):
    """Extend a previously generated video (Veo-parity scene extension).

    The source video's last frame is extracted and used as the first-frame
    conditioning image for a continuation clip, which is rendered at the
    source's exact dimensions and concatenated on. A single continuous
    soundtrack is then re-rendered across the full extended duration so the
    audio stays coherent instead of stitching two different tracks.
    """
    await _wait_for_model_ready()

    if not (req.idea or "").strip():
        raise HTTPException(status_code=422, detail="'idea' is required — describe what the continuation should show")

    # ── Resolve the source video to a real file under uploads/videos ──────
    videos_dir = (_UPLOADS_PATH / "videos").resolve()
    src_name = req.source.strip()
    src_job = _job_read(src_name) if len(src_name) >= 8 and "/" not in src_name and "." not in src_name else None
    if src_job:
        _require_job_owner(src_job, request)
        if src_job.get("status") != "done" or not src_job.get("filename"):
            raise HTTPException(status_code=409, detail=f"source job {src_name} has no finished video to extend")
        src_name = str(src_job["filename"])
    src_name = src_name.rsplit("/", 1)[-1]
    src_path = (videos_dir / src_name).resolve()
    if not src_path.is_relative_to(videos_dir) or not src_path.exists():
        raise HTTPException(status_code=404, detail=f"source video not found: {req.source}")

    add_dur = max(2.0, min(60.0, float(req.extend_duration or 8.0)))
    effective_awareness = _effective_awareness(
        normalize_platform(req.platform), _merged_awareness_for(req))
    job_id = str(uuid.uuid4())
    _job_write(job_id, {
        "status":        "pending",
        "created_at":    datetime.utcnow().isoformat() + "Z",
        "kind":          "video_extend",
        "extended_from": src_name,
        "added_duration": add_dur,
        "platform":      req.platform,
        "url":           None,
        "filename":      None,
    })

    def _extend_and_render():
        import base64 as _b64
        import traceback as _tb
        try:
            from PIL import Image as _Image
            from ai_model.video.ffmpeg_util import run_ffmpeg
            from ai_model.video.video_agent import VideoAgent, VideoAgentRequest
            from ai_model.video.cinematic_engine import render_cinematic_open
            from ai_model.video import ai_scene_builder

            _job_update(job_id, {"status": "running"})

            # 1) Extract the source's last frame → conditioning image
            frame_png = _UPLOADS_PATH / f"extend_lastframe_{job_id[:8]}.png"
            r = run_ffmpeg([
                "ffmpeg", "-y", "-sseof", "-0.5", "-i", str(src_path),
                "-frames:v", "1", "-update", "1", str(frame_png),
            ], timeout=60.0)
            if r.returncode != 0 or not frame_png.exists():
                # -sseof can fail on very short clips — fall back to last-frame select
                r = run_ffmpeg([
                    "ffmpeg", "-y", "-i", str(src_path),
                    "-vf", "select=eof", "-frames:v", "1", "-update", "1", str(frame_png),
                ], timeout=120.0)
            if r.returncode != 0 or not frame_png.exists():
                raise RuntimeError(f"could not extract last frame (rc={r.returncode})")

            with _Image.open(frame_png) as _img:
                width, height = _img.size
            first_frame_b64 = _b64.b64encode(frame_png.read_bytes()).decode("ascii")

            # 2) Render the continuation clip at the source's exact dimensions.
            # Continuation must be conditioned by the SAME awareness merge as
            # every other generation endpoint — previously this built
            # VideoAgentRequest with no awareness field at all, so a
            # continuation clip lost all brand/trend/platform conditioning
            # the original video had.
            agent = VideoAgent(_creative_model, _script_agent, _visual_spec_agent)
            agent_req = VideoAgentRequest(
                idea=req.idea.strip(),
                platform=req.platform,
                goal=req.goal,
                tone=req.tone,
                genre=req.genre or (src_job or {}).get("genre_detected", "") or "",
                artist_name=req.artist_name or "",
                duration=add_dur,
                camera_motion=req.camera_motion or "",
                negative_prompt=req.negative_prompt or "",
                seed=req.seed,
                lighting=req.lighting or "",
                color_temperature=req.color_temperature or "",
                composition=req.composition or "",
                first_frame_b64=first_frame_b64,
                awareness=effective_awareness,
            )
            production = agent.plan(agent_req)
            production.total_duration = add_dur
            scene_configs = agent.build_open_scenes(agent_req, production, width, height)
            dna = ai_scene_builder.build_dna(agent_req.idea, production.genre_detected, production.tone_used)
            cont = render_cinematic_open(
                scenes=scene_configs, width=width, height=height,
                total_duration=add_dur, audio_path=None,
                transition="fade", transition_dur=0.5,
                label=f"extend:{production.genre_detected}",
            )
            if not cont.success:
                raise RuntimeError(cont.error or "continuation render failed")
            cont_path = videos_dir / cont.filename

            # 3) Concatenate source + continuation (video streams, normalised)
            out_name = f"extended_{job_id[:8]}.mp4"
            out_path = videos_dir / out_name
            norm = f"fps=24,scale={width}:{height},format=yuv420p,setpts=PTS-STARTPTS"
            r = run_ffmpeg([
                "ffmpeg", "-y", "-i", str(src_path), "-i", str(cont_path),
                "-filter_complex",
                f"[0:v]{norm}[v0];[1:v]{norm}[v1];[v0][v1]concat=n=2:v=1:a=0[v]",
                "-map", "[v]", "-c:v", "libx264", "-preset", "veryfast",
                "-crf", "20", "-movflags", "+faststart", str(out_path),
            ], timeout=600.0)
            if r.returncode != 0 or not out_path.exists():
                raise RuntimeError(f"concat failed (rc={r.returncode}): {(r.stderr or '')[-300:]}")

            # 4) One continuous soundtrack across the full extended duration
            final_name = out_name
            if req.generate_audio:
                total_dur = _ffmpeg_media_duration(str(out_path)) or (add_dur + 30.0)
                snd = _auto_soundtrack_path(
                    job_id, total_dur,
                    genre=production.genre_detected or (req.genre or ""),
                    mood=req.mood or production.tone_used or "",
                )
                if snd:
                    muxed = videos_dir / f"extended_{job_id[:8]}_audio.mp4"
                    r = run_ffmpeg([
                        "ffmpeg", "-y", "-i", str(out_path), "-i", snd,
                        "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                        "-c:a", "aac", "-b:a", "192k", "-shortest",
                        "-movflags", "+faststart", str(muxed),
                    ], timeout=300.0)
                    if r.returncode == 0 and muxed.exists():
                        final_name = muxed.name

            try:
                frame_png.unlink(missing_ok=True)
            except Exception:
                pass

            _job_update(job_id, {
                "status":         "done",
                "url":            f"/uploads/videos/{final_name}",
                "filename":       final_name,
                "width":          width,
                "height":         height,
                "genre_detected": production.genre_detected,
                "tone_used":      production.tone_used,
                "scenes":         [{"type": s.scene_type, "text": s.text} for s in production.scenes],
            })
        except Exception as exc:
            print(f"[VideoExtend] Error for job {job_id}: {_tb.format_exc()}")
            _job_update(job_id, {"status": "error", "error": f"{type(exc).__name__}: {exc}"})

    threading.Thread(target=lambda: _run_gpu_job(job_id, _extend_and_render),
                     daemon=True, name=f"VideoExtend-{job_id}").start()
    return {
        "job_id":         job_id,
        "status":         "processing",
        "extended_from":  src_name,
        "added_duration": add_dur,
        "poll_url":       f"/api/video-job/{job_id}",
    }


# ── AI-driven video generation ─────────────────────────────────────────────────

@app.post("/api/video/generate-ai")
@_planned_generation("video", dedicated_media=True)
async def api_video_generate_ai(request: Request, _key=Depends(require_scope("generate"))):
    """
    Generate a video where ALL text content is produced by the trained model.

    The VideoAgent conditions the transformer on platform / goal / tone / genre
    control tokens, generates distinct AI text for every scene (hook, build, body,
    drop, cta, outro), selects the matching cinematic template based on the
    AI-determined genre/tone, and renders the final MP4 via FFmpeg.

    Body fields (all optional except idea):
      idea           – what the video is about
      platform       – tiktok | instagram | youtube | instagram_reels | etc.
      goal           – growth | conversion | engagement | awareness | streams | sales
      tone           – energetic | edgy | chill | professional | promotional | etc.
      genre          – trap | rnb | pop | afrobeats | drill | lofi | indie | etc.
      artist_name    – shown on screen as the creator label
      duration       – desired length in seconds (platform default if omitted)
      artist_context – dict with optional audio_path key
      scenes_override – [{type, text}, ...] user-edited scene texts; skips re-planning
    """
    body = await request.json()

    await _wait_for_model_ready()

    idea         = str(body.get("idea", "")).strip()
    platform     = str(body.get("platform", "tiktok")).strip().lower()
    goal         = str(body.get("goal", "growth")).strip().lower()
    tone         = str(body.get("tone", "energetic")).strip().lower()
    genre        = str(body.get("genre", "")).strip().lower()
    artist_name  = str(body.get("artist_name", "")).strip()
    duration     = float(body.get("duration") or 0)
    artist_ctx   = body.get("artist_context", {}) or {}
    # Optional list of {type, text} dicts the user edited in the UI
    scenes_override_raw: list[dict] = body.get("scenes_override") or []

    if not idea:
        raise HTTPException(status_code=422, detail="'idea' is required")

    # Awareness is part of the generation identity: two callers with the same
    # idea but different creative direction must not receive one another's
    # coalesced video.
    from types import SimpleNamespace
    _video_awareness_req = SimpleNamespace(
        awareness=body.get("awareness", ""),
        description=body.get("description", "") or idea,
        prompt_url=body.get("prompt_url", ""),
        instruction=body.get("instruction", ""),
        extra_context=body.get("extra_context", ""),
        content_themes=body.get("content_themes"),
    )
    _effective_video_awareness = _effective_awareness(
        platform, _merged_awareness_for(_video_awareness_req))

    # Coalesce: identical concurrent video AI gen requests (including the
    # conditioning context) share one plan+render rather than running N copies.
    _vdigest = _job_digest({
        "type":     "video_ai_gen",
        "idea":     idea,
        "platform": platform,
        "goal":     goal,
        "tone":     tone,
        "genre":    genre,
        "awareness": _effective_video_awareness,
    })
    with _active_jobs_lock:
        _vexisting = _active_jobs.get(_vdigest)
    if _vexisting:
        _vj = _job_read(_vexisting)
        if _vj and _vj.get("status") in ("pending", "running"):
            _job_add_request_owner(_vexisting)
            return {
                "job_id":   _vexisting,
                "status":   "coalesced",
                "poll_url": f"/api/video-job/{_vexisting}",
            }

    # ── Request intelligence: analyse intent & cinematic strategy up front ─
    from ai_model import request_intelligence as ri
    brief = ri.build_brief(
        modality="video", platform=normalize_platform(platform),
        topic=idea, goal=goal, tone=tone, genre=genre, artist=artist_name,
        mood=str(body.get("mood") or "") or None,
        bpm=body.get("bpm"), key=str(body.get("key") or "") or None,
        artist_profile_id=str(body.get("artistProfileId") or "") or None,
        awareness=_effective_video_awareness,
    )

    from ai_model.video.video_agent import VideoAgent as _VA, VideoAgentRequest
    from ai_model.video.renderer import ASPECT_RATIOS, PLATFORM_RATIOS
    from ai_model.video import ai_scene_builder

    # `idea` is templated raw into scene phrases — keep it clean and route
    # the richer intent/audience/theme context through `awareness` instead.
    # ── Veo-parity controls (all optional, silently defaulted) ────────────
    _refs_raw = body.get("reference_images") or []
    if not isinstance(_refs_raw, list) or len(_refs_raw) > 10:
        raise HTTPException(status_code=422, detail="reference_images must contain at most ten images")
    _refs = [str(x) for x in _refs_raw if x]
    _seed_raw = body.get("seed")

    req = VideoAgentRequest(
        idea=idea,
        platform=platform,
        goal=goal,
        tone=tone or brief.tone,
        genre=genre,
        artist_name=artist_name,
        duration=duration,
        artist_context=artist_ctx,
        awareness="\n".join(
            p for p in (
                _effective_video_awareness,
                "\n".join(f"• {d}" for d in brief.directives),
            ) if p
        ),
        camera_motion=str(body.get("camera_motion") or ""),
        negative_prompt=str(body.get("negative_prompt") or ""),
        seed=int(_seed_raw) if _seed_raw is not None else None,
        fps=int(body.get("fps") or 24),
        motion_intensity=(float(body["motion_intensity"])
                          if body.get("motion_intensity") is not None else None),
        enhance_prompt=bool(body.get("enhance_prompt", True)),
        lighting=str(body.get("lighting") or ""),
        color_temperature=str(body.get("color_temperature") or ""),
        style_reference=str(body.get("style_reference") or ""),
        composition=str(body.get("composition") or ""),
        reference_images=_refs,
        first_frame_b64=str(body.get("first_frame_b64") or ""),
        last_frame_b64=str(body.get("last_frame_b64") or ""),
        output_resolution=str(body.get("output_resolution") or ""),
    )
    _gen_audio = bool(body.get("generate_audio", True))
    _want_voiceover = bool(body.get("voiceover", False))
    _vo_voice = body.get("voiceover_voice")
    _vo_wpm = body.get("voiceover_wpm")

    # ── Run plan() synchronously so scenes are available in this response ──
    # Only the heavy render step is deferred to a background thread.
    _agent     = _VA(_creative_model, _script_agent, _visual_spec_agent)
    production = await _in_thread(lambda: _agent.plan(req, brief=brief))

    # Apply user-edited scene texts if provided (re-render with edits)
    if scenes_override_raw:
        override_map = {i: s.get("text", "") for i, s in enumerate(scenes_override_raw) if isinstance(s, dict)}
        for i, scene in enumerate(production.scenes):
            if i in override_map and override_map[i]:
                scene.text = override_map[i]

    ratio  = production.aspect_ratio or PLATFORM_RATIOS.get(production.platform, "9:16")
    width, height = ASPECT_RATIOS.get(ratio, (1080, 1920))
    scenes_data = [{"type": s.scene_type, "text": s.text} for s in production.scenes]

    job_id = str(uuid.uuid4())
    with _active_jobs_lock:
        _active_jobs[_vdigest] = job_id
    _job_write(job_id, {
        "status":          "pending",
        "created_at":      datetime.utcnow().isoformat() + "Z",
        "platform":        platform,
        "genre_detected":  production.genre_detected,
        "tone_used":       production.tone_used,
        "source":          production.source,
        "duration":        production.total_duration,
        "aspect_ratio":    production.aspect_ratio,
        "template":        production.template_id,
        "url":             None,
        "filename":        None,
        "width":           None,
        "height":          None,
        "scenes":          scenes_data,
        "scenes_rendered": 0,
        "render_ms":       None,
        "error":           None,
        "intelligence":    brief.to_dict(),
    })

    # Capture references for the render closure
    _production = production
    _width, _height = width, height
    _req = req

    def _render_only():
        import traceback as _tb
        try:
            from ai_model.video.cinematic_engine import render_cinematic_open

            _t0 = time.time()
            scene_configs = _agent.build_open_scenes(_req, _production, _width, _height)
            _t_build = time.time() - _t0
            dna        = ai_scene_builder.build_dna(_req.idea, _production.genre_detected, _production.tone_used)
            transition = "fadeblack" if dna.darkness > 0.70 else "dissolve" if dna.energy < 0.50 else "fade"
            # Native-audio parity: auto-soundtrack when no caller audio.
            _t0 = time.time()
            _audio_path = _req.artist_context.get("audio_path")
            if not _audio_path and _gen_audio:
                _audio_path = _auto_soundtrack_path(
                    job_id, _production.total_duration,
                    genre=_production.genre_detected or _req.genre,
                    mood=_production.tone_used or "",
                )
            print(
                f"[VideoRender][Timing] build_scenes={_t_build:.1f}s "
                f"soundtrack={time.time() - _t0:.1f}s job={job_id[:8]}",
                flush=True,
            )

            # Voice-over: real spoken narration from the planned scene texts,
            # music ducked underneath (never-raise; falls back to music).
            if _want_voiceover:
                _vo_path = _voiceover_track_path(
                    job_id, _narration_script(_production),
                    _production.total_duration, music_path=_audio_path,
                    voice=_vo_voice, wpm=_vo_wpm,
                )
                if _vo_path:
                    _audio_path = _vo_path
                    _job_update(job_id, {"voiceover": True})

            result     = render_cinematic_open(
                scenes=scene_configs,
                width=_width,
                height=_height,
                total_duration=_production.total_duration,
                audio_path=_audio_path,
                transition=transition,
                transition_dur=0.5 if dna.energy > 0.70 else 0.8,
                label=f"ai:{_production.genre_detected}:{_production.tone_used}",
                genre=_production.genre_detected or _req.genre,
            )
            if result.success:
                _job_update(job_id, {
                    "status":          "done",
                    "url":             f"/uploads/videos/{result.filename}",
                    "filename":        result.filename,
                    "width":           result.width,
                    "height":          result.height,
                    "scenes_rendered": result.scenes_rendered,
                    "render_ms":       result.render_time_ms,
                })
            else:
                _job_update(job_id, {
                    "status": "error",
                    "error":  result.error,
                })
        except Exception as exc:
            print(f"[VideoAgent] Error for job {job_id}: {_tb.format_exc()}")
            _job_update(job_id, {
                "status": "error",
                "error":  str(exc),
            })

    threading.Thread(target=lambda: _run_gpu_job(job_id, _render_only),
                     daemon=True, name=f"AIVideoJob-{job_id}").start()

    return {
        "job_id":         job_id,
        "status":         "pending",
        "poll_url":       f"/api/video-job/{job_id}",
        "scenes":         scenes_data,
        "genre_detected": production.genre_detected,
        "tone_used":      production.tone_used,
        "source":         production.source,
        "duration":       production.total_duration,
        "aspect_ratio":   production.aspect_ratio,
        "template":       production.template_id,
        "intelligence":   brief.to_dict(),
    }


# -- Job polling ---------------------------------------------------------------

@app.get("/api/video-job/{job_id}")
async def api_poll_video_job(job_id: str, request: Request, _key=Depends(require_scope("read"))):
    """Poll a video render job."""
    job = _job_read(job_id)
    if job is None:
        return {"status": "error", "error": "Job not found"}
    _require_job_owner(job, request)
    if job["status"] == "done":
        return {
            "status":          "done",
            "url":             job.get("url"),
            "filename":        job.get("filename"),
            "width":           job.get("width"),
            "height":          job.get("height"),
            "duration":        job.get("duration"),
            "template":        job.get("template"),
            "template_name":   job.get("template_name"),
            "genre_detected":  job.get("genre_detected"),
            "tone_used":       job.get("tone_used"),
            "source":          job.get("source"),
            "aspect_ratio":    job.get("aspect_ratio"),
            "scenes":          job.get("scenes", []),
            "scenes_rendered": job.get("scenes_rendered", 0),
            "render_ms":       job.get("render_ms"),
            "technique":       job.get("technique"),
            "voiceover":       bool(job.get("voiceover", False)),
            "resolved_media_manifest": job.get("resolved_media_manifest"),
        }
    if job["status"] == "error":
        return {"status": "error", "error": job.get("error", "Unknown error")}
    return {"status": job["status"]}


@app.delete("/api/video-job/{job_id}")
async def api_cancel_video_job(job_id: str, request: Request, _key=Depends(require_scope("generate"))):
    """
    Cancel a pending job (marks it so the render thread exits before encoding)
    or purge a finished/errored job and delete its output file.
    """
    job = _job_read(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    _require_job_owner(job, request)

    status = job.get("status")

    if status == "pending":
        _job_update(job_id, {"status": "cancelled"})
        return {"ok": True, "action": "cancelled", "job_id": job_id}

    if status in ("done", "error", "cancelled"):
        filename = job.get("filename")
        if filename:
            try:
                (_UPLOADS_PATH / "videos" / filename).unlink(missing_ok=True)
            except Exception:
                pass
        try:
            os.unlink(_job_path(job_id))
        except Exception:
            pass
        return {"ok": True, "action": "purged", "job_id": job_id}

    return {"ok": True, "action": "no_op", "job_id": job_id}


@app.get("/api/concurrency/stats")
async def api_concurrency_stats(_key=Depends(require_scope("read"))):
    """Live snapshot of the adaptive concurrency gates.

    ``capacity`` is recomputed from the container's current usable compute and
    available memory, so it shrinks under pressure and grows when resources free
    up — i.e. it auto-adjusts to whatever load MaxBooster sends."""
    from ai_model import dedup_cache
    return {
        "inference": INFERENCE_GATE.stats(),
        "render": RENDER_GATE.stats(),
        "dedup_cache": dedup_cache.stats(),
    }


@app.get("/api/video-jobs")
async def api_list_video_jobs(request: Request, _key=Depends(require_scope("read"))):
    """
    Return a summary of all video jobs in this server session, newest first.
    Each entry includes enough metadata to render a history view — no scene
    text payload is included; poll the individual job for full scenes[].
    """
    rows = []
    try:
        entries = [
            (fname, os.path.getmtime(os.path.join(_JOBS_DIR, fname)))
            for fname in os.listdir(_JOBS_DIR)
            if fname.endswith(".json") and not fname.endswith(".tmp")
        ]
        entries.sort(key=lambda x: x[1], reverse=True)
        for fname, _mtime in entries:
            job_id = fname[:-5]
            data = _job_read(job_id)
            if data is None:
                continue
            try:
                _require_job_owner(data, request)
            except HTTPException:
                continue
            rows.append({
                "job_id":          job_id,
                "status":          data.get("status"),
                "created_at":      data.get("created_at"),
                "platform":        data.get("platform"),
                "genre_detected":  data.get("genre_detected"),
                "tone_used":       data.get("tone_used"),
                "duration":        data.get("duration"),
                "source":          data.get("source"),
                "scenes_rendered": data.get("scenes_rendered", 0),
                "aspect_ratio":    data.get("aspect_ratio"),
                "url":             data.get("url"),
                "error":           data.get("error"),
            })
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return {"jobs": rows, "total": len(rows)}


@app.get("/api/video-job/{job_id}/preview/{scene_idx}")
async def api_video_job_preview(job_id: str, scene_idx: int, request: Request, _key=Depends(require_scope("read"))):
    """
    Extract a single JPEG thumbnail frame from a completed video job at
    the temporal midpoint of the requested scene.  Returns image/jpeg.
    """
    import subprocess

    job = _job_read(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    _require_job_owner(job, request)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail=f"Job is {job.get('status')}, not done")

    filename = job.get("filename")
    if not filename:
        raise HTTPException(status_code=404, detail="No output file recorded for this job")

    video_path = _UPLOADS_PATH / "videos" / filename
    if not video_path.exists():
        raise HTTPException(status_code=404, detail="Video file not found on disk")

    scenes = job.get("scenes", [])
    num_scenes = max(len(scenes), 1)
    if scene_idx < 0 or scene_idx >= num_scenes:
        raise HTTPException(
            status_code=422,
            detail=f"scene_idx must be 0–{num_scenes - 1} (video has {num_scenes} scenes)",
        )

    total_duration = float(job.get("duration") or 10.0)
    scene_dur = total_duration / num_scenes
    t = scene_idx * scene_dur + scene_dur * 0.4

    cmd = [
        "ffmpeg", "-y",
        "-ss", f"{t:.3f}",
        "-i", str(video_path),
        "-frames:v", "1",
        "-q:v", "3",
        "-f", "image2pipe",
        "-vcodec", "mjpeg",
        "pipe:1",
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=15)
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="Frame extraction timed out")

    if proc.returncode != 0 or not proc.stdout:
        raise HTTPException(status_code=500, detail="ffmpeg frame extraction failed")

    return Response(content=proc.stdout, media_type="image/jpeg")


@app.delete("/api/audio-job/{job_id}")
async def api_cancel_audio_job(job_id: str, request: Request, _key=Depends(require_scope("generate"))):
    """Cancel an owned audio render; its isolated worker observes terminal state."""
    job = _job_read(job_id)
    if job is None or job.get("job_type") != "audio":
        raise HTTPException(status_code=404, detail="Audio job not found")
    _require_job_owner(job, request)
    if job.get("status") not in ("done", "error", "cancelled"):
        _job_update(job_id, {"status": "cancelled", "error": "Cancelled by owner"})
    current = _job_read(job_id) or job
    return {"ok": True, "job_id": job_id, "status": current.get("status"),
            "action": "cancelled" if current.get("status") == "cancelled" else "no_op"}


@app.get("/api/audio-job/{job_id}")
async def api_poll_audio_job(job_id: str, request: Request, _key=Depends(require_scope("read"))):
    """Poll an audio generation job."""
    job = _job_read(job_id)
    if job is None:
        return {"status": "error", "error": "Job not found"}
    _require_job_owner(job, request)
    if job["status"] == "done":
        return {
            "status":    "done",
            "url":       job["url"],
            "audio_url": job["url"],
            "duration":  job["duration"],
            "bpm":       job["bpm"],
            "key":       job["key"],
            "format":        job.get("format"),
            "sample_rate":   job.get("sample_rate"),
            "bit_depth":     job.get("bit_depth"),
            "loudness_lufs": job.get("loudness_lufs"),
            "requested_bpm": job.get("requested_bpm"),
            "requested_key": job.get("requested_key"),
            "requested_loudness_lufs": job.get("requested_loudness_lufs"),
            "loudness_target_applied": job.get("loudness_target_applied"),
            "measured_bpm": job.get("measured_bpm"),
            "measured_key": job.get("measured_key"),
            "measured_loudness_lufs": job.get("measured_loudness_lufs"),
            "waveform_source": job.get("waveform_source"),
            # Measured sonic facts (loudness/energy/brightness/bass/stems) —
            # forwarded by clients into /api/generate/content beat_context.
            "audio_analysis": job.get("audio_analysis"),
            "stems":         job.get("stems") or {},
            # Awareness-driven section plan actually rendered (null = plain loop).
            "arrangement":   job.get("arrangement"),
            "seed":             job.get("seed"),
            "concept":          job.get("concept"),
            "style_hook":       job.get("style_hook"),
            "source":           job.get("source", "heuristic"),
            "technique":        job.get("technique"),
            # Awareness provenance — which live signals shaped track selection
            "awareness_genres":  job.get("awareness_genres"),
            "awareness_mood":    job.get("awareness_mood"),
            "awareness_source":  job.get("awareness_source"),
            # Non-None string when the dataset had no track matching the
            # requested key and the selector fell back to nearest-BPM.
            "selection_warning": job.get("selection_warning"),
            # Which dataset sample was selected (idx, bpm, key).
            "source_sample":     job.get("source_sample"),
        }
    if job["status"] == "error":
        return {"status": "error", "error": job.get("error", "Unknown error")}
    return {"status": job["status"]}


# ─── Audio stems endpoint ─────────────────────────────────────────────────────
# GET /api/audio/{job_id}/stems
# Returns a JSON dict of stem download URLs. The stems were saved when the job
# completed (if stems=True was requested). For jobs that had stems, the stem
# URLs are already stored on the job dict under "stems".
# Additionally persists individual WAV files under uploads/stems/{job_id}/ for
# direct per-stem downloads.

@app.get("/api/audio/{job_id}/stems")
async def api_audio_stems(job_id: str, request: Request, _key=Depends(require_scope("read"))):
    """Return stem download URLs for a completed audio job."""
    job = _job_read(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    _require_job_owner(job, request)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail=f"Job not complete (status={job.get('status')})")

    # stems dict from the job is already {name: "/uploads/..."} URL strings
    raw_stems: dict = job.get("stems") or {}

    # Also attempt to create/expose per-stem files under uploads/stems/{job_id}/
    # so clients can download individual named stems (drums.wav, bass.wav, etc.)
    stems_dir = _UPLOADS_PATH / "stems" / job_id
    try:
        stems_dir.mkdir(parents=True, exist_ok=True)
    except Exception as _mkdir_err:
        print(f"[stems] could not create stems dir: {_mkdir_err}", flush=True)

    # Build final URL map — prefer per-job stems dir copies, fall back to raw URLs
    stem_urls: dict = {}
    _standard_names = ("drums", "bass", "pads", "lead", "fx", "melody", "percussion")

    for name, src_url in raw_stems.items():
        # src_url is like "/uploads/audio_{job_id}_stem_{name}.wav"
        dest_name = f"{name}.wav"
        dest_path = stems_dir / dest_name
        if not dest_path.exists():
            # Copy from the original upload path
            try:
                src_filename = src_url.lstrip("/").removeprefix("uploads/")
                src_path = _UPLOADS_PATH / src_filename
                if src_path.exists():
                    import shutil as _shutil
                    _shutil.copy2(str(src_path), str(dest_path))
            except Exception as _cp_err:
                print(f"[stems] copy {name} failed: {_cp_err}", flush=True)
        # Always expose the per-job URL
        stem_urls[name] = f"/api/files/stems/{job_id}/{dest_name}"

    # If no stems from job dict, check if stem files exist on disk
    if not stem_urls:
        for sname in _standard_names:
            candidate = stems_dir / f"{sname}.wav"
            if candidate.exists():
                stem_urls[sname] = f"/api/files/stems/{job_id}/{sname}.wav"

    return {"stems": stem_urls, "job_id": job_id}


# ─── Serve stem files (file-serving route for stems) ─────────────────────────

@app.get("/api/files/stems/{job_id}/{filename}")
async def api_serve_stem_file(job_id: str, filename: str, request: Request, _key=Depends(require_scope("read"))):
    """Download an individual stem WAV file."""
    # Sanitise inputs to prevent path traversal: job_id and filename must be
    # simple names (no separators, no dot-segments), and the resolved path
    # must be strictly inside uploads/stems/<job_id>/ (relative_to, not a
    # string-prefix check, which sibling dirs like "uploads_bak" would pass).
    import re as _re_stem
    job = _job_read(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    _require_job_owner(job, request)
    if not _re_stem.fullmatch(r"[A-Za-z0-9._-]+", job_id) or job_id in (".", ".."):
        raise HTTPException(status_code=400, detail="Invalid path")
    safe_name = Path(filename).name
    if (safe_name != filename or not safe_name
            or not _re_stem.fullmatch(r"[A-Za-z0-9._-]+", safe_name)
            or safe_name in (".", "..")):
        raise HTTPException(status_code=400, detail="Invalid path")
    stems_root = (_UPLOADS_PATH / "stems").resolve()
    stem_path = (stems_root / job_id / safe_name).resolve()
    try:
        stem_path.relative_to(stems_root / job_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid path")
    if not stem_path.exists():
        raise HTTPException(status_code=404, detail="Stem file not found")
    return FileResponse(
        str(stem_path),
        media_type="audio/wav",
        filename=safe_name,
        headers={"Content-Disposition": f'attachment; filename="{safe_name}"'},
    )


# ─── Audio MIDI endpoint ──────────────────────────────────────────────────────
# GET /api/audio/{job_id}/midi
# Generates a MIDI file from the job parameters and returns it as a download.

@app.get("/api/audio/{job_id}/midi")
async def api_audio_midi(job_id: str, request: Request, _key=Depends(require_scope("read"))):
    """Generate and return a MIDI file for a completed audio job."""
    job = _job_read(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    _require_job_owner(job, request)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail=f"Job not complete (status={job.get('status')})")

    bpm   = float(job.get("bpm") or 120)
    key   = str(job.get("key") or "C")
    dur   = float(job.get("duration") or 30)

    # Build a minimal MIDI file using only stdlib (struct + bytes).
    # Format 0, single track, 480 PPQN. Writes a simple chord pattern
    # at the job's BPM/key to give producers a starting point.
    try:
        import io as _io
        import struct as _struct

        PPQN = 480
        tempo_us = int(60_000_000 / bpm)  # microseconds per beat

        # Key → root MIDI note (C4 = 60)
        _key_map = {
            "C": 60, "C#": 61, "Db": 61, "D": 62, "D#": 63, "Eb": 63,
            "E": 64, "F": 65, "F#": 66, "Gb": 66, "G": 67, "G#": 68,
            "Ab": 68, "A": 69, "A#": 70, "Bb": 70, "B": 71,
        }
        root = _key_map.get(key.split("m")[0], 60)
        # Major chord: root, major third, fifth
        notes = [root, root + 4, root + 7]

        def _var(v: int) -> bytes:
            """Encode variable-length MIDI quantity."""
            buf = [v & 0x7F]
            v >>= 7
            while v:
                buf.append((v & 0x7F) | 0x80)
                v >>= 7
            buf.reverse()
            return bytes(buf)

        track_data = _io.BytesIO()
        # Tempo meta event (delta=0)
        track_data.write(b"\x00\xFF\x51\x03")
        track_data.write(_struct.pack(">I", tempo_us)[1:])  # 3-byte big-endian

        # Number of bars to fill `dur` seconds
        beats_per_bar = 4
        beat_dur_s = 60.0 / bpm
        total_beats = max(4, int(dur / beat_dur_s))
        total_bars  = max(1, total_beats // beats_per_bar)

        for _bar in range(min(total_bars, 32)):  # cap at 32 bars
            # Note-on for each note in chord (delta=0 for simultaneous)
            for i, note in enumerate(notes):
                delta = 0 if i > 0 else 0
                track_data.write(_var(delta) + bytes([0x90, note, 80]))
            # Note-off after one bar (4 beats = 4*PPQN ticks)
            bar_ticks = beats_per_bar * PPQN
            for i, note in enumerate(notes):
                delta = bar_ticks if i == 0 else 0
                track_data.write(_var(delta) + bytes([0x80, note, 0]))

        # End of track meta event
        track_data.write(b"\x00\xFF\x2F\x00")

        track_bytes = track_data.getvalue()
        track_len   = len(track_bytes)

        midi_buf = _io.BytesIO()
        # MIDI Header chunk
        midi_buf.write(b"MThd")
        midi_buf.write(_struct.pack(">IHHH", 6, 0, 1, PPQN))
        # MIDI Track chunk
        midi_buf.write(b"MTrk")
        midi_buf.write(_struct.pack(">I", track_len))
        midi_buf.write(track_bytes)

        midi_bytes = midi_buf.getvalue()
        safe_key   = key.replace("#", "s").replace("/", "_")
        filename   = f"audio_{job_id[:8]}_{safe_key}_{int(bpm)}bpm.mid"

        from fastapi.responses import Response as _FResponse
        return _FResponse(
            content=midi_bytes,
            media_type="application/octet-stream",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"MIDI generation failed: {exc}")


# -- Model weight sync (no /api/ prefix) --------------------------------------

@app.get("/api/models/social/state")
async def models_social_state(_key=Depends(require_scope("read"))):
    """Current trained weight state for the social model domain."""
    return _api_model_state("social")


@app.get("/api/models/advertising/state")
async def models_advertising_state(_key=Depends(require_scope("read"))):
    """Current trained weight state for the advertising model domain."""
    return _api_model_state("advertising")


@app.get("/api/models/content/state")
async def models_content_state(_key=Depends(require_scope("read"))):
    """Current trained weight state for the content model domain."""
    return _api_model_state("content")


@app.get("/api/models/engagement/state")
async def models_engagement_state(_key=Depends(require_scope("read"))):
    """Current trained weight state for the engagement model domain."""
    return _api_model_state("engagement")


# -- Training feedback ---------------------------------------------------------

_feedback_records: List[dict] = []
_feedback_lock    = threading.Lock()

@app.post("/api/train/feedback")
async def train_feedback_endpoint(req: ApiTrainFeedbackRequest, _key=Depends(require_scope("train"))):
    """Receive anonymised engagement signals for MaxCore retraining."""
    record = {**req.model_dump(), "received_at": datetime.utcnow().isoformat() + "Z"}
    with _feedback_lock:
        _feedback_records.append(record)
        if len(_feedback_records) > 10_000:
            _feedback_records[:] = _feedback_records[-10_000:]
    # Attempt to persist
    try:
        fb_path = Path(__file__).resolve().parent / "knowledge" / "feedback_log.json"
        fb_path.parent.mkdir(parents=True, exist_ok=True)
        existing: list = []
        if fb_path.exists():
            existing = json.loads(fb_path.read_text())
        existing.append(record)
        fb_path.write_text(json.dumps(existing[-10_000:], indent=2))
    except Exception as e:
        print(f"[Feedback] WARNING: could not persist: {e}", flush=True)
    return {"ok": True}


# ─── MaxBooster contract endpoints (aliases / new) ───────────────────────────

@app.get("/api/health")
async def api_health():
    """Health probe under the /api prefix — MaxCoreAIClient.isAvailable() polls this."""
    return {
        "status": "healthy",
        "model_loaded": _model_ready,
        "uptime_seconds": time.time() - _start_time,
        "version": "1.0.0",
        "storage_mode": _get_storage_mode(),
    }


# ─── Production warm-up ───────────────────────────────────────────────────────
# Tracks the last deep-warm result so GET /api/warm/status is non-destructive.
_deep_warm_status: dict[str, Any] = {
    "state": "pending",   # pending | warm | partial | error
    "cycles": 0,
    "last_warm_at": None,
    "subsystems": {},
}


@app.post("/api/warm")
@_planned_generation("content", specification=True)
async def api_warm(_admin=Depends(verify_admin)):
    """
    Production warm-up pass — exercises the Digital GPU inference chains so the
    reserved VM is fully hot before (or between) real user requests.

    Runs one inference pass through:
      • transformer / KV-cache  (short prompt selected from checkpoint vocabulary)
      • distribution agent      (binding check; shares the warmed transformer)
      • pocket GEMM dedup cache (stats probe confirms cache is active)
      • quality awareness       (platform buffer re-prime)
      • RTA Digital GPU         (global GEMM op-count probe)

    Every step is never-raise.  Returns per-subsystem timing and the accumulated
    warm_start status from the boot-time subsystem pre-warm.
    Safe to call repeatedly — idempotent and cheap after the first pass.
    """
    import time as _wt

    _deep_warm_status["cycles"] = _deep_warm_status.get("cycles", 0) + 1
    results: dict[str, Any] = {}
    overall_ok = True

    def _step(name: str, fn) -> None:
        nonlocal overall_ok
        t0 = _wt.time()
        try:
            val = fn()
            results[name] = {"ok": True, "ms": int((_wt.time() - t0) * 1000), "detail": val}
        except Exception as exc:
            results[name] = {"ok": False, "ms": int((_wt.time() - t0) * 1000), "error": f"{type(exc).__name__}: {exc}"}
            overall_ok = False

    # ── 1. Transformer / KV-cache ─────────────────────────────────────────────
    # Use a prompt the loaded checkpoint can encode. A synthetic creative brief
    # would add awareness/request words that may not exist in its frozen vocab.
    # This still runs CreativeModel.generate and its unchanged prompt-loss guard.
    def _warm_transformer():
        if not _model_ready or _creative_model is None or _tokenizer is None:
            return "skipped (model not ready)"
        from ai_model.generation.plan import active_plan
        from ai_model.model.creative_model import select_representable_probe_prompt
        plan = active_plan.get()
        if plan is None:
            raise RuntimeError("Warm-up inference requires an active generation plan")
        prompt = ("music" if globals().get("_live_serving_model") is not None
                  else select_representable_probe_prompt(_tokenizer))
        output = _creative_model.generate(
            prompt,
            max_new_tokens=4,
            temperature=0.8,
            top_p=0.92,
            top_k=50,
            min_length=4,
            seed=plan.seed,
            snapshot_hash=plan.snapshot_hash,
        )
        encoded = _tokenizer.encode(prompt)
        return f"prompt_tokens={len(getattr(encoded, 'ids', encoded))} generated_chars={len(output)}"

    # ── 2. DistributionAgent binding ──────────────────────────────────────────
    # DistributionAgent shares the same model; it is not an independent scorer.
    # Do not synthesize a caption request here: that would invent conditioning
    # rather than verify a distinct inference subsystem.
    def _warm_distribution_agent():
        if not _model_ready or _distribution_agent is None:
            return "skipped (distribution agent not ready)"
        if _distribution_agent.model is not _creative_model:
            raise RuntimeError("DistributionAgent is not bound to the serving checkpoint")
        return "bound to the serving checkpoint"

    # ── 3. Pocket GEMM dedup cache ────────────────────────────────────────────
    def _warm_pocket():
        from ai_model.maxcore.pdim import get_pocket_accelerator
        pa = get_pocket_accelerator()
        stats = pa.stats()
        return f"hits={stats.get('hits', 0)} misses={stats.get('misses', 0)}"

    # ── 4. Quality awareness buffer ───────────────────────────────────────────
    def _warm_awareness():
        from ai_model import quality_awareness
        quality_awareness.platform_awareness_string("tiktok")
        return "ok"

    # ── 5. RTA Digital GPU op-count probe ────────────────────────────────────
    def _warm_rta():
        from ai_model import rta as _rta
        counts = _rta.global_op_counts()
        total = sum(counts.values()) if isinstance(counts, dict) else 0
        return f"total_ops={total}"

    await _in_thread(lambda: _step("transformer",  _warm_transformer))
    await _in_thread(lambda: _step("distribution_agent", _warm_distribution_agent))
    await _in_thread(lambda: _step("pocket_gemm",  _warm_pocket))
    await _in_thread(lambda: _step("awareness",    _warm_awareness))
    await _in_thread(lambda: _step("rta",          _warm_rta))

    _deep_warm_status["state"] = "warm" if overall_ok else "partial"
    _deep_warm_status["last_warm_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    _deep_warm_status["subsystems"] = results

    return {
        "hot": overall_ok,
        "model_ready": _model_ready,
        "warm_start": _warm_status,
        "deep_warm": _deep_warm_status,
        "subsystems": results,
    }


@app.get("/api/warm/status")
async def api_warm_status(_admin=Depends(verify_admin)):
    """Non-destructive warm-up status — returns last deep-warm result without running a new pass."""
    return {
        "model_ready": _model_ready,
        "warm_start": _warm_status,
        "deep_warm": _deep_warm_status,
    }


@app.get("/api/rta/status")
async def api_rta_status(selftest: bool = False, _key=Depends(require_scope("generate"))):
    """RTA-1 rendering-fabric status. Proves the trinity (IRC/VRC/ARC) runs on the
    self-contained Digital GPU by reporting cumulative GEMM ops; ``?selftest=1``
    runs a fast end-to-end render of all three mediums."""
    from ai_model import rta as _rta
    out = {
        "fabric": "RTA-1 (UMRF)",
        "compute_backend": "digital_gpu",
        "nodes": sorted(_rta.node_registry().keys()),
        "digital_gpu_ops": _rta.global_op_counts(),
    }
    if selftest:
        out["selftest"] = await _in_thread(_rta.api.self_test)
        out["digital_gpu_ops_after"] = _rta.global_op_counts()
    return out


class ApiSafetyScreenRequest(BaseModel):
    text: str = ""


@app.post("/api/safety/screen")
async def api_safety_screen(req: ApiSafetyScreenRequest, _key=Depends(require_scope("generate"))):
    """Stage 8 content-safety probe: screen + enforce a piece of text. Returns the
    policy verdict and the enforced (redacted/refused) output. Also exposes the
    running violation counters."""
    from ai_model.safety import get_safety
    s = get_safety()
    res = s.enforce(req.text or "")
    return {
        **res.to_dict(),
        "enforced_text": res.text,
        "stats": s.stats(),
    }


@app.post("/api/audio/mastering-recommendation")
async def audio_mastering_recommendation(
    req: AudioMasteringRecommendationRequest,
    _key=Depends(require_scope("generate")),
):
    """Make mastering decisions from measured PCM features, never file IDs or seeds.

    This endpoint intentionally receives the compact analysis generated by the
    Node DSP rather than audio bytes.  Its coupled decision model assesses
    spectral balance, dynamics, rhythm, timbre, loudness and stereo image
    together and returns parameters for the local sample-processing chain.
    """
    import math

    def finite(value: float, fallback: float = 0.0) -> float:
        return float(value) if math.isfinite(value) else fallback

    def clip(value: float, low: float, high: float) -> float:
        return max(low, min(high, value))

    f = req.frequencyBalance
    s = req.spectral
    d = req.dynamics
    r = req.rhythm
    t = req.timbre
    balance = {name: clip(finite(getattr(f, name)), 0.0, 1.0)
               for name in ("sub", "bass", "lowMid", "mid", "highMid", "presence", "brilliance")}
    brightness = clip((finite(s.brightness) + balance["presence"] + balance["brilliance"]) / 3, 0, 1)
    low_weight = clip((balance["sub"] + balance["bass"] + finite(s.bassPresence)) / 3, 0, 1)
    mid_weight = clip((balance["lowMid"] + balance["mid"] + finite(s.midPresence)) / 3, 0, 1)
    high_weight = clip((balance["highMid"] + balance["presence"] + balance["brilliance"] +
                        finite(s.highPresence)) / 4, 0, 1)
    dynamic_range = clip(finite(req.dynamicRange, finite(d.dynamicRange)), 0, 40)
    crest = clip(finite(d.crestFactor), 0, 30)
    tempo = clip(finite(r.tempo, 120), 40, 240)
    tempo_confidence = clip(finite(r.tempoConfidence), 0, 1)
    groove = clip(finite(r.groove), 0, 1)
    complexity = clip(finite(r.rhythmComplexity), 0, 1)
    harmonic = clip(finite(t.harmonicRatio), 0, 1)
    noise = clip((finite(t.noisiness) + finite(s.spectralFlatness)) / 2, 0, 1)
    roughness = clip(finite(t.roughness), 0, 1)
    width = clip(finite(req.stereoWidth), 0, 2)
    lufs = clip(finite(req.currentLUFS, -24), -70, 0)
    peak = clip(finite(req.currentPeak, -12), -96, 3)

    genres = {
        "hip-hop": {"tempo": 88, "low": .62, "bright": .42, "range": 7, "width": .78, "lufs": -9},
        "electronic": {"tempo": 126, "low": .53, "bright": .66, "range": 6, "width": 1.12, "lufs": -8},
        "pop": {"tempo": 116, "low": .43, "bright": .58, "range": 9, "width": .92, "lufs": -10},
        "rock": {"tempo": 124, "low": .46, "bright": .53, "range": 10, "width": .85, "lufs": -11},
        "jazz": {"tempo": 112, "low": .36, "bright": .42, "range": 15, "width": .70, "lufs": -16},
        "classical": {"tempo": 100, "low": .34, "bright": .45, "range": 20, "width": .62, "lufs": -20},
        "r&b": {"tempo": 92, "low": .54, "bright": .43, "range": 9, "width": .83, "lufs": -10},
        "metal": {"tempo": 145, "low": .49, "bright": .61, "range": 6, "width": .88, "lufs": -9},
    }
    requested = (req.genre or "").strip().lower()
    if requested not in genres:
        # Joint distance: genre identity arises from multiple measured factors,
        # not a single threshold such as tempo or bass alone.
        def distance(profile: dict) -> float:
            return (
                abs(tempo - profile["tempo"]) / 70 * (0.5 + tempo_confidence / 2)
                + abs(low_weight - profile["low"]) * 1.6
                + abs(brightness - profile["bright"]) * 1.4
                + abs(dynamic_range - profile["range"]) / 18
                + abs(width - profile["width"]) * 0.7
                + abs(noise - (0.34 if profile["lufs"] <= -11 else 0.45)) * 0.35
            )
        genre = min(genres, key=lambda name: distance(genres[name]))
        genre_confidence = clip(1 - distance(genres[genre]) / 2.8, .35, .92)
    else:
        genre = requested
        genre_confidence = .92
    profile = genres[genre]

    # ── Elite reference anchoring ─────────────────────────────────────────
    # When the Node layer attaches the measured elite reference profile, its
    # finishing targets override the genre presets: the benchmark showed the
    # MaxCore-vs-elite gap is mastering/finishing (LUFS, true peak, LRA,
    # stereo image), not genre identity or composition.
    ref = req.referenceProfile or {}
    def _ref(key: str, fallback: float) -> float:
        try:
            v = float(ref.get(key, fallback))
            return v if math.isfinite(v) else fallback
        except (TypeError, ValueError):
            return fallback
    ref_lufs = _ref("targetLUFS", profile["lufs"])
    ref_peak = _ref("truePeakCeilingDbtp", -1.0 if genre in ("jazz", "classical") else (-.3 if genre in ("hip-hop", "electronic", "metal", "r&b") else -.6))
    ref_lra = _ref("lraLu", profile["range"])
    ref_width = _ref("stereoWidth", profile["width"])
    ref_anchored = bool(ref)

    # A corrective target moves with programme material: high transient/noisy
    # material gets less high boost; dense low-end material gets more control.
    ideal_low = profile["low"] - .06 * noise + .03 * harmonic
    ideal_bright = profile["bright"] - .08 * noise + .04 * complexity
    mud = balance["lowMid"] - (0.14 + .05 * harmonic)
    presence_target = .15 + .10 * harmonic + .05 * complexity
    sub_gain = clip((ideal_low - balance["sub"]) * 9 - max(0, crest - 12) * .08, -5, 4)
    bass_gain = clip((ideal_low - balance["bass"]) * 8 - max(0, balance["sub"] - .18) * 3, -5, 4)
    low_mid_gain = clip(-mud * 10 + (0.04 if dynamic_range > 14 else 0), -5, 3)
    presence_gain = clip((presence_target - balance["highMid"]) * 8 + (profile["bright"] - brightness) * 2, -4, 4)
    air_gain = clip((ideal_bright - (balance["presence"] + balance["brilliance"]) / 2) * 9 - noise * 1.5, -4, 4)

    density = clip((8 - dynamic_range) / 8, 0, 1)
    transient_pressure = clip((crest - 9) / 10, 0, 1)
    low_control = clip(1.5 + density * 1.6 + max(0, low_weight - ideal_low) * 3 + roughness * .3, 1.2, 5)
    high_control = clip(1.3 + density * .9 + noise * .9, 1.1, 3.8)
    base_threshold = clip(-17 + (lufs + 14) * .22 - transient_pressure * 2, -25, -8)
    # Stereo target: when elite-anchored, move toward the reference width
    # (0.7683 measured) instead of the genre preset alone.
    _width_anchor = ref_width if ref_anchored else profile["width"]
    desired_width = clip(_width_anchor + (_width_anchor - width) * .34 - noise * .08, .85, 1.35)
    true_peak = ref_peak if ref_anchored else (-1.0 if genre in ("jazz", "classical") else (-.3 if genre in ("hip-hop", "electronic", "metal", "r&b") else -.6))
    target_lufs = ref_lufs
    limiter_ceiling = clip(true_peak - (.12 if dynamic_range < 6 or peak > -.3 else 0), -1.3, -.1)
    input_gain = clip(-6 - peak, -12, 6)

    issues = sum(1 for v in (abs(ideal_low - low_weight) > .14, abs(ideal_bright - brightness) > .14,
                              abs(mud) > .10, dynamic_range < 5, width < .16, peak > -.15) if v)
    feature_quality = (tempo_confidence + clip(harmonic + (1 - noise), 0, 1) +
                       (1 if -60 < lufs < -2 else .2)) / 3
    confidence = clip(.38 + .35 * genre_confidence + .27 * feature_quality - .035 * issues, .35, .96)
    reasoning = [
        f"{genre} profile selected from tempo {tempo:.0f} BPM, low-energy {low_weight:.2f}, brightness {brightness:.2f}, and {dynamic_range:.1f} dB dynamics.",
        f"Coupled tonal correction addresses low-end {'excess' if low_weight > ideal_low else 'deficit'} and {'excess' if brightness > ideal_bright else 'deficit'} high-frequency energy.",
        f"Compression responds to density {density:.2f}, crest factor {crest:.1f}, and timbral noise {noise:.2f}; it is not a fixed genre preset.",
        f"Stereo target {desired_width:.2f} protects low frequencies below {120 if low_weight > .5 else 100} Hz while responding to measured width {width:.2f}.",
    ]
    if ref_anchored:
        reasoning.append(
            f"Elite-reference anchored: target {ref_lufs:.1f} LUFS, "
            f"{ref_peak:.1f} dBTP ceiling, {ref_lra:.1f} LU LRA, "
            f"width {ref_width:.2f} (measured {ref.get('measuredFrom', 'elite reference')}).")
    return {
        "genre": genre,
        "config": {
            "inputGain": round(input_gain, 3),
            "eq": [
                {"frequency": 45, "gain": round(sub_gain, 3), "q": .8, "type": "lowShelf"},
                {"frequency": 110, "gain": round(bass_gain, 3), "q": 1.0, "type": "peak"},
                {"frequency": 320, "gain": round(low_mid_gain, 3), "q": 1.25, "type": "peak"},
                {"frequency": 3200, "gain": round(presence_gain, 3), "q": 1.1, "type": "peak"},
                {"frequency": 11000, "gain": round(air_gain, 3), "q": .75, "type": "highShelf"},
            ],
            "multibandCompressor": [
                {"lowFreq": 0, "highFreq": 110, "threshold": round(base_threshold - 2, 3), "ratio": round(low_control, 3), "attack": 18, "release": 130, "knee": 5, "makeupGain": round(max(0, bass_gain) * .35, 3)},
                {"lowFreq": 110, "highFreq": 500, "threshold": round(base_threshold, 3), "ratio": round(1.5 + density * 1.2 + max(0, mud) * 2, 3), "attack": 14, "release": 105, "knee": 4, "makeupGain": round(max(0, -low_mid_gain) * .15, 3)},
                {"lowFreq": 500, "highFreq": 2200, "threshold": round(base_threshold + .5, 3), "ratio": round(1.35 + density * .9, 3), "attack": 10, "release": 85, "knee": 4, "makeupGain": 0},
                {"lowFreq": 2200, "highFreq": 8000, "threshold": round(base_threshold - noise, 3), "ratio": round(1.4 + density + noise * .7, 3), "attack": 5, "release": 60, "knee": 3, "makeupGain": round(max(0, presence_gain) * .2, 3)},
                {"lowFreq": 8000, "highFreq": 20000, "threshold": round(base_threshold - noise * 1.5, 3), "ratio": round(high_control, 3), "attack": 3, "release": 50, "knee": 3, "makeupGain": round(max(0, air_gain) * .18, 3)},
            ],
            "stereo": {"width": round(desired_width, 3), "bassMonoFreq": 120 if low_weight > .5 else 100,
                       "midSideBalance": 0, "correlation": .3},
            "loudness": {"targetLUFS": target_lufs, "truePeak": true_peak,
                         "loudnessRange": round(clip(max(dynamic_range, ref_lra * .65) if ref_anchored else max(dynamic_range, profile["range"] * .65), 4, 16), 3),
                         "shortTermMax": 3},
            "limiter": {"ceiling": round(limiter_ceiling, 3), "release": 90 if dynamic_range > 13 else 50,
                        "lookahead": 1.5, "softClip": dynamic_range < 8},
            "outputGain": 0, "dithering": True, "bitDepth": 24,
        },
        "confidence": round(confidence, 3),
        "reasoning": reasoning,
    }


@app.post("/api/audio/mixing-recommendation")
async def audio_mixing_recommendation(
    req: AudioMixingRecommendationRequest,
    _key=Depends(require_scope("generate")),
):
    """Per-track corrective EQ + compression decision from measured PCM features.

    Unlike mastering (which balances a finished stereo mix), this decides how
    a single track should sit in a mix before summing: role sets the target
    tonal/dynamics profile for what a bass, kick, vocal or generic part
    should look like, and the actual measured spectral/dynamics/timbre
    features of THIS track -- not just its name string -- determine how far
    it sits from that target and how hard to correct it. Two tracks sharing
    a role get different treatment if their measured content differs.
    """
    import math

    def finite(value: float, fallback: float = 0.0) -> float:
        return float(value) if math.isfinite(value) else fallback

    def clip(value: float, low: float, high: float) -> float:
        return max(low, min(high, value))

    f = req.frequencyBalance
    s = req.spectral
    d = req.dynamics
    t = req.timbre
    balance = {name: clip(finite(getattr(f, name)), 0.0, 1.0)
               for name in ("sub", "bass", "lowMid", "mid", "highMid", "presence", "brilliance")}
    dynamic_range = clip(finite(req.dynamicRange, finite(d.dynamicRange)), 0, 40)
    crest = clip(finite(d.crestFactor), 0, 30)
    harmonic = clip(finite(t.harmonicRatio), 0, 1)
    noise = clip((finite(t.noisiness) + finite(s.spectralFlatness)) / 2, 0, 1)
    roughness = clip(finite(t.roughness), 0, 1)
    peak = clip(finite(req.currentPeak, -6), -96, 3)

    # Target balance + dynamics character per instrumental role. These are
    # starting points the measured features then pull away from below --
    # not fixed presets applied verbatim.
    roles = {
        "bass": {"sub": .62, "bass": .58, "lowMid": .16, "presence": .08,
                 "hpf": 30, "thresh": -16, "ratio": 3.4, "attack": 8, "release": 90, "holdLowMid": True},
        "kick": {"sub": .30, "bass": .40, "lowMid": .15, "presence": .18,
                 "hpf": 35, "thresh": -14, "ratio": 4.0, "attack": 3, "release": 60, "holdLowMid": True},
        "drums": {"sub": .26, "bass": .34, "lowMid": .17, "presence": .22,
                  "hpf": 40, "thresh": -15, "ratio": 3.6, "attack": 4, "release": 70, "holdLowMid": True},
        "vocal": {"sub": .02, "bass": .10, "lowMid": .12, "presence": .32,
                  "hpf": 100, "thresh": -18, "ratio": 2.5, "attack": 6, "release": 85, "holdLowMid": False},
        "generic": {"sub": .18, "bass": .26, "lowMid": .20, "presence": .18,
                    "hpf": 55, "thresh": -20, "ratio": 2.2, "attack": 10, "release": 100, "holdLowMid": False},
    }
    role = (req.role or "generic").strip().lower()
    if role not in roles:
        role = "generic"
    target = roles[role]

    # Corrective gain moves the measured balance toward the role's target,
    # but noisy/harsh source material is corrected more gently so the fix
    # doesn't amplify grit that's already there.
    gentleness = 1 - noise * .35
    sub_gain = clip((target["sub"] - balance["sub"]) * 8 * gentleness, -6, 5)
    bass_gain = clip((target["bass"] - balance["bass"]) * 7 * gentleness, -6, 5)
    if target["holdLowMid"]:
        # Bass/kick/drums: low-mids only ever get cut (to keep the 200-500Hz
        # zone from turning to mud when several such tracks sum together).
        low_mid_gain = clip(-(balance["lowMid"] - target["lowMid"]) * 9, -6, 0)
    else:
        low_mid_gain = clip((target["lowMid"] - balance["lowMid"]) * 7 * gentleness, -6, 4)
    presence_gain = clip((target["presence"] - balance["presence"]) * 8 * gentleness + harmonic * 1.2, -5, 5)

    # Compression responds to how dense/peaky the source already is, not a
    # fixed per-role number: a track that already sits consistent (high
    # dynamic range, low crest factor) needs less squeeze than a spiky one.
    density = clip((10 - dynamic_range) / 10, 0, 1)
    transient = clip((crest - 8) / 14, 0, 1)
    threshold = clip(target["thresh"] + (peak + 6) * .3 - transient * 3, -34, -6)
    ratio = clip(target["ratio"] - density * .6 + roughness * .4, 1.3, 6)
    attack = clip(target["attack"] * (1 - transient * .4), 1, 40)
    release = clip(target["release"] * (1 + density * .3), 30, 250)
    makeup = clip(max(0, -threshold - 14) * .18, 0, 4)

    confidence = clip(.5 + harmonic * .18 + (1 - noise) * .18 + (.14 if role != "generic" else 0), .4, .95)
    reasoning = [
        f"{role} target profile compared against measured sub {balance['sub']:.2f}, bass {balance['bass']:.2f}, low-mid {balance['lowMid']:.2f}, presence {balance['presence']:.2f}.",
        f"Corrective EQ was {'gentled for measured noisiness ' + format(noise, '.2f') if noise > .5 else 'applied directly, source is clean'}.",
        f"Compression set from measured dynamic range {dynamic_range:.1f} dB and crest factor {crest:.1f} -- not a fixed {role} preset.",
    ]

    return {
        "role": role,
        "config": {
            "highpassFreq": target["hpf"],
            "eq": [
                {"frequency": 60, "gain": round(sub_gain, 3), "q": 0.8},
                {"frequency": 120, "gain": round(bass_gain, 3), "q": 1.0},
                {"frequency": 350, "gain": round(low_mid_gain, 3), "q": 1.2},
                {"frequency": 3200, "gain": round(presence_gain, 3), "q": 1.1},
            ],
            "compressor": {
                "threshold": round(threshold, 3),
                "ratio": round(ratio, 3),
                "attack": round(attack, 3),
                "release": round(release, 3),
                "makeupGain": round(makeup, 3),
            },
        },
        "confidence": round(confidence, 3),
        "reasoning": reasoning,
    }


@app.post("/api/audio/analyze")
async def api_audio_analyze(req: ApiAudioAnalyzeRequest, request: Request, _key=Depends(require_scope("generate"))):
    """
    Beat/structure analysis for beat-synced music video generation.
    Deterministic per audio reference so repeated calls on the same track agree.
    Returns bpm/tempo, key/musical_key, sections[], energy_curve[] and mood[].
    """
    return await _analyze_audio_reference(req.audio_path or req.audio_url, request)


@app.post("/api/infer/viral-score")
async def api_infer_viral_score(req: ApiViralScoreRequest, _key=Depends(require_scope("generate"))):
    """
    Pre-render viral potential score for a planned music video.
    Returns score and viral_score in 0–1 (MaxBooster multiplies by 100) plus a
    human-readable recommendation.
    """
    raise HTTPException(
        status_code=503,
        detail={
            "error": "MaxCore video scoring inference unavailable",
            "required_capability": "trained video-plan scoring model",
            "requested_model": req.model,
        },
    )


def _resolve_video_job_file(job_id: str, request: Request) -> Path:
    """Validate a completed video job and return its on-disk MP4 path."""
    job = _job_read(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    _require_job_owner(job, request)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail=f"Job is {job.get('status')}, not done")
    filename = job.get("filename")
    if not filename:
        raise HTTPException(status_code=404, detail="No output file recorded for this job")
    videos_dir = (_UPLOADS_PATH / "videos").resolve()
    path = (videos_dir / filename).resolve()
    # Containment guard: never serve anything outside the videos directory
    if not path.is_relative_to(videos_dir):
        raise HTTPException(status_code=400, detail="Invalid output path")
    if not path.exists():
        raise HTTPException(status_code=404, detail="Video file not found on disk")
    return path


@app.get("/api/video-job/{job_id}/download")
@app.get("/api/video-job/{job_id}/file")
@app.get("/api/video-job/{job_id}/video")
async def api_video_job_download(job_id: str, request: Request, _key=Depends(require_scope("read"))):
    """Serve the rendered MP4 binary for a completed video job (validated by ftyp on the client)."""
    path = _resolve_video_job_file(job_id, request)
    return FileResponse(str(path), media_type="video/mp4", filename=path.name)


# ─── Entry Point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import multiprocessing
    import uvicorn
    port = int(os.environ.get("MODEL_API_PORT", 9878))

    # ── Single-instance guard ───────────────────────────────────────────────
    # uvicorn kicks off the model load (~1.7 GB) during application startup,
    # which begins before the port is reliably bound.  In production the API
    # server can run more than one cluster primary (e.g. ports 8080 and 3000),
    # and each primary independently manages the Python AI server.  Two near-
    # simultaneous spawns both pass the "is the port open yet?" check and each
    # load the full model before either binds 9878 — doubling memory to ~3.4 GB
    # and starving the video renderer, so even posix_spawn'd ffmpeg execve
    # fails with OSError [Errno 5] (EIO) under the memory cgroup.
    #
    # An exclusive OS file lock guarantees exactly one instance ever loads the
    # model.  A duplicate stands down *before* importing/loading anything heavy,
    # then waits for the owner to bind the port so the Node lifecycle manager
    # sees "port held by another process" and quietly stands by (no respawn
    # loop).  The lock is advisory and tied to the open fd, so the kernel
    # releases it automatically if the owner crashes.
    import fcntl
    _singleton_lock_path = os.environ.get(
        "MODEL_SINGLETON_LOCK", f"/tmp/maxcore_model_{port}.lock"
    )
    _singleton_lock_fd = os.open(
        _singleton_lock_path, os.O_CREAT | os.O_RDWR, 0o644
    )
    try:
        fcntl.flock(_singleton_lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print(
            f"[Server] Another AI server instance already holds "
            f"{_singleton_lock_path} — standing down to avoid a duplicate "
            f"model load.",
            flush=True,
        )
        import socket as _socket
        import time as _time
        _deadline = _time.time() + 90
        while _time.time() < _deadline:
            with _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM) as _s:
                _s.settimeout(1.0)
                if _s.connect_ex(("127.0.0.1", port)) == 0:
                    break
            _time.sleep(1.0)
        os._exit(0)

    # Worker count: default 1 to keep memory footprint small (each worker
    # loads the full ~1.7 GB model independently).  Operators on hosts with
    # more RAM can set UVICORN_WORKERS=N to scale unique-request throughput
    # linearly.  BLAS thread pools are sized to cpus // UVICORN_WORKERS (see
    # the bootstrap block at the top of this module, before numpy is
    # imported) so N worker processes divide the host instead of each
    # claiming a full-core BLAS pool.
    cpu_count = multiprocessing.cpu_count()
    worker_count = max(1, int(os.environ.get("UVICORN_WORKERS", "1")))
    print(f"[Server] Starting MaxBooster AI Training Server on port {port} "
          f"({worker_count} uvicorn workers, {cpu_count} CPUs detected)")

    # Any exception that escapes uvicorn.run() — import error, port conflict,
    # bad config, etc. — must produce a non-zero exit so the Node supervisor's
    # "exit" event handler fires and schedules a restart.  Without this, an
    # unhandled exception would let Python exit with code 1 by default (which
    # is correct), but we make it explicit and log the full traceback so the
    # cause is visible in workflow logs.
    try:
        uvicorn.run(
            "server:app",
            host="127.0.0.1",
            port=port,
            log_level="info",
            workers=worker_count,
            timeout_keep_alive=300,
            limit_concurrency=None,   # no artificial cap — async coalescer + pdim auto-scale handle backpressure
            backlog=4096,             # maximise OS socket queue for burst acceptance
        )
    except SystemExit:
        # uvicorn raises SystemExit(0) on clean SIGTERM/SIGINT shutdown.
        # Re-raise so the process exits with the original code and the Node
        # supervisor sees the correct signal/code combination.
        raise
    except Exception:
        import traceback
        traceback.print_exc()
        print("[Server] uvicorn.run() raised an unexpected exception — exiting with code 1 so supervisor restarts.", flush=True)
        sys.exit(1)
